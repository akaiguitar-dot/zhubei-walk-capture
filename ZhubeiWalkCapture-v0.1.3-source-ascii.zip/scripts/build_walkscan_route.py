#!/usr/bin/env python3
"""Build a local point-line-face corridor skeleton from a WalkScan package."""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
import tempfile
import zipfile
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from validate_walkscan import _find_dataset_root, _safe_extract, validate_directory


def _read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def _read_odometry(path: Path) -> list[dict]:
    points: list[dict] = []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle, skipinitialspace=True):
            clean = {key.strip(): (value or "").strip() for key, value in row.items()}
            points.append(
                {
                    "frame": clean["frame"],
                    "timestamp": float(clean["timestamp"]),
                    "x": float(clean["x"]),
                    "y": float(clean["y"]),
                    "z": float(clean["z"]),
                }
            )
    return points


def _horizontal_distance(a: dict, b: dict) -> float:
    return math.hypot(b["x"] - a["x"], b["z"] - a["z"])


def _remove_stationary_jitter(points: list[dict], minimum_step: float = 0.015) -> list[dict]:
    if not points:
        return []
    kept = [points[0]]
    for point in points[1:]:
        if _horizontal_distance(kept[-1], point) >= minimum_step:
            kept.append(point)
    return kept


def _smooth(points: list[dict], radius: int = 2) -> list[dict]:
    if len(points) < 3:
        return [dict(point) for point in points]
    result: list[dict] = []
    for index, point in enumerate(points):
        start = max(0, index - radius)
        stop = min(len(points), index + radius + 1)
        window = points[start:stop]
        result.append(
            {
                **point,
                "x": sum(item["x"] for item in window) / len(window),
                "y": sum(item["y"] for item in window) / len(window),
                "z": sum(item["z"] for item in window) / len(window),
            }
        )
    return result


def _add_distance(points: list[dict]) -> list[dict]:
    total = 0.0
    result: list[dict] = []
    for index, point in enumerate(points):
        if index:
            total += _horizontal_distance(points[index - 1], point)
        result.append({**point, "distanceMeters": total})
    return result


def _make_sections(points: list[dict], half_width: float, height: float) -> list[dict]:
    sections: list[dict] = []
    for index, point in enumerate(points):
        previous = points[max(0, index - 1)]
        following = points[min(len(points) - 1, index + 1)]
        dx = following["x"] - previous["x"]
        dz = following["z"] - previous["z"]
        length = math.hypot(dx, dz)
        if length < 1e-6:
            tangent_x, tangent_z = 0.0, -1.0
        else:
            tangent_x, tangent_z = dx / length, dz / length
        normal_x, normal_z = -tangent_z, tangent_x
        left = [
            point["x"] + normal_x * half_width,
            point["y"],
            point["z"] + normal_z * half_width,
        ]
        right = [
            point["x"] - normal_x * half_width,
            point["y"],
            point["z"] - normal_z * half_width,
        ]
        sections.append(
            {
                "distanceMeters": point["distanceMeters"],
                "center": [point["x"], point["y"], point["z"]],
                "tangent": [tangent_x, 0.0, tangent_z],
                "leftFloor": left,
                "rightFloor": right,
                "leftCeiling": [left[0], left[1] + height, left[2]],
                "rightCeiling": [right[0], right[1] + height, right[2]],
            }
        )
    return sections


def _make_faces(section_count: int) -> dict[str, list[list[int]]]:
    floor: list[list[int]] = []
    left_side: list[list[int]] = []
    right_side: list[list[int]] = []
    ceiling: list[list[int]] = []
    for index in range(max(0, section_count - 1)):
        a = index * 4
        b = (index + 1) * 4
        # Vertex order per section: left floor, right floor, left ceiling, right ceiling.
        floor.append([a, b, b + 1, a + 1])
        left_side.append([a, a + 2, b + 2, b])
        right_side.append([a + 1, b + 1, b + 3, a + 3])
        ceiling.append([a + 2, a + 3, b + 3, b + 2])
    return {
        "floor": floor,
        "buildingSideGuide": left_side,
        "roadSideGuide": right_side,
        "canopyGuide": ceiling,
    }


def _read_locations(path: Path) -> list[dict]:
    if not path.is_file():
        return []
    locations: list[dict] = []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle, skipinitialspace=True):
            clean = {key.strip(): (value or "").strip() for key, value in row.items()}
            try:
                locations.append(
                    {
                        "timestamp": float(clean["timestamp"]),
                        "latitude": float(clean["latitude"]),
                        "longitude": float(clean["longitude"]),
                        "horizontalAccuracy": float(clean["horizontal_accuracy"]),
                    }
                )
            except (KeyError, ValueError):
                continue
    return locations


def _approximate_geojson(
    points: list[dict],
    locations: list[dict],
    system_boot_epoch: float | None,
    segment_id: str,
) -> dict | None:
    if not points or not locations or system_boot_epoch is None:
        return None
    anchor_location = min(locations, key=lambda item: item["horizontalAccuracy"])
    anchor_point = min(
        points,
        key=lambda point: abs(
            system_boot_epoch + point["timestamp"] - anchor_location["timestamp"]
        ),
    )
    earth_radius = 6_378_137.0
    anchor_lat_rad = math.radians(anchor_location["latitude"])
    coordinates: list[list[float]] = []
    for point in points:
        east = point["x"] - anchor_point["x"]
        south = point["z"] - anchor_point["z"]
        latitude = anchor_location["latitude"] - math.degrees(south / earth_radius)
        longitude = anchor_location["longitude"] + math.degrees(
            east / (earth_radius * max(math.cos(anchor_lat_rad), 1e-6))
        )
        coordinates.append([longitude, latitude])
    return {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "properties": {
                    "segmentID": segment_id,
                    "positioning": "approximate",
                    "anchorHorizontalAccuracyMeters": anchor_location["horizontalAccuracy"],
                },
                "geometry": {"type": "LineString", "coordinates": coordinates},
            }
        ],
    }


@contextmanager
def open_dataset(path: Path) -> Iterator[Path]:
    if path.is_dir():
        yield _find_dataset_root(path)
        return
    if not zipfile.is_zipfile(path):
        raise ValueError("輸入檔案不是有效的 .walkscan／ZIP")
    with tempfile.TemporaryDirectory(prefix="walkscan-route-") as temp:
        root = Path(temp)
        _safe_extract(path, root)
        yield _find_dataset_root(root)


def build_route(
    dataset_root: Path,
    *,
    half_width: float = 1.2,
    height: float = 3.0,
) -> dict:
    report = validate_directory(dataset_root, metadata_only=True)
    if not report.valid:
        raise ValueError("資料包未通過檢查：" + "；".join(report.errors))
    manifest = _read_json(dataset_root / "mission.json")
    stations = _read_json(dataset_root / "stations.json").get("stations", [])
    raw_points = _read_odometry(dataset_root / "odometry.csv")
    points = _add_distance(_smooth(_remove_stationary_jitter(raw_points)))
    if len(points) < 2:
        raise ValueError("odometry 軌跡點不足，無法建立動線")

    sections = _make_sections(points, half_width=half_width, height=height)
    vertices = [
        vertex
        for section in sections
        for vertex in (
            section["leftFloor"],
            section["rightFloor"],
            section["leftCeiling"],
            section["rightCeiling"],
        )
    ]
    geojson = _approximate_geojson(
        points,
        _read_locations(dataset_root / "locations.csv"),
        manifest.get("systemBootEpochSeconds"),
        report.segment_id,
    )
    return {
        "schemaVersion": 1,
        "source": "WalkScan v2",
        "segmentID": report.segment_id,
        "captureMode": report.capture_mode,
        "coordinateSystem": "ARKit gravityAndHeading: +x east, +y up, +z south, metres",
        "interpretation": {
            "centerline": "smoothed observed camera path",
            "corridorWidth": "provisional guide; replace with LiDAR-estimated sidewalk edges",
            "height": "visual guide; not an engineering measurement",
        },
        "measuredPathMeters": points[-1]["distanceMeters"],
        "guideHalfWidthMeters": half_width,
        "guideHeightMeters": height,
        "centerline": points,
        "sections": sections,
        "mesh": {
            "vertexOrder": ["leftFloor", "rightFloor", "leftCeiling", "rightCeiling"],
            "vertices": vertices,
            "faces": _make_faces(len(sections)),
        },
        "stations": stations,
        "approximateGeoJSON": geojson,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="從 WalkScan 建立自由動線點線面骨架")
    parser.add_argument("input", type=Path, help=".walkscan 檔或已解開的資料夾")
    parser.add_argument("-o", "--output", type=Path, required=True, help="輸出 JSON")
    parser.add_argument("--half-width", type=float, default=1.2, help="暫定半寬，公尺")
    parser.add_argument("--height", type=float, default=3.0, help="暫定顯示高度，公尺")
    args = parser.parse_args()
    try:
        with open_dataset(args.input) as dataset_root:
            result = build_route(
                dataset_root,
                half_width=args.half_width,
                height=args.height,
            )
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"建立失敗：{exc}", file=sys.stderr)
        return 1
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(result, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(
        f"已建立 {result['segmentID']}："
        f"{result['measuredPathMeters']:.1f} 公尺，"
        f"{len(result['centerline'])} 個軌跡點"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
