#!/usr/bin/env python3
"""Validate a Zhubei WalkScan v2 directory or .walkscan ZIP package."""

from __future__ import annotations

import argparse
import csv
import json
import sys
import tempfile
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class ValidationReport:
    source: str
    segment_id: str = ""
    capture_mode: str = ""
    measured_meters: float = 0
    station_count: int = 0
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def valid(self) -> bool:
        return not self.errors

    def as_dict(self) -> dict[str, Any]:
        return {
            "valid": self.valid,
            "source": self.source,
            "segmentID": self.segment_id,
            "captureMode": self.capture_mode,
            "measuredMeters": self.measured_meters,
            "stationCount": self.station_count,
            "errors": self.errors,
            "warnings": self.warnings,
        }


def _load_json(path: Path, report: ValidationReport) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        report.errors.append(f"缺少 {path.name}")
        return {}
    except (OSError, json.JSONDecodeError) as exc:
        report.errors.append(f"{path.name} 無法讀取：{exc}")
        return {}
    if not isinstance(value, dict):
        report.errors.append(f"{path.name} 的最外層必須是物件")
        return {}
    return value


def _find_dataset_root(root: Path) -> Path:
    if (root / "mission.json").is_file():
        return root
    candidates = [path.parent for path in root.rglob("mission.json")]
    if len(candidates) == 1:
        return candidates[0]
    return root


def _safe_extract(archive: Path, destination: Path) -> None:
    destination_resolved = destination.resolve()
    with zipfile.ZipFile(archive) as bundle:
        for member in bundle.infolist():
            target = (destination / member.filename).resolve()
            if destination_resolved not in target.parents and target != destination_resolved:
                raise ValueError(f"封裝含有不安全路徑：{member.filename}")
        bundle.extractall(destination)


def _read_odometry_frames(path: Path, report: ValidationReport) -> set[str]:
    if not path.is_file():
        report.errors.append("缺少 odometry.csv")
        return set()
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            rows = csv.DictReader(handle, skipinitialspace=True)
            if not rows.fieldnames or "frame" not in [name.strip() for name in rows.fieldnames]:
                report.errors.append("odometry.csv 缺少 frame 欄位")
                return set()
            frames = set()
            for row in rows:
                frame = (row.get("frame") or row.get(" frame") or "").strip()
                if frame:
                    frames.add(frame)
            return frames
    except OSError as exc:
        report.errors.append(f"odometry.csv 無法讀取：{exc}")
        return set()


def _check_relative_file(
    dataset_root: Path,
    relative_path: Any,
    label: str,
    station_id: str,
    report: ValidationReport,
    metadata_only: bool,
) -> None:
    if not isinstance(relative_path, str) or not relative_path:
        report.errors.append(f"{station_id} 缺少 {label} 路徑")
        return
    if metadata_only:
        return
    target = (dataset_root / relative_path).resolve()
    root_resolved = dataset_root.resolve()
    if root_resolved not in target.parents:
        report.errors.append(f"{station_id} 的 {label} 路徑超出資料包")
    elif not target.is_file():
        report.errors.append(f"{station_id} 缺少 {relative_path}")


def validate_directory(
    dataset_root: Path,
    *,
    source_label: str | None = None,
    metadata_only: bool = False,
) -> ValidationReport:
    dataset_root = _find_dataset_root(dataset_root)
    report = ValidationReport(source=source_label or str(dataset_root))
    manifest = _load_json(dataset_root / "mission.json", report)
    station_index = _load_json(dataset_root / "stations.json", report)

    report.segment_id = str(manifest.get("segmentID", ""))
    report.capture_mode = str(manifest.get("captureMode", ""))
    try:
        report.measured_meters = float(manifest.get("measuredTravelMeters", 0))
    except (TypeError, ValueError):
        report.errors.append("mission.json 的 measuredTravelMeters 不是數字")

    if manifest.get("schemaVersion") != 2:
        report.errors.append("mission.json 必須使用 WalkScan schemaVersion 2")
    if report.capture_mode not in {"mapped_segment", "free_route"}:
        report.errors.append("captureMode 必須是 mapped_segment 或 free_route")
    if not report.segment_id:
        report.errors.append("mission.json 缺少 segmentID")

    stations = station_index.get("stations", [])
    if not isinstance(stations, list):
        report.errors.append("stations.json 的 stations 必須是陣列")
        stations = []
    report.station_count = len(stations)

    manifest_count = manifest.get("capturedStationCount")
    if manifest_count != report.station_count:
        report.errors.append(
            f"節點數不一致：mission={manifest_count}，stations={report.station_count}"
        )

    spacing = station_index.get("spacingMeters")
    if spacing != 1 and spacing != 1.0:
        report.warnings.append(f"節點間距不是 1 公尺：{spacing}")

    if report.measured_meters >= 1 and not stations:
        report.errors.append("行走距離超過 1 公尺，但沒有任何自動取樣節點")
    elif report.measured_meters < 1 and not stations:
        report.warnings.append("行走距離不足 1 公尺，因此沒有自動取樣節點")

    odometry_frames = _read_odometry_frames(dataset_root / "odometry.csv", report)
    seen_ids: set[str] = set()
    seen_sequences: set[int] = set()
    previous_nominal = 0.0

    for station in stations:
        if not isinstance(station, dict):
            report.errors.append("stations.json 含有非物件節點")
            continue
        station_id = str(station.get("stationID", "未命名節點"))
        sequence = station.get("sequence")
        frame = str(station.get("frame", "")).strip()

        if station_id in seen_ids:
            report.errors.append(f"重複節點編號：{station_id}")
        seen_ids.add(station_id)
        if not isinstance(sequence, int):
            report.errors.append(f"{station_id} 的 sequence 不是整數")
        elif sequence in seen_sequences:
            report.errors.append(f"重複 sequence：{sequence}")
        else:
            seen_sequences.add(sequence)

        try:
            nominal = float(station.get("nominalRouteDistanceMeters"))
            if nominal <= previous_nominal:
                report.errors.append(f"{station_id} 的路徑距離沒有遞增")
            previous_nominal = nominal
        except (TypeError, ValueError):
            report.errors.append(f"{station_id} 缺少 nominalRouteDistanceMeters")

        if frame not in odometry_frames:
            report.errors.append(f"{station_id} 找不到 odometry frame {frame}")

        _check_relative_file(
            dataset_root, station.get("rgbImage"), "彩色照片", station_id, report, metadata_only
        )
        _check_relative_file(
            dataset_root, station.get("depthImage"), "深度圖", station_id, report, metadata_only
        )
        _check_relative_file(
            dataset_root,
            station.get("confidenceImage"),
            "深度可信度",
            station_id,
            report,
            metadata_only,
        )

        position = station.get("cameraPositionMeters")
        quaternion = station.get("cameraQuaternion")
        intrinsics = station.get("cameraIntrinsics")
        if not isinstance(position, list) or len(position) != 3:
            report.errors.append(f"{station_id} 的 cameraPositionMeters 必須有 3 個值")
        if not isinstance(quaternion, list) or len(quaternion) != 4:
            report.errors.append(f"{station_id} 的 cameraQuaternion 必須有 4 個值")
        if not isinstance(intrinsics, list) or len(intrinsics) != 9:
            report.errors.append(f"{station_id} 的 cameraIntrinsics 必須有 9 個值")

    if seen_sequences and seen_sequences != set(range(len(stations))):
        report.errors.append("節點 sequence 必須從 0 連續編號")

    return report


def validate_path(path: Path, *, metadata_only: bool = False) -> ValidationReport:
    if path.is_dir():
        return validate_directory(path, metadata_only=metadata_only)
    if not path.is_file():
        report = ValidationReport(source=str(path))
        report.errors.append("找不到資料包")
        return report
    if not zipfile.is_zipfile(path):
        report = ValidationReport(source=str(path))
        report.errors.append("檔案不是有效的 ZIP／.walkscan 封裝")
        return report
    with tempfile.TemporaryDirectory(prefix="walkscan-") as temp:
        destination = Path(temp)
        try:
            _safe_extract(path, destination)
        except (OSError, ValueError, zipfile.BadZipFile) as exc:
            report = ValidationReport(source=str(path))
            report.errors.append(f"無法解開資料包：{exc}")
            return report
        return validate_directory(
            destination,
            source_label=str(path),
            metadata_only=metadata_only,
        )


def main() -> int:
    parser = argparse.ArgumentParser(description="檢查竹北步行採集 .walkscan 資料包")
    parser.add_argument("path", type=Path, help=".walkscan 檔或已解開的資料夾")
    parser.add_argument("--json", action="store_true", help="輸出 JSON 報告")
    parser.add_argument(
        "--metadata-only",
        action="store_true",
        help="只檢查索引與順序，不要求影像檔存在",
    )
    args = parser.parse_args()
    report = validate_path(args.path, metadata_only=args.metadata_only)

    if args.json:
        print(json.dumps(report.as_dict(), ensure_ascii=False, indent=2))
    else:
        result = "通過" if report.valid else "未通過"
        print(f"WalkScan 檢查：{result}")
        print(f"路段／動線：{report.segment_id or '未知'}")
        print(f"模式：{report.capture_mode or '未知'}")
        print(f"距離：{report.measured_meters:.1f} 公尺；節點：{report.station_count}")
        for warning in report.warnings:
            print(f"提醒：{warning}")
        for error in report.errors:
            print(f"錯誤：{error}")
    return 0 if report.valid else 1


if __name__ == "__main__":
    sys.exit(main())
