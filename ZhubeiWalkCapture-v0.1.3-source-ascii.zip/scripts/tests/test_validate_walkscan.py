import sys
import unittest
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SCRIPT_DIR))

from validate_walkscan import validate_directory
from build_walkscan_route import build_route


class WalkScanValidatorTests(unittest.TestCase):
    fixture_root = Path(__file__).resolve().parent / "fixtures"

    def test_valid_bundle(self) -> None:
        report = validate_directory(self.fixture_root / "valid")
        self.assertTrue(report.valid, report.errors)

    def test_missing_station_image_is_reported(self) -> None:
        report = validate_directory(self.fixture_root / "missing-image")
        self.assertFalse(report.valid)
        self.assertTrue(any("彩色照片" in error or ".jpg" in error for error in report.errors))

    def test_duplicate_sequence_is_reported(self) -> None:
        report = validate_directory(
            self.fixture_root / "duplicate-sequence",
            metadata_only=True,
        )
        self.assertFalse(report.valid)
        self.assertTrue(any("重複 sequence" in error for error in report.errors))

    def test_builds_curved_corridor_skeleton(self) -> None:
        result = build_route(self.fixture_root / "valid")
        self.assertEqual(result["segmentID"], "FREE-TEST")
        self.assertGreaterEqual(len(result["centerline"]), 2)
        self.assertEqual(len(result["mesh"]["vertices"]), len(result["sections"]) * 4)
        self.assertEqual(
            len(result["mesh"]["faces"]["floor"]),
            len(result["sections"]) - 1,
        )


if __name__ == "__main__":
    unittest.main()
