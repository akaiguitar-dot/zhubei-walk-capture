# 在 Windows 將第一版裝進 iPhone 15 Pro

這份流程只適合「你自己的一支手機先做現場測試」。不需要買 Mac，也不需要付 Apple Developer 年費，但免費個人簽章約 7 天後要重新簽署安裝。

## A. 用 GitHub 的 Mac 編譯

1. 在 GitHub 建立一個新的公開 repository，例如 `zhubei-walk-capture`。
2. 只上傳本交付包內的內容。不要把整個 GIS 專案與原始研究資料一起公開。
3. 打開 repository 的 `Actions`。
4. 選擇 `Build Zhubei Walk Capture`。
5. 點 `Run workflow`。
6. 完成後，在該次執行頁面下載 `ZhubeiWalkCapture-unsigned` artifact。
7. 解壓後會得到 `ZhubeiWalkCapture-unsigned.ipa`。

公開 repository 的標準 GitHub-hosted runner 可免費使用。若改用 private repository，會消耗帳號的免費 Actions 額度；超過額度可能產生費用。

## B. 在 Windows 簽署並裝進手機

1. 從 Apple 官方來源安裝 Windows 版 iTunes 與 iCloud。
2. 安裝 Sideloadly。
3. 用傳輸線連接 iPhone，手機上選擇信任這台電腦。
4. 打開 Sideloadly，將 `ZhubeiWalkCapture-unsigned.ipa` 拖入視窗。
5. 選擇你的 iPhone，輸入自己的 Apple Account 後開始簽署安裝。
6. 若手機要求，至「設定 → 隱私權與安全性 → 開發者模式」啟用開發者模式並重開機。
7. 至「設定 → 一般 → VPN 與裝置管理」信任自己的開發者憑證。
8. 打開「竹北步行採集」，允許相機、動作與方向、使用 App 期間的位置權限。

Apple 的免費 Personal Team provisioning profile 有效期為 7 天；到期後 App 不會再開啟，需要重新簽署安裝。現場資料存在 App 文件區，重新安裝前應先匯出所有 `.walkscan`，避免因移除 App 而遺失。

## C. 第一段現場測試

1. 選擇「自由動線」。
2. 名稱輸入 `FREE-TEST-001`。
3. 走一段 3 至 5 公尺、包含一個輕微轉彎的人行道。
4. 手機保持目視高度，依圓圈提示擺正；每公尺會震動並閃一下。
5. 結束後點紅鍵，在最近完成的記錄中選擇「匯出到電腦」。
6. Windows 執行：

```powershell
python scripts/validate_walkscan.py "FREE-TEST-001.walkscan"
python scripts/build_walkscan_route.py "FREE-TEST-001.walkscan" -o "FREE-TEST-001-corridor.json"
```

第一輪只驗證三件事：節點是否每公尺出現、自由轉彎是否保留、點線面骨架是否沿著實際路徑生成。確認資料可靠後，再接網站路段點選與 LiDAR 六立面判讀。
