//
//  RecordSessionViewController.swift
//  Stray Scanner
//
//  Created by Kenneth Blomqvist on 11/28/20.
//  Copyright © 2020 Stray Robots. All rights reserved.
//

import Foundation
import UIKit
import Metal
import ARKit
import CoreData
import CoreMotion
import CoreLocation

let FpsDividers: [Int] = [1, 2, 4, 12, 60]
let AvailableFpsSettings: [Int] = FpsDividers.map { Int(60 / $0) }
let FpsUserDefaultsKey: String = "FPS"

class MetalView : UIView {
    override class var layerClass: AnyClass {
        get {
            return CAMetalLayer.self
        }
    }
    override var layer: CAMetalLayer {
        return super.layer as! CAMetalLayer
    }
}

class RecordSessionViewController : UIViewController, ARSessionDelegate, CLLocationManagerDelegate {
    private var unsupported: Bool = false
    private var arConfiguration: ARWorldTrackingConfiguration?
    private let session = ARSession()
    private let motionManager = CMMotionManager()
    private let locationManager = CLLocationManager()
    private var renderer: CameraRenderer?
    private var updateLabelTimer: Timer?
    private var startedRecording: Date?
    private var dataContext: NSManagedObjectContext!
    private var datasetEncoder: DatasetEncoder?
    private let imuOperationQueue = OperationQueue()
    private var chosenFpsSetting: Int = 0
    private var mission = WalkMission(
        segmentID: "ZB-WALK-UNASSIGNED",
        targetLengthMeters: 20,
        requiresReturnTrip: true,
        captureMode: .mappedSegment
    )
    private var travelledMeters: Double = 0
    private var lastProgressPosition: SIMD3<Float>?
    private var lastProgressSampleTimestamp: TimeInterval = 0
    private var turnWasAnnounced = false
    private var completionWasAnnounced = false
    private let segmentLabel = UILabel()
    private let guidanceLabel = UILabel()
    private let distanceLabel = UILabel()
    private let trackingLabel = UILabel()
    private let aimLabel = UILabel()
    private let missionProgress = UIProgressView(progressViewStyle: .bar)
    private let captureReticle = UIView()
    private var stationFeedbackVisibleUntil: CFTimeInterval = 0
    @IBOutlet private var rgbView: MetalView!
    @IBOutlet private var depthView: MetalView!
    @IBOutlet private var recordButton: RecordButton!
    @IBOutlet private var timeLabel: UILabel!
    @IBOutlet weak var fpsButton: UIButton!
    var dismissFunction: Optional<() -> Void> = Optional.none

    func setMission(_ mission: WalkMission) {
        self.mission = mission
    }
    
    func setDismissFunction(_ fn: Optional<() -> Void>) {
        self.dismissFunction = fn
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        // Five RGB-D frames per second gives several observations per walking metre
        // without producing an unnecessarily large field dataset.
        self.chosenFpsSetting = AvailableFpsSettings.firstIndex(of: 5) ?? 3
        updateFpsSetting()
    }

    override func viewDidLoad() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        self.dataContext = appDelegate.persistentContainer.newBackgroundContext()
        self.renderer = CameraRenderer(rgbLayer: rgbView.layer, depthLayer: depthView.layer)
        self.renderer?.renderMode = .rgb
        rgbView.isHidden = false
        depthView.isHidden = true

        depthView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(viewTapped)))
        rgbView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(viewTapped)))
        
        setViewProperties()
        setupMissionOverlay()
        session.delegate = self
        session.delegateQueue = .main
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.distanceFilter = 1
        locationManager.requestWhenInUseAuthorization()

        recordButton.setCallback { (recording: Bool) in
            self.toggleRecording(recording)
        }
        fpsButton.layer.masksToBounds = true
        fpsButton.layer.cornerRadius = 12.0
        fpsButton.isHidden = true
        
        imuOperationQueue.qualityOfService = .userInitiated
    }

    override func viewDidDisappear(_ animated: Bool) {
        session.pause();
    }

    override func viewWillDisappear(_ animated: Bool) {
        updateLabelTimer?.invalidate()
        datasetEncoder = nil
    }

    override func viewDidAppear(_ animated: Bool) {
        startSession()
    }

    private func startSession() {
        let config = ARWorldTrackingConfiguration()
        // Keep arbitrary walking paths geographically oriented so the Windows
        // importer can align the local corridor with GPS and GIS layers.
        config.worldAlignment = .gravityAndHeading
        arConfiguration = config
        if !ARWorldTrackingConfiguration.isSupported || !ARWorldTrackingConfiguration.supportsFrameSemantics(.sceneDepth) {
            print("AR is not supported.")
            unsupported = true
        } else {
            config.frameSemantics.insert(.sceneDepth)
            session.run(config)
        }
    }
    
    private func startRawIMU() {
        if self.motionManager.isAccelerometerAvailable {
            self.motionManager.accelerometerUpdateInterval = 1.0 / 1200.0 // Set update rate
            self.motionManager.startAccelerometerUpdates(to: imuOperationQueue) { (data, error) in
                guard let data = data else {
                    if let error = error {
                        print("Error retrieving accelerometer data: \(error.localizedDescription)")
                    }
                    return
                }
                self.datasetEncoder?.addRawAccelerometer(data: data)
            }
        } else {
            print("Accelerometer not available on this device.")
        }

        if self.motionManager.isGyroAvailable {
            self.motionManager.gyroUpdateInterval = 1.0 / 1200.0 // Set update rate
            self.motionManager.startGyroUpdates(to: imuOperationQueue) { (data, error) in
                guard let data = data else {
                    if let error = error {
                        print("Error retrieving gyroscope data: \(error.localizedDescription)")
                    }
                    return
                }
                self.datasetEncoder?.addRawGyroscope(data: data)
            }
        } else {
            print("Gyroscope not available on this device.")
        }
    }

    private func stopRawIMU() {
        if self.motionManager.isAccelerometerActive {
            self.motionManager.stopAccelerometerUpdates()
            print("Stopped accelerometer updates.")
        }
        if self.motionManager.isGyroActive {
            self.motionManager.stopGyroUpdates()
            print("Stopped gyroscope updates.")
        }
    }
    
    private func toggleRecording(_ recording: Bool) {
        if unsupported {
            showUnsupportedAlert()
            return
        }
        if recording && self.startedRecording == nil {
            startRecording()
        } else if self.startedRecording != nil && !recording {
            stopRecording()
        } else {
            print("This should not happen. We are either not recording and want to stop, or we are recording and want to start.")
        }
    }

    private func startRecording() {
        self.startedRecording = Date()
        travelledMeters = 0
        lastProgressPosition = nil
        lastProgressSampleTimestamp = 0
        turnWasAnnounced = false
        completionWasAnnounced = false
        missionProgress.progress = 0
        aimLabel.text = "將圓圈對準前方，手機保持平穩"
        if mission.captureMode == .freeRoute {
            guidanceLabel.text = "沿想記錄的動線行走，結束時再按紅鍵"
            missionProgress.isHidden = true
        } else {
            guidanceLabel.text = "沿人行道向前走，手機維持目視高度"
            missionProgress.isHidden = false
        }
        updateTime()
        updateLabelTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            self.updateTime()
        }
        datasetEncoder = DatasetEncoder(
            arConfiguration: arConfiguration!,
            fpsDivider: FpsDividers[chosenFpsSetting],
            mission: mission
        )
        locationManager.startUpdatingLocation()
        startRawIMU()
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
    }

    private func stopRecording() {
        guard let started = self.startedRecording else {
            print("Hasn't started recording. Something is wrong.")
            return
        }
        startedRecording = nil
        updateLabelTimer?.invalidate()
        updateLabelTimer = nil
        // Stop IMU updates
        stopRawIMU()
        locationManager.stopUpdatingLocation()
        datasetEncoder?.wrapUp(travelDistance: travelledMeters)
        if let encoder = datasetEncoder {
            switch encoder.status {
                case .allGood:
                    saveRecording(started, encoder)
                case .videoEncodingError:
                    showError()
                case .directoryCreationError:
                    showError()
            }
        } else {
            print("No dataset encoder. Something is wrong.")
        }
        self.dismissFunction?()
    }

    private func saveRecording(_ started: Date, _ encoder: DatasetEncoder) {
        let duration = Date().timeIntervalSince(started)
        let entity = NSEntityDescription.entity(forEntityName: "Recording", in: self.dataContext)!
        let recording: Recording = Recording(entity: entity, insertInto: self.dataContext)
        recording.setValue(datasetEncoder!.id, forKey: "id")
        recording.setValue(duration, forKey: "duration")
        recording.setValue(started, forKey: "createdAt")
        recording.setValue(mission.segmentID, forKey: "name")
        recording.setValue(datasetEncoder!.rgbFilePath.relativeString, forKey: "rgbFilePath")
        recording.setValue(datasetEncoder!.depthFilePath.relativeString, forKey: "depthFilePath")
        do {
            try self.dataContext.save()
        } catch let error as NSError {
            print("Could not save recording. \(error), \(error.userInfo)")
        }
    }

    private func showError() {
        let controller = UIAlertController(title: "Error",
            message: "Something went wrong when encoding video. This should not have happened. You might want to file a bug report.",
            preferredStyle: .alert)
        controller.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default Action"), style: .default, handler: { _ in
            self.dismiss(animated: true, completion: nil)
        }))
        self.present(controller, animated: true, completion: nil)
    }

    private func updateTime() {
        guard let started = self.startedRecording else { return }
        let seconds = Date().timeIntervalSince(started)
        let minutes: Int = Int(floor(seconds / 60).truncatingRemainder(dividingBy: 60))
        let hours: Int = Int(floor(seconds / 3600))
        let roundSeconds: Int = Int(floor(seconds.truncatingRemainder(dividingBy: 60)))
        self.timeLabel.text = String(format: "%02d:%02d:%02d", hours, minutes, roundSeconds)
    }

    @objc func viewTapped() {
        switch renderer!.renderMode {
            case .depth:
                renderer!.renderMode = RenderMode.rgb
                rgbView.isHidden = false
                depthView.isHidden = true
            case .rgb:
                renderer!.renderMode = RenderMode.depth
                depthView.isHidden = false
                rgbView.isHidden = true
        }
    }
    
    @IBAction func fpsButtonTapped() {
        chosenFpsSetting = (chosenFpsSetting + 1) % AvailableFpsSettings.count
        updateFpsSetting()
        UserDefaults.standard.set(chosenFpsSetting, forKey: FpsUserDefaultsKey)
    }

    func session(_ session: ARSession, didUpdate frame: ARFrame) {
        self.renderer!.render(frame: frame)
        updateTrackingLabel(frame.camera.trackingState)
        updateAimGuide(frame.camera)
        if startedRecording != nil {
            updateMissionProgress(frame: frame)
            if let encoder = datasetEncoder {
                if let stationSequence = encoder.add(
                    frame: frame,
                    travelDistance: travelledMeters
                ) {
                    announceStationCapture(sequence: stationSequence)
                }
            } else {
                print("There is no video encoder. That can't be good.")
            }
        }
    }

    private func setViewProperties() {
        self.view.backgroundColor = UIColor(named: "BackgroundColor")
    }

    private func setupMissionOverlay() {
        let blur = UIVisualEffectView(effect: UIBlurEffect(style: .systemThinMaterialDark))
        blur.translatesAutoresizingMaskIntoConstraints = false
        blur.layer.cornerRadius = 18
        blur.clipsToBounds = true

        segmentLabel.translatesAutoresizingMaskIntoConstraints = false
        segmentLabel.font = .systemFont(ofSize: 14, weight: .semibold)
        segmentLabel.textColor = .white
        segmentLabel.text = mission.segmentID

        guidanceLabel.translatesAutoresizingMaskIntoConstraints = false
        guidanceLabel.font = .systemFont(ofSize: 18, weight: .bold)
        guidanceLabel.textColor = .white
        guidanceLabel.numberOfLines = 2
        guidanceLabel.text = "點下方紅鍵開始採集"

        distanceLabel.translatesAutoresizingMaskIntoConstraints = false
        distanceLabel.font = .monospacedDigitSystemFont(ofSize: 15, weight: .medium)
        distanceLabel.textColor = .white
        distanceLabel.text = mission.captureMode == .freeRoute
            ? "已記錄 0.0 公尺"
            : "0.0 / \(String(format: "%.0f", mission.expectedTravelMeters)) 公尺"

        trackingLabel.translatesAutoresizingMaskIntoConstraints = false
        trackingLabel.font = .systemFont(ofSize: 12, weight: .medium)
        trackingLabel.textColor = .systemYellow
        trackingLabel.text = "正在建立空間定位…"

        aimLabel.translatesAutoresizingMaskIntoConstraints = false
        aimLabel.font = .systemFont(ofSize: 12, weight: .medium)
        aimLabel.textColor = .white
        aimLabel.text = "將圓圈對準前方，手機保持平穩"

        missionProgress.translatesAutoresizingMaskIntoConstraints = false
        missionProgress.trackTintColor = UIColor.white.withAlphaComponent(0.2)
        missionProgress.progressTintColor = .systemGreen
        missionProgress.layer.cornerRadius = 3
        missionProgress.clipsToBounds = true

        let stack = UIStackView(arrangedSubviews: [
            segmentLabel,
            guidanceLabel,
            distanceLabel,
            missionProgress,
            trackingLabel,
            aimLabel
        ])
        stack.axis = .vertical
        stack.spacing = 7
        stack.translatesAutoresizingMaskIntoConstraints = false
        blur.contentView.addSubview(stack)
        view.addSubview(blur)

        captureReticle.translatesAutoresizingMaskIntoConstraints = false
        captureReticle.layer.borderWidth = 3
        captureReticle.layer.borderColor = UIColor.systemGreen.cgColor
        captureReticle.layer.cornerRadius = 34
        captureReticle.backgroundColor = UIColor.clear
        view.addSubview(captureReticle)

        let arrow = UIImageView(image: UIImage(systemName: "arrow.up"))
        arrow.translatesAutoresizingMaskIntoConstraints = false
        arrow.tintColor = .systemGreen
        arrow.contentMode = .scaleAspectFit
        captureReticle.addSubview(arrow)

        NSLayoutConstraint.activate([
            blur.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 12),
            blur.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 14),
            blur.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -14),

            stack.topAnchor.constraint(equalTo: blur.contentView.topAnchor, constant: 14),
            stack.leadingAnchor.constraint(equalTo: blur.contentView.leadingAnchor, constant: 16),
            stack.trailingAnchor.constraint(equalTo: blur.contentView.trailingAnchor, constant: -16),
            stack.bottomAnchor.constraint(equalTo: blur.contentView.bottomAnchor, constant: -14),
            missionProgress.heightAnchor.constraint(equalToConstant: 6),

            captureReticle.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            captureReticle.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -40),
            captureReticle.widthAnchor.constraint(equalToConstant: 68),
            captureReticle.heightAnchor.constraint(equalToConstant: 68),

            arrow.centerXAnchor.constraint(equalTo: captureReticle.centerXAnchor),
            arrow.centerYAnchor.constraint(equalTo: captureReticle.centerYAnchor),
            arrow.widthAnchor.constraint(equalToConstant: 28),
            arrow.heightAnchor.constraint(equalToConstant: 28)
        ])
    }

    private func updateMissionProgress(frame: ARFrame) {
        guard frame.timestamp - lastProgressSampleTimestamp >= 0.25 else { return }
        lastProgressSampleTimestamp = frame.timestamp

        let transform = frame.camera.transform
        let current = SIMD3<Float>(
            transform.columns.3.x,
            0,
            transform.columns.3.z
        )
        defer { lastProgressPosition = current }
        guard let previous = lastProgressPosition else { return }

        let step = simd_distance(current, previous)
        // Ignore tracking jitter and implausible relocalisation jumps.
        guard step >= 0.02, step <= 0.75 else { return }
        travelledMeters += Double(step)

        if mission.captureMode == .freeRoute {
            distanceLabel.text = String(format: "已記錄 %.1f 公尺", travelledMeters)
            guidanceLabel.text = "自由採集中；沿路轉彎也會保存"
            return
        }

        let expected = max(mission.expectedTravelMeters, 0.1)
        let progress = min(Float(travelledMeters / expected), 1)
        missionProgress.setProgress(progress, animated: true)
        distanceLabel.text = String(
            format: "%.1f / %.0f 公尺",
            travelledMeters,
            expected
        )

        if !completionWasAnnounced,
           travelledMeters >= expected {
            completionWasAnnounced = true
            guidanceLabel.text = "往返完成，點下方紅鍵結束並歸檔"
            missionProgress.progressTintColor = .systemCyan
            UINotificationFeedbackGenerator().notificationOccurred(.success)
        } else if mission.requiresReturnTrip,
                  !turnWasAnnounced,
                  travelledMeters >= mission.targetLengthMeters {
            turnWasAnnounced = true
            guidanceLabel.text = "已到端點，請轉身沿原路返回"
            UINotificationFeedbackGenerator().notificationOccurred(.warning)
        } else if completionWasAnnounced {
            guidanceLabel.text = "往返完成，點下方紅鍵結束並歸檔"
        } else if mission.requiresReturnTrip && turnWasAnnounced {
            guidanceLabel.text = "沿原路返回起點"
        }
    }

    private func updateTrackingLabel(_ state: ARCamera.TrackingState) {
        switch state {
        case .normal:
            trackingLabel.text = "LiDAR 與空間定位正常"
            trackingLabel.textColor = .systemGreen
        case .limited(let reason):
            trackingLabel.textColor = .systemYellow
            switch reason {
            case .excessiveMotion:
                trackingLabel.text = "請放慢移動速度"
            case .insufficientFeatures:
                trackingLabel.text = "請讓畫面包含地面與周邊物件"
            case .initializing, .relocalizing:
                trackingLabel.text = "正在建立空間定位…"
            @unknown default:
                trackingLabel.text = "定位品質受限，請慢慢移動"
            }
        case .notAvailable:
            trackingLabel.text = "暫時無法定位"
            trackingLabel.textColor = .systemRed
        }
    }

    private func updateAimGuide(_ camera: ARCamera) {
        guard CACurrentMediaTime() >= stationFeedbackVisibleUntil else { return }
        let pitch = abs(camera.eulerAngles.x)
        let roll = abs(camera.eulerAngles.z)
        let isReady = pitch <= 0.55 && roll <= 0.35

        if roll > 0.35 {
            aimLabel.text = "請把手機擺正，避免左右傾斜"
            aimLabel.textColor = .systemYellow
        } else if pitch > 0.55 {
            aimLabel.text = "請讓鏡頭接近水平，保留前方與地面"
            aimLabel.textColor = .systemYellow
        } else {
            aimLabel.text = startedRecording == nil
                ? "方向良好，按紅鍵後開始"
                : "方向良好；每 1 公尺自動拍攝"
            aimLabel.textColor = .systemGreen
        }

        captureReticle.layer.borderColor = (
            isReady ? UIColor.systemGreen : UIColor.systemYellow
        ).cgColor
    }

    private func announceStationCapture(sequence: Int) {
        let count = sequence + 1
        stationFeedbackVisibleUntil = CACurrentMediaTime() + 0.8
        aimLabel.text = "已自動拍下第 \(count) 個空間節點"
        aimLabel.textColor = .systemCyan
        UIImpactFeedbackGenerator(style: .light).impactOccurred()

        UIView.animate(
            withDuration: 0.08,
            animations: {
                self.captureReticle.backgroundColor = UIColor.white.withAlphaComponent(0.65)
                self.captureReticle.transform = CGAffineTransform(scaleX: 1.12, y: 1.12)
            },
            completion: { _ in
                UIView.animate(withDuration: 0.18) {
                    self.captureReticle.backgroundColor = .clear
                    self.captureReticle.transform = .identity
                }
            }
        )
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        locations.forEach { datasetEncoder?.add(location: $0) }
    }
    
    private func updateFpsSetting() {
        let fps = AvailableFpsSettings[chosenFpsSetting]
        let buttonLabel: String = "\(fps) fps"
        fpsButton.setTitle(buttonLabel, for: UIControl.State.normal)
    }
    
    private func showUnsupportedAlert() {
        let alert = UIAlertController(title: "Unsupported device", message: "This device doesn't seem to have the required level of ARKit support.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
            self.dismissFunction?()
        }))
        self.present(alert, animated: true)
    }
    
    private func countSessions() -> Int {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return 0 }
        let request = NSFetchRequest<NSManagedObject>(entityName: "Recording")
        do {
            let fetched: [NSManagedObject] = try appDelegate.persistentContainer.viewContext.fetch(request)
            return fetched.count
        } catch let error {
            print("Could not fetch sessions for counting. \(error.localizedDescription)")
        }
        return 0
    }
}
