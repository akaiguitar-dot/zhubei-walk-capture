//
//  DatasetEncoder.swift
//  StrayScanner
//
//  Created by Kenneth Blomqvist on 1/2/21.
//  Copyright © 2021 Stray Robots. All rights reserved.
//

import Foundation
import ARKit
import CryptoKit
import CoreMotion
import CoreLocation
import CoreImage
import UIKit

private struct LocationSample: Codable {
    let timestamp: Double
    let latitude: Double
    let longitude: Double
    let altitude: Double
    let horizontalAccuracy: Double
    let verticalAccuracy: Double
    let speed: Double
    let course: Double

    init(location: CLLocation) {
        timestamp = location.timestamp.timeIntervalSince1970
        latitude = location.coordinate.latitude
        longitude = location.coordinate.longitude
        altitude = location.altitude
        horizontalAccuracy = location.horizontalAccuracy
        verticalAccuracy = location.verticalAccuracy
        speed = location.speed
        course = location.course
    }
}

private struct WalkScanManifest: Codable {
    let schemaVersion: Int
    let source: String
    let captureMode: String
    let segmentID: String
    let targetLengthMeters: Double
    let expectedTravelMeters: Double
    let measuredTravelMeters: Double
    let requiresReturnTrip: Bool
    let stationSpacingMeters: Double
    let capturedStationCount: Int
    let systemBootEpochSeconds: Double
    let odometryTimestampTimebase: String
    let captureStartedAt: Date
    let captureCompletedAt: Date
    let capturedFrameRate: Int
    let deviceModel: String
    let operatingSystem: String
    let contents: [String]
}

private struct WalkStation: Codable {
    let stationID: String
    let sequence: Int
    let direction: String
    let legIndex: Int
    let legDistanceMeters: Double
    let nominalRouteDistanceMeters: Double
    let measuredRouteDistanceMeters: Double
    let frame: String
    let frameTimestamp: Double
    let capturedAtEpochSeconds: Double
    let rgbImage: String
    let depthImage: String
    let confidenceImage: String
    let trackingQuality: String
    let imageWidthPixels: Int
    let imageHeightPixels: Int
    let cameraPositionMeters: [Float]
    let cameraQuaternion: [Float]
    let cameraEulerRadians: [Float]
    let cameraIntrinsics: [Float]
}

private struct WalkStationIndex: Codable {
    let schemaVersion: Int
    let spacingMeters: Double
    let coordinateSystem: String
    let imageOrientation: String
    let stations: [WalkStation]
}

class DatasetEncoder {
    enum Status {
        case allGood
        case videoEncodingError
        case directoryCreationError
    }
    private let rgbEncoder: VideoEncoder
    private let depthEncoder: DepthEncoder
    private let confidenceEncoder: ConfidenceEncoder
    private let datasetDirectory: URL
    private let odometryEncoder: OdometryEncoder
    private let imuEncoder: IMUEncoder
    private let distortionEncoder: DistortionEncoder
    private let mission: WalkMission
    private let stationDirectory: URL
    private let stationImageContext = CIContext(options: [.cacheIntermediates: false])
    private let stationSpacingMeters: Double = 1.0
    private let systemBootEpochSeconds =
        Date().timeIntervalSince1970 - ProcessInfo.processInfo.systemUptime
    private let captureStartedAt = Date()
    private let capturedFrameRate: Int
    private let locationLock = NSLock()
    private var locationSamples: [LocationSample] = []
    private var lastFrame: ARFrame?
    private var dispatchGroup = DispatchGroup()
    private var currentFrame: Int = -1
    private var savedFrames: Int = 0
    private var nextStationDistanceMeters: Double = 1.0
    private var reservedStationCount: Int = 0
    private var stationSamples: [WalkStation] = []
    private let frameInterval: Int // Only save every frameInterval-th frame.
    private let encodingSemaphore = DispatchSemaphore(value: 3) // Limit queued frames to avoid ARFrame retention
    public let id: UUID
    public let rgbFilePath: URL // Relative to app document directory.
    public let depthFilePath: URL // Relative to app document directory.
    public let cameraMatrixPath: URL
    public let odometryPath: URL
    public let imuPath: URL
    public var status = Status.allGood
    private let queue: DispatchQueue
    
    private var latestAccelerometerData: (timestamp: Double, data: simd_double3)?
    private var latestGyroscopeData: (timestamp: Double, data: simd_double3)?


    init(arConfiguration: ARWorldTrackingConfiguration, fpsDivider: Int = 1, mission: WalkMission) {
        self.frameInterval = fpsDivider
        self.capturedFrameRate = max(1, Int(60 / fpsDivider))
        self.mission = mission
        self.queue = DispatchQueue(label: "encoderQueue")
        
        let width = arConfiguration.videoFormat.imageResolution.width
        let height = arConfiguration.videoFormat.imageResolution.height
        var theId: UUID = UUID()
        datasetDirectory = DatasetEncoder.createDirectory(id: &theId)
        self.id = theId
        self.rgbFilePath = datasetDirectory.appendingPathComponent("rgb.mp4")
        self.rgbEncoder = VideoEncoder(file: self.rgbFilePath, width: width, height: height)
        self.depthFilePath = datasetDirectory.appendingPathComponent("depth", isDirectory: true)
        self.depthEncoder = DepthEncoder(outDirectory: self.depthFilePath)
        let confidenceFilePath = datasetDirectory.appendingPathComponent("confidence", isDirectory: true)
        self.confidenceEncoder = ConfidenceEncoder(outDirectory: confidenceFilePath)
        self.cameraMatrixPath = datasetDirectory.appendingPathComponent("camera_matrix.csv", isDirectory: false)
        self.odometryPath = datasetDirectory.appendingPathComponent("odometry.csv", isDirectory: false)
        self.odometryEncoder = OdometryEncoder(url: self.odometryPath)
        self.imuPath = datasetDirectory.appendingPathComponent("imu.csv", isDirectory: false)
        self.imuEncoder = IMUEncoder(url: self.imuPath)
        self.distortionEncoder = DistortionEncoder(datasetDirectory: datasetDirectory)
        self.stationDirectory = datasetDirectory.appendingPathComponent("stations", isDirectory: true)
        do {
            try FileManager.default.createDirectory(
                at: stationDirectory,
                withIntermediateDirectories: true,
                attributes: nil
            )
        } catch {
            print("Could not create station directory. \(error.localizedDescription)")
        }
    }

    @discardableResult
    func add(frame: ARFrame, travelDistance: Double) -> Int? {
        currentFrame = currentFrame + 1
        if (currentFrame % frameInterval != 0) {
            return nil
        }
        // Drop frame if encoding is backed up to avoid accumulating ARFrame references.
        guard encodingSemaphore.wait(timeout: .now()) == .success else {
            return nil
        }
        let frameNumber: Int = savedFrames
        savedFrames = savedFrames + 1
        let stationReservation = isFrameReadyForStation(frame)
            ? reserveStationIfNeeded(
                travelDistance: travelDistance,
                frameNumber: frameNumber
            )
            : nil
        dispatchGroup.enter()
        queue.async {
            defer {
                self.encodingSemaphore.signal()
                self.dispatchGroup.leave()
            }
            if let sceneDepth = frame.sceneDepth {
                self.depthEncoder.encodeFrame(frame: sceneDepth.depthMap, frameNumber: frameNumber)
                if let confidence = sceneDepth.confidenceMap {
                    self.confidenceEncoder.encodeFrame(frame: confidence, frameNumber: frameNumber)
                } else {
                    print("warning: confidence map missing.")
                }
            } else {
                print("warning: scene depth missing.")
            }
            self.rgbEncoder.add(
                frame: VideoEncoderInput(buffer: frame.capturedImage, time: frame.timestamp),
                currentFrame: frameNumber
            )
            self.odometryEncoder.add(frame: frame, currentFrame: frameNumber)
            self.distortionEncoder.add(frame: frame, currentFrame: frameNumber)
            if let reservation = stationReservation {
                self.encodeStation(frame: frame, reservation: reservation)
            }
            self.lastFrame = frame
        }
        return stationReservation?.sequence
    }

    private func isFrameReadyForStation(_ frame: ARFrame) -> Bool {
        guard case .normal = frame.camera.trackingState else { return false }
        let euler = frame.camera.eulerAngles
        return abs(euler.x) <= 0.55 && abs(euler.z) <= 0.35
    }

    private struct StationReservation {
        let sequence: Int
        let nominalRouteDistanceMeters: Double
        let measuredRouteDistanceMeters: Double
        let frameNumber: Int
    }

    private func reserveStationIfNeeded(
        travelDistance: Double,
        frameNumber: Int
    ) -> StationReservation? {
        guard travelDistance + 0.05 >= nextStationDistanceMeters else { return nil }

        let reservation = StationReservation(
            sequence: reservedStationCount,
            nominalRouteDistanceMeters: nextStationDistanceMeters,
            measuredRouteDistanceMeters: travelDistance,
            frameNumber: frameNumber
        )
        reservedStationCount += 1
        nextStationDistanceMeters += stationSpacingMeters
        return reservation
    }

    private func encodeStation(frame: ARFrame, reservation: StationReservation) {
        let frameName = String(format: "%06d", reservation.frameNumber)
        let direction: String
        let legIndex: Int
        let legDistance: Double
        let legCode: String

        if mission.captureMode == .freeRoute {
            direction = "free"
            legIndex = 0
            legDistance = reservation.nominalRouteDistanceMeters
            legCode = "P"
        } else if mission.requiresReturnTrip &&
                    reservation.nominalRouteDistanceMeters > mission.targetLengthMeters {
            direction = "return"
            legIndex = 1
            legDistance = reservation.nominalRouteDistanceMeters - mission.targetLengthMeters
            legCode = "R"
        } else {
            direction = "outbound"
            legIndex = 0
            legDistance = reservation.nominalRouteDistanceMeters
            legCode = "F"
        }

        let safeSegmentID = mission.segmentID.replacingOccurrences(
            of: "[^A-Za-z0-9_-]",
            with: "-",
            options: .regularExpression
        )
        let legSequence = max(1, Int(round(legDistance / stationSpacingMeters)))
        let stationID = "\(safeSegmentID)-\(legCode)-\(String(format: "%03d", legSequence))"
        let imageFilename = "station-\(String(format: "%06d", reservation.sequence)).jpg"
        let relativeImagePath = "stations/\(imageFilename)"
        let imageURL = stationDirectory.appendingPathComponent(imageFilename)
        let sourceImage = CIImage(cvPixelBuffer: frame.capturedImage)

        do {
            if let jpegData = stationImageContext.jpegRepresentation(
                of: sourceImage,
                colorSpace: CGColorSpaceCreateDeviceRGB(),
                options: [:]
            ) {
                try jpegData.write(to: imageURL, options: .atomic)
            } else {
                print("Could not create JPEG for station \(stationID).")
            }
        } catch {
            print("Could not save station \(stationID). \(error.localizedDescription)")
        }

        let transform = frame.camera.transform
        let position = transform.columns.3
        let quaternion = simd_quatf(transform).vector
        let euler = frame.camera.eulerAngles
        let intrinsics = frame.camera.intrinsics

        stationSamples.append(WalkStation(
            stationID: stationID,
            sequence: reservation.sequence,
            direction: direction,
            legIndex: legIndex,
            legDistanceMeters: legDistance,
            nominalRouteDistanceMeters: reservation.nominalRouteDistanceMeters,
            measuredRouteDistanceMeters: reservation.measuredRouteDistanceMeters,
            frame: frameName,
            frameTimestamp: frame.timestamp,
            capturedAtEpochSeconds: systemBootEpochSeconds + frame.timestamp,
            rgbImage: relativeImagePath,
            depthImage: "depth/\(frameName).png",
            confidenceImage: "confidence/\(frameName).png",
            trackingQuality: trackingQuality(frame.camera.trackingState),
            imageWidthPixels: CVPixelBufferGetWidth(frame.capturedImage),
            imageHeightPixels: CVPixelBufferGetHeight(frame.capturedImage),
            cameraPositionMeters: [position.x, position.y, position.z],
            cameraQuaternion: [quaternion.x, quaternion.y, quaternion.z, quaternion.w],
            cameraEulerRadians: [euler.x, euler.y, euler.z],
            cameraIntrinsics: [
                intrinsics.columns.0.x, intrinsics.columns.0.y, intrinsics.columns.0.z,
                intrinsics.columns.1.x, intrinsics.columns.1.y, intrinsics.columns.1.z,
                intrinsics.columns.2.x, intrinsics.columns.2.y, intrinsics.columns.2.z
            ]
        ))
    }

    private func trackingQuality(_ state: ARCamera.TrackingState) -> String {
        switch state {
        case .normal:
            return "normal"
        case .notAvailable:
            return "not_available"
        case .limited(let reason):
            switch reason {
            case .excessiveMotion:
                return "limited_excessive_motion"
            case .insufficientFeatures:
                return "limited_insufficient_features"
            case .initializing:
                return "limited_initializing"
            case .relocalizing:
                return "limited_relocalizing"
            @unknown default:
                return "limited_unknown"
            }
        }
    }
    
   func addRawAccelerometer(data: CMAccelerometerData) {
        let acceleration = simd_double3(data.acceleration.x, data.acceleration.y, data.acceleration.z)
        latestAccelerometerData = (timestamp: data.timestamp, data: acceleration)
        tryWritingIMUData()
    }

    func addRawGyroscope(data: CMGyroData) {
        let rotationRate = simd_double3(data.rotationRate.x, data.rotationRate.y, data.rotationRate.z)
        latestGyroscopeData = (timestamp: data.timestamp, data: rotationRate)
        tryWritingIMUData()
    }

    private func tryWritingIMUData() {
        guard
            let accelerometer = latestAccelerometerData,
            let gyroscope = latestGyroscopeData
        else {
            return
        }

        // Write the row to the CSV with the most recent timestamp
        let timestamp = max(accelerometer.timestamp, gyroscope.timestamp)
        imuEncoder.add(
            timestamp: timestamp,
            linear: accelerometer.data,
            angular: gyroscope.data
        )

        // Clear the buffers after writing
        latestAccelerometerData = nil
        latestGyroscopeData = nil
    }

    func add(location: CLLocation) {
        guard location.horizontalAccuracy >= 0 else { return }
        locationLock.lock()
        locationSamples.append(LocationSample(location: location))
        locationLock.unlock()
    }

    func wrapUp(travelDistance: Double) {
        dispatchGroup.wait()
        self.rgbEncoder.finishEncoding()
        self.imuEncoder.done()
        self.odometryEncoder.done()
        self.distortionEncoder.done()
        writeIntrinsics()
        writeStationIndex()
        writeMissionManifest(travelDistance: travelDistance)
        writeLocations()
        status = .allGood
        switch self.rgbEncoder.status {
            case .allGood:
                break
            case .error:
                status = .videoEncodingError
        }
        switch self.depthEncoder.status {
            case .allGood:
                break
            case .frameEncodingError:
                status = .videoEncodingError
                print("Something went wrong encoding depth.")
        }
        switch self.confidenceEncoder.status {
            case .allGood:
                break
            case .encodingError:
                status = .videoEncodingError
                print("Something went wrong encoding confidence values.")
        }
    }

    private func writeMissionManifest(travelDistance: Double) {
        let manifest = WalkScanManifest(
            schemaVersion: 2,
            source: "ZhubeiWalkCapture",
            captureMode: mission.captureMode.rawValue,
            segmentID: mission.segmentID,
            targetLengthMeters: mission.targetLengthMeters,
            expectedTravelMeters: mission.expectedTravelMeters,
            measuredTravelMeters: travelDistance,
            requiresReturnTrip: mission.requiresReturnTrip,
            stationSpacingMeters: stationSpacingMeters,
            capturedStationCount: stationSamples.count,
            systemBootEpochSeconds: systemBootEpochSeconds,
            odometryTimestampTimebase: "seconds_since_system_boot",
            captureStartedAt: captureStartedAt,
            captureCompletedAt: Date(),
            capturedFrameRate: capturedFrameRate,
            deviceModel: UIDevice.current.model,
            operatingSystem: "\(UIDevice.current.systemName) \(UIDevice.current.systemVersion)",
            contents: [
                "rgb.mp4",
                "depth/*.png",
                "confidence/*.png",
                "odometry.csv",
                "imu.csv",
                "locations.csv",
                "camera_matrix.csv",
                "stations.json",
                "stations/*.jpg"
            ]
        )
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        do {
            let data = try encoder.encode(manifest)
            try data.write(to: datasetDirectory.appendingPathComponent("mission.json"), options: .atomic)
        } catch {
            print("Could not write mission manifest. \(error.localizedDescription)")
        }
    }

    private func writeStationIndex() {
        let index = WalkStationIndex(
            schemaVersion: 1,
            spacingMeters: stationSpacingMeters,
            coordinateSystem: "ARKit gravityAndHeading: +x east, +y up, +z south, metres",
            imageOrientation: "native camera sensor orientation; use intrinsics without rotating pixels",
            stations: stationSamples.sorted { $0.sequence < $1.sequence }
        )
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        do {
            let data = try encoder.encode(index)
            try data.write(
                to: datasetDirectory.appendingPathComponent("stations.json"),
                options: .atomic
            )
        } catch {
            print("Could not write station index. \(error.localizedDescription)")
        }
    }

    private func writeLocations() {
        locationLock.lock()
        let samples = locationSamples
        locationLock.unlock()

        var lines = [
            "timestamp,latitude,longitude,altitude,horizontal_accuracy,vertical_accuracy,speed,course"
        ]
        lines.append(contentsOf: samples.map {
            "\($0.timestamp),\($0.latitude),\($0.longitude),\($0.altitude),\($0.horizontalAccuracy),\($0.verticalAccuracy),\($0.speed),\($0.course)"
        })
        do {
            try lines.joined(separator: "\n").write(
                to: datasetDirectory.appendingPathComponent("locations.csv"),
                atomically: true,
                encoding: .utf8
            )
        } catch {
            print("Could not write locations. \(error.localizedDescription)")
        }
    }

    private func writeIntrinsics() {
        if let cameraMatrix = lastFrame?.camera.intrinsics {
            let rows = cameraMatrix.transpose.columns
            var csv: [String] = []
            for row in [rows.0, rows.1, rows.2] {
                let csvLine = "\(row.x), \(row.y), \(row.z)"
                csv.append(csvLine)
            }
            let contents = csv.joined(separator: "\n")
            do {
                try contents.write(to: self.cameraMatrixPath, atomically: true, encoding: String.Encoding.utf8)
            } catch let error {
                print("Could not write camera matrix. \(error.localizedDescription)")
            }
        }
    }

    static private func createDirectory(id: inout UUID) -> URL {
        let directoryId = hashUUID(id: id)
        let url = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        var directory = URL(fileURLWithPath: directoryId, relativeTo: url)
        if FileManager.default.fileExists(atPath: directory.absoluteString) {
            // Just in case the first 5 characters clash, try again.
            id = UUID()
            directory = DatasetEncoder.createDirectory(id: &id)
        }
        do {
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true, attributes: nil)
        } catch let error as NSError {
            print("Error creating directory. \(error), \(error.userInfo)")
        }
        return directory
    }

    static private func hashUUID(id: UUID) -> String {
        var hasher: SHA256 = SHA256()
        hasher.update(data: id.uuidString.data(using: .ascii)!)
        let digest = hasher.finalize()
        var string = ""
        digest.makeIterator().prefix(5).forEach { (byte: UInt8) in
            string += String(format: "%02x", byte)
        }
        print("Hash: \(string)")
        return string
    }
}
