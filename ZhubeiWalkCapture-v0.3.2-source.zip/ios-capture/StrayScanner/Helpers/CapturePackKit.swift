import Foundation
import CryptoKit
import CoreLocation
import MapKit

struct CapturePackManifest: Codable, Equatable {
    struct Policy: Codable, Equatable {
        let nominalSpacingMeters: Double
        let policyID: String
    }

    let schema: String
    let datasetID: String
    let datasetRevisionID: String
    let immutable: Bool
    let status: String
    let hashPolicy: String
    let capturePolicy: Policy
    let files: [String: String]
}

struct CaptureAxisFeature: Identifiable {
    let datasetID: String
    let datasetRevisionID: String
    let featureID: String
    let subsegmentID: String
    let geometryRevisionID: String
    let geometryHash: String
    let status: String
    let captureEligible: Bool
    let axisStartNodeID: String
    let axisEndNodeID: String
    let axisLengthMm: Int
    let vertexChainageMm: [Int]
    let axis: [CLLocationCoordinate2D]
    let polygonRings: [[CLLocationCoordinate2D]]

    var id: String { "\(datasetRevisionID)/\(geometryRevisionID)" }
    var isDemo: Bool { status == "demo_pending_field_confirmation" }
}

struct VerifiedCapturePack {
    let manifest: CapturePackManifest
    let features: [CaptureAxisFeature]
    let sourceDirectory: URL
}

enum CapturePackError: Error, LocalizedError, Equatable {
    case missingFile(String)
    case unsupportedPolicy(String)
    case mutablePack
    case digestMismatch(String)
    case malformed(String)
    case geometryDigestMismatch(String)

    var errorDescription: String? {
        switch self {
        case .missingFile(let name): return "圖資缺少 \(name)"
        case .unsupportedPolicy(let value): return "不支援的拍攝規則：\(value)"
        case .mutablePack: return "圖資未標記為不可變版本"
        case .digestMismatch(let name): return "圖資檔案校驗失敗：\(name)"
        case .malformed(let message): return "圖資格式錯誤：\(message)"
        case .geometryDigestMismatch(let id): return "路段幾何校驗失敗：\(id)"
        }
    }
}

enum CapturePackVerifier {
    static let supportedPolicyID = "photo-first-fixed-4m-v1"

    static func load(directory: URL) throws -> VerifiedCapturePack {
        let manifestURL = directory.appendingPathComponent("pack-manifest.json")
        guard let manifestData = try? Data(contentsOf: manifestURL) else {
            throw CapturePackError.missingFile("pack-manifest.json")
        }
        let manifest = try JSONDecoder().decode(CapturePackManifest.self, from: manifestData)
        guard manifest.immutable else { throw CapturePackError.mutablePack }
        guard manifest.capturePolicy.policyID == supportedPolicyID else {
            throw CapturePackError.unsupportedPolicy(manifest.capturePolicy.policyID)
        }
        guard manifest.capturePolicy.nominalSpacingMeters == 4 else {
            throw CapturePackError.unsupportedPolicy("nominalSpacing=\(manifest.capturePolicy.nominalSpacingMeters)")
        }

        for (name, expected) in manifest.files {
            let url = directory.appendingPathComponent(name)
            guard let data = try? Data(contentsOf: url) else {
                throw CapturePackError.missingFile(name)
            }
            guard sha256(data) == expected.lowercased() else {
                throw CapturePackError.digestMismatch(name)
            }
        }

        let axesData = try Data(contentsOf: directory.appendingPathComponent("capture-axes.geojson"))
        let polygonsData = try Data(contentsOf: directory.appendingPathComponent("sidewalk-features.geojson"))
        let canonicalData = try Data(contentsOf: directory.appendingPathComponent("canonical-geometries.json"))
        let features = try parseFeatures(
            axesData: axesData,
            polygonsData: polygonsData,
            canonicalData: canonicalData,
            manifest: manifest
        )
        return VerifiedCapturePack(manifest: manifest, features: features, sourceDirectory: directory)
    }

    static func defaultPackDirectory(bundle: Bundle = .main) -> URL? {
        if let bundled = bundle.url(
            forResource: "zhubei-citywide-field-r1",
            withExtension: nil,
            subdirectory: "CapturePacks"
        ) { return bundled }

        if let bundled = bundle.url(
            forResource: "real-pilot-candidate-r1",
            withExtension: nil,
            subdirectory: "CapturePacks"
        ) { return bundled }

        let support = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        let downloaded = support
            .appendingPathComponent("WalkScan/CapturePacks", isDirectory: true)
            .appendingPathComponent("real-pilot-candidate-r1", isDirectory: true)
        return FileManager.default.fileExists(atPath: downloaded.path) ? downloaded : nil
    }

    private static func parseFeatures(
        axesData: Data,
        polygonsData: Data,
        canonicalData: Data,
        manifest: CapturePackManifest
    ) throws -> [CaptureAxisFeature] {
        let axesRoot = try jsonObject(axesData)
        let polygonsRoot = try jsonObject(polygonsData)
        let canonicalRoot = try jsonObject(canonicalData)
        guard let axes = axesRoot["features"] as? [[String: Any]],
              let polygons = polygonsRoot["features"] as? [[String: Any]],
              let canonical = canonicalRoot["features"] as? [[String: Any]] else {
            throw CapturePackError.malformed("feature collection")
        }

        let polygonsByRevision = Dictionary(uniqueKeysWithValues: try polygons.map { item -> (String, [[CLLocationCoordinate2D]]) in
            let properties = try propertiesOf(item)
            let revision = try string("geometryRevisionID", in: properties)
            let geometry = try dictionary("geometry", in: item)
            guard let rawRings = geometry["coordinates"] as? [[[Any]]] else {
                throw CapturePackError.malformed("polygon coordinates")
            }
            return (revision, try rawRings.map { try parseCoordinates($0) })
        })

        // The Website publishes a JCS-hashed EPSG:3826 integer-mm canonical
        // payload.  This app must not reconstruct that payload from display
        // GeoJSON (or Foundation JSON serialization): it verifies the signed
        // pack-file digest, then only checks value identity across payloads.
        let canonicalHashes = try Dictionary(
            uniqueKeysWithValues: canonical.map { item -> (String, String) in
                (
                    try string("geometryRevisionID", in: item),
                    try string("geometryHash", in: item).lowercased()
                )
            }
        )

        return try axes.map { item in
            let properties = try propertiesOf(item)
            let geometry = try dictionary("geometry", in: item)
            guard let rawAxis = geometry["coordinates"] as? [[Any]] else {
                throw CapturePackError.malformed("capture axis coordinates")
            }
            let revision = try string("geometryRevisionID", in: properties)
            let geometryHash = try string("geometryHash", in: properties)
            guard canonicalHashes[revision] == geometryHash.lowercased() else {
                throw CapturePackError.geometryDigestMismatch(revision)
            }
            let datasetRevision = try string("datasetRevisionID", in: properties)
            guard datasetRevision == manifest.datasetRevisionID else {
                throw CapturePackError.malformed("mixed dataset revision")
            }
            return CaptureAxisFeature(
                datasetID: try string("datasetID", in: properties),
                datasetRevisionID: datasetRevision,
                featureID: try string("featureID", in: properties),
                subsegmentID: try string("subsegmentID", in: properties),
                geometryRevisionID: revision,
                geometryHash: geometryHash,
                status: try string("status", in: properties),
                captureEligible: properties["captureEligible"] as? Bool ?? false,
                axisStartNodeID: try string("axisStartNodeID", in: properties),
                axisEndNodeID: try string("axisEndNodeID", in: properties),
                axisLengthMm: try integer("axisLengthMm", in: properties),
                vertexChainageMm: try integerArray("vertexChainageMm", in: properties),
                axis: try parseCoordinates(rawAxis),
                polygonRings: polygonsByRevision[revision] ?? []
            )
        }
    }

    private static func jsonObject(_ data: Data) throws -> [String: Any] {
        guard let value = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw CapturePackError.malformed("root object")
        }
        return value
    }

    private static func propertiesOf(_ item: [String: Any]) throws -> [String: Any] {
        try dictionary("properties", in: item)
    }

    private static func dictionary(_ key: String, in object: [String: Any]) throws -> [String: Any] {
        guard let value = object[key] as? [String: Any] else {
            throw CapturePackError.malformed(key)
        }
        return value
    }

    private static func string(_ key: String, in object: [String: Any]) throws -> String {
        guard let value = object[key] as? String else { throw CapturePackError.malformed(key) }
        return value
    }

    private static func integer(_ key: String, in object: [String: Any]) throws -> Int {
        guard let value = object[key] as? NSNumber else { throw CapturePackError.malformed(key) }
        return value.intValue
    }

    private static func integerArray(_ key: String, in object: [String: Any]) throws -> [Int] {
        guard let values = object[key] as? [NSNumber] else { throw CapturePackError.malformed(key) }
        return values.map(\.intValue)
    }

    private static func parseCoordinates(_ values: [[Any]]) throws -> [CLLocationCoordinate2D] {
        try values.map { pair in
            guard pair.count >= 2,
                  let longitude = pair[0] as? NSNumber,
                  let latitude = pair[1] as? NSNumber else {
                throw CapturePackError.malformed("coordinate pair")
            }
            return CLLocationCoordinate2D(latitude: latitude.doubleValue, longitude: longitude.doubleValue)
        }
    }

    private static func sha256(_ data: Data) -> String {
        SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
    }
}

enum CaptureProjectionStatus: String, Codable, Equatable {
    case confirmed
    case clampedEndpoint = "clamped_endpoint"
    case ambiguousCandidates = "ambiguous_candidates"
    case rejectedPolygonHole = "rejected_polygon_hole"
    case outsideEligiblePolygon = "outside_eligible_polygon"
}

struct CaptureProjection: Codable, Equatable {
    let status: CaptureProjectionStatus
    let featureID: String?
    let subsegmentID: String?
    let geometryRevisionID: String?
    let segmentIndex: Int?
    let segmentFraction: Double?
    let chainageMeters: Double?
    let normalizedMeasure: Double?
    let snappedLatitude: Double?
    let snappedLongitude: Double?
    let snapDistanceMeters: Double?
}

enum CaptureAxisProjector {
    static func project(
        _ coordinate: CLLocationCoordinate2D,
        accuracyMeters: Double,
        features: [CaptureAxisFeature],
        selectedGeometryRevisionID: String? = nil
    ) -> CaptureProjection {
        let eligible = features.filter {
            $0.captureEligible && (selectedGeometryRevisionID == nil || $0.geometryRevisionID == selectedGeometryRevisionID)
        }
        let candidates = eligible.compactMap { nearest(coordinate, to: $0) }.sorted { $0.distance < $1.distance }
        guard let best = candidates.first else { return empty(.outsideEligiblePolygon) }

        if selectedGeometryRevisionID == nil,
           candidates.count > 1,
           candidates[1].distance <= max(accuracyMeters, 1),
           abs(candidates[1].distance - best.distance) <= 0.35 {
            return empty(.ambiguousCandidates)
        }

        switch membership(of: coordinate, in: best.feature.polygonRings) {
        case .outside where !best.clamped:
            return projection(best, status: .outsideEligiblePolygon)
        case .hole:
            return projection(best, status: .rejectedPolygonHole)
        case .inside, .outside:
            break
        }
        return projection(best, status: best.clamped ? .clampedEndpoint : .confirmed)
    }

    private struct Candidate {
        let feature: CaptureAxisFeature
        let segmentIndex: Int
        let t: Double
        let coordinate: CLLocationCoordinate2D
        let distance: Double
        let chainage: Double
        let clamped: Bool
    }

    private static func nearest(_ coordinate: CLLocationCoordinate2D, to feature: CaptureAxisFeature) -> Candidate? {
        guard feature.axis.count >= 2, feature.vertexChainageMm.count == feature.axis.count else { return nil }
        let point = MKMapPoint(coordinate)
        var best: Candidate?
        for index in 0..<(feature.axis.count - 1) {
            let a = MKMapPoint(feature.axis[index])
            let b = MKMapPoint(feature.axis[index + 1])
            let dx = b.x - a.x
            let dy = b.y - a.y
            let denominator = dx * dx + dy * dy
            let rawT = denominator == 0 ? 0 : ((point.x - a.x) * dx + (point.y - a.y) * dy) / denominator
            let t = min(1, max(0, rawT))
            let snappedPoint = MKMapPoint(x: a.x + t * dx, y: a.y + t * dy)
            let snapped = snappedPoint.coordinate
            let distance = CLLocation(latitude: coordinate.latitude, longitude: coordinate.longitude)
                .distance(from: CLLocation(latitude: snapped.latitude, longitude: snapped.longitude))
            let start = Double(feature.vertexChainageMm[index]) / 1000
            let end = Double(feature.vertexChainageMm[index + 1]) / 1000
            let candidate = Candidate(
                feature: feature,
                segmentIndex: index,
                t: t,
                coordinate: snapped,
                distance: distance,
                chainage: start + t * (end - start),
                clamped: rawT < 0 || rawT > 1
            )
            if best == nil || distance < best!.distance { best = candidate }
        }
        return best
    }

    private enum PolygonMembership { case outside, inside, hole }

    private static func membership(
        of coordinate: CLLocationCoordinate2D,
        in rings: [[CLLocationCoordinate2D]]
    ) -> PolygonMembership {
        guard let outer = rings.first else { return .outside }
        let point = MKMapPoint(coordinate)
        guard ringContains(point, ring: outer) else { return .outside }
        return rings.dropFirst().contains { ringContains(point, ring: $0) } ? .hole : .inside
    }

    /// Deterministic ray casting avoids relying on an unprepared renderer path
    /// and is directly testable with the shared polygon-hole fixture.
    private static func ringContains(_ point: MKMapPoint, ring: [CLLocationCoordinate2D]) -> Bool {
        guard ring.count >= 3 else { return false }
        let vertices = ring.map { MKMapPoint($0) }
        var inside = false
        var j = vertices.count - 1
        for i in 0..<vertices.count {
            let a = vertices[i]
            let b = vertices[j]
            let crosses = ((a.y > point.y) != (b.y > point.y))
                && (point.x < (b.x - a.x) * (point.y - a.y) / (b.y - a.y) + a.x)
            if crosses { inside.toggle() }
            j = i
        }
        return inside
    }

    private static func projection(_ value: Candidate, status: CaptureProjectionStatus) -> CaptureProjection {
        CaptureProjection(
            status: status,
            featureID: value.feature.featureID,
            subsegmentID: value.feature.subsegmentID,
            geometryRevisionID: value.feature.geometryRevisionID,
            segmentIndex: value.segmentIndex,
            segmentFraction: value.t,
            chainageMeters: value.chainage,
            normalizedMeasure: value.feature.axisLengthMm > 0 ? value.chainage / (Double(value.feature.axisLengthMm) / 1000) : nil,
            snappedLatitude: value.coordinate.latitude,
            snappedLongitude: value.coordinate.longitude,
            snapDistanceMeters: value.distance
        )
    }

    private static func empty(_ status: CaptureProjectionStatus) -> CaptureProjection {
        CaptureProjection(
            status: status,
            featureID: nil,
            subsegmentID: nil,
            geometryRevisionID: nil,
            segmentIndex: nil,
            segmentFraction: nil,
            chainageMeters: nil,
            normalizedMeasure: nil,
            snappedLatitude: nil,
            snappedLongitude: nil,
            snapDistanceMeters: nil
        )
    }
}
