import UIKit
import MapKit
import CoreLocation

final class MissionEndpointConfirmationViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
    private let binding: WalkMission.MapBinding
    private let expectedChainageMeters: Double
    private let endpointTitle: String
    private let completion: (Bool) -> Void
    private let mapView = MKMapView()
    private let locationManager = CLLocationManager()
    private let statusLabel = UILabel()
    private var accuracyCircle: MKCircle?

    init(
        binding: WalkMission.MapBinding,
        expectedChainageMeters: Double? = nil,
        endpointTitle: String = "確認終點",
        completion: @escaping (Bool) -> Void
    ) {
        self.binding = binding
        self.expectedChainageMeters = expectedChainageMeters ?? binding.captureEndChainageMeters
        self.endpointTitle = endpointTitle
        self.completion = completion
        super.init(nibName: nil, bundle: nil)
        modalPresentationStyle = .pageSheet
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = endpointTitle
        view.backgroundColor = .systemBackground
        mapView.delegate = self
        mapView.showsUserLocation = true
        mapView.translatesAutoresizingMaskIntoConstraints = false

        let axis = binding.axisCoordinates.map {
            CLLocationCoordinate2D(latitude: $0[1], longitude: $0[0])
        }
        let line = MKPolyline(coordinates: axis, count: axis.count)
        line.title = binding.geometryRevisionID
        mapView.addOverlay(line)
        if let ring = binding.polygonRings.first?.map({ CLLocationCoordinate2D(latitude: $0[1], longitude: $0[0]) }) {
            let polygon = MKPolygon(coordinates: ring, count: ring.count)
            polygon.title = binding.geometryRevisionID
            mapView.addOverlay(polygon)
        }
        let target = coordinateOnAxis(chainageMeters: expectedChainageMeters, axis: axis)
        if let target {
            mapView.setRegion(MKCoordinateRegion(center: target, latitudinalMeters: 55, longitudinalMeters: 55), animated: false)
        }

        let crosshair = UIImageView(image: UIImage(systemName: "plus"))
        crosshair.tintColor = .label
        crosshair.translatesAutoresizingMaskIntoConstraints = false
        crosshair.isUserInteractionEnabled = false

        statusLabel.text = "把準星移到路段終點，再確認"
        statusLabel.font = .preferredFont(forTextStyle: .footnote)
        statusLabel.numberOfLines = 0

        let locate = UIButton(type: .system)
        locate.setTitle("定位到我", for: .normal)
        locate.accessibilityLabel = "定位到我"
        locate.accessibilityHint = "將地圖移到目前位置並顯示定位精度範圍"
        locate.addTarget(self, action: #selector(locateMe), for: .touchUpInside)

        let confirm = UIButton(type: .system)
        confirm.setTitle("確認終點，準備回程", for: .normal)
        confirm.accessibilityLabel = "確認終點，準備回程"
        confirm.accessibilityHint = "只有準星位於指定終點時才會確認"
        confirm.titleLabel?.font = .preferredFont(forTextStyle: .headline)
        confirm.addTarget(self, action: #selector(confirmEndpoint), for: .touchUpInside)

        let cancel = UIButton(type: .system)
        cancel.setTitle("返回相機", for: .normal)
        cancel.addTarget(self, action: #selector(cancelConfirmation), for: .touchUpInside)

        let controls = UIStackView(arrangedSubviews: [statusLabel, locate, confirm, cancel])
        controls.axis = .vertical
        controls.spacing = 10
        controls.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(mapView)
        view.addSubview(crosshair)
        view.addSubview(controls)
        NSLayoutConstraint.activate([
            mapView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            mapView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            mapView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            mapView.bottomAnchor.constraint(equalTo: controls.topAnchor, constant: -12),
            crosshair.centerXAnchor.constraint(equalTo: mapView.centerXAnchor),
            crosshair.centerYAnchor.constraint(equalTo: mapView.centerYAnchor),
            crosshair.widthAnchor.constraint(equalToConstant: 32),
            crosshair.heightAnchor.constraint(equalToConstant: 32),
            controls.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            controls.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            controls.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -12)
        ])

        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.startUpdatingLocation()
    }

    @objc private func locateMe() {
        guard let coordinate = locationManager.location?.coordinate else {
            statusLabel.text = "尚未取得定位；可直接移動地圖用準星確認"
            return
        }
        mapView.setCenter(coordinate, animated: true)
    }

    private func coordinateOnAxis(
        chainageMeters: Double,
        axis: [CLLocationCoordinate2D]
    ) -> CLLocationCoordinate2D? {
        guard axis.count >= 2,
              binding.vertexChainageMm.count == axis.count else { return axis.first }
        let targetMm = Int((chainageMeters * 1000).rounded())
        for index in 0..<(axis.count - 1) {
            let startMm = binding.vertexChainageMm[index]
            let endMm = binding.vertexChainageMm[index + 1]
            guard targetMm >= startMm, targetMm <= endMm, endMm > startMm else { continue }
            let t = Double(targetMm - startMm) / Double(endMm - startMm)
            return CLLocationCoordinate2D(
                latitude: axis[index].latitude + (axis[index + 1].latitude - axis[index].latitude) * t,
                longitude: axis[index].longitude + (axis[index + 1].longitude - axis[index].longitude) * t
            )
        }
        return chainageMeters <= 0 ? axis.first : axis.last
    }

    @objc private func confirmEndpoint() {
        let feature = CaptureAxisFeature(
            datasetID: binding.datasetID,
            datasetRevisionID: binding.datasetRevisionID,
            featureID: binding.featureID,
            subsegmentID: binding.subsegmentID,
            geometryRevisionID: binding.geometryRevisionID,
            geometryHash: binding.geometryHash,
            status: binding.packStatus,
            captureEligible: true,
            axisStartNodeID: binding.axisStartNodeID,
            axisEndNodeID: binding.axisEndNodeID,
            axisLengthMm: binding.axisLengthMm,
            vertexChainageMm: binding.vertexChainageMm,
            axis: binding.axisCoordinates.map { CLLocationCoordinate2D(latitude: $0[1], longitude: $0[0]) },
            polygonRings: binding.polygonRings.map { ring in ring.map { CLLocationCoordinate2D(latitude: $0[1], longitude: $0[0]) } }
        )
        let result = CaptureAxisProjector.project(
            mapView.centerCoordinate,
            accuracyMeters: max(locationManager.location?.horizontalAccuracy ?? 5, 1),
            features: [feature],
            selectedGeometryRevisionID: binding.geometryRevisionID
        )
        guard result.status == .confirmed || result.status == .clampedEndpoint,
              let chainage = result.chainageMeters,
              abs(chainage - expectedChainageMeters) <= 1.25 else {
            statusLabel.text = "準星尚未到指定終點，請移到綠色路段另一端"
            statusLabel.textColor = .systemOrange
            return
        }
        locationManager.stopUpdatingLocation()
        dismiss(animated: true) { self.completion(true) }
    }

    @objc private func cancelConfirmation() {
        locationManager.stopUpdatingLocation()
        dismiss(animated: true) { self.completion(false) }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last, location.horizontalAccuracy >= 0 else { return }
        if let old = accuracyCircle { mapView.removeOverlay(old) }
        let circle = MKCircle(center: location.coordinate, radius: location.horizontalAccuracy)
        accuracyCircle = circle
        mapView.addOverlay(circle)
    }

    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        if let circle = overlay as? MKCircle {
            let renderer = MKCircleRenderer(circle: circle)
            renderer.fillColor = UIColor.systemBlue.withAlphaComponent(0.12)
            renderer.strokeColor = UIColor.systemBlue.withAlphaComponent(0.5)
            return renderer
        }
        if let polygon = overlay as? MKPolygon {
            let renderer = MKPolygonRenderer(polygon: polygon)
            renderer.fillColor = UIColor.systemGreen.withAlphaComponent(0.22)
            renderer.strokeColor = .systemGreen
            renderer.lineWidth = 2
            return renderer
        }
        if let line = overlay as? MKPolyline {
            let renderer = MKPolylineRenderer(polyline: line)
            renderer.strokeColor = .systemGreen
            renderer.lineWidth = 5
            return renderer
        }
        return MKOverlayRenderer(overlay: overlay)
    }
}
