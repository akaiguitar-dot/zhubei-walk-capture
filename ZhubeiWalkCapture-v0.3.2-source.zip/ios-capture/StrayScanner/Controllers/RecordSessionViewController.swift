//
//  RecordSessionViewController.swift
//  Stray Scanner
//
//  Created by Kenneth Blomqvist on 11/28/20.
//  Copyright © 2020 Stray Robots. All rights reserved.
//

import Foundation
import UIKit
import Metal
import ARKit
import CoreData
import CoreLocation

let FpsDividers: [Int] = [1, 2, 4, 12, 60]
let AvailableFpsSettings: [Int] = FpsDividers.map { Int(60 / $0) }
let FpsUserDefaultsKey: String = "FPS"

class MetalView : UIView {
    override class var layerClass: AnyClass {
        get {
            return CAMetalLayer.self
        }
    }
    override var layer: CAMetalLayer {
        return super.layer as! CAMetalLayer
    }
}

private struct WalkGuideGate {
    let sequence: Int
    let center: SIMD3<Float>
    let direction: SIMD3<Float>
    let widthMeters: Float
    let floorY: Float
    let confidence: Float
}

private struct WalkGuidePlan {
    let direction: SIMD3<Float>
    let floorY: Float
    let widthMeters: Float
    let confidence: Float
}

class RecordSessionViewController : UIViewController, ARSessionDelegate, CLLocationManagerDelegate {
    private var unsupported: Bool = false
    private var arConfiguration: ARWorldTrackingConfiguration?
    private let session = ARSession()
    private let locationManager = CLLocationManager()
    private var latestLocation: CLLocation?
    private var latestHeading: CLHeading?
    private var lockedOriginLocation: CLLocation?
    private var lockedOrigin: WalkCaptureOrigin?
    private var renderer: CameraRenderer?
    private var updateLabelTimer: Timer?
    private var startedRecording: Date?
    private var dataContext: NSManagedObjectContext!
    private var datasetEncoder: DatasetEncoder?
    private var chosenFpsSetting: Int = 0
    private var mission = WalkMission(
        segmentID: "ZB-WALK-UNASSIGNED",
        targetLengthMeters: 20,
        requiresReturnTrip: true,
        captureMode: .mappedSegment
    )
    private var travelledMeters: Double = 0
    private var lastProgressPosition: SIMD3<Float>?
    private var lastProgressSampleTimestamp: TimeInterval = 0
    private var turnWasAnnounced = false
    private var completionWasAnnounced = false
    private var isReturnTrip = false
    private var endpointAwaitingConfirmation = false
    private var endpointGroundCaptured = false
    private var endpointConfirmedForReturn = false
    private var returnEndpointMapConfirmed = false
    private var fieldQCApproved = false
    private let segmentLabel = UILabel()
    private let guidanceLabel = UILabel()
    private let distanceLabel = UILabel()
    private let captureCountLabel = UILabel()
    private let trackingLabel = UILabel()
    private let aimLabel = UILabel()
    private let preflightLabel = UILabel()
    private let originStatusLabel = UILabel()
    private let lockOriginButton = UIButton(type: .system)
    private let turnAroundButton = UIButton(type: .system)
    private let diagnosticsButton = UIButton(type: .system)
    private var diagnosticsStack: UIStackView?
    private var diagnosticsExpanded = false
    private let missionProgress = UIProgressView(progressViewStyle: .bar)
    private let captureReticle = UIView()
    private let gateOverlayView = UIView()
    private let gateFillLayer = CAShapeLayer()
    private let gateOutlineLayer = CAShapeLayer()
    private let routeGuideLayer = CAShapeLayer()
    private var stationFeedbackVisibleUntil: CFTimeInterval = 0
    private var pendingFacePrompt: String?
    private var activeGuideGate: WalkGuideGate?
    private var previousGuideDirection: SIMD3<Float>?
    private var guideCanCreateGate = false
    private var guideGateReached = false
    private var guideNextSequence = 1
    private var guideCompletedDistanceMeters: Double = 0
    private var lastGuidePlanTimestamp: TimeInterval = -1
    private var lastGuideRenderState = ""
    private var guideAwaitingReturnTurn = false
    private var guideReturnReferenceDirection: SIMD3<Float>?
    @IBOutlet private var rgbView: MetalView!
    @IBOutlet private var depthView: MetalView!
    @IBOutlet private var recordButton: RecordButton!
    @IBOutlet private var timeLabel: UILabel!
    @IBOutlet weak var fpsButton: UIButton!
    var dismissFunction: Optional<() -> Void> = Optional.none

    func setMission(_ mission: WalkMission) {
        self.mission = mission
    }
    
    func setDismissFunction(_ fn: Optional<() -> Void>) {
        self.dismissFunction = fn
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        // The capture engine now saves automatic RGB-D stills instead of video.
        updateFpsSetting()
    }

    override func viewDidLoad() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        self.dataContext = appDelegate.persistentContainer.newBackgroundContext()
        self.renderer = CameraRenderer(rgbLayer: rgbView.layer, depthLayer: depthView.layer)
        self.renderer?.renderMode = .rgb
        rgbView.isHidden = false
        depthView.isHidden = true

        depthView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(viewTapped)))
        rgbView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(viewTapped)))
        
        setViewProperties()
        setupMissionOverlay()
        session.delegate = self
        session.delegateQueue = .main
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.distanceFilter = 1
        locationManager.headingFilter = 1
        locationManager.headingOrientation = .portrait
        locationManager.requestWhenInUseAuthorization()

        recordButton.setCallback { (recording: Bool) in
            self.toggleRecording(recording)
        }
        recordButton.setCaptureEnabled(false)
        fpsButton.layer.masksToBounds = true
        fpsButton.layer.cornerRadius = 12.0
        fpsButton.isHidden = true
        UIDevice.current.isBatteryMonitoringEnabled = true
    }

    override func viewDidDisappear(_ animated: Bool) {
        session.pause()
        locationManager.stopUpdatingLocation()
        locationManager.stopUpdatingHeading()
    }

    override func viewWillDisappear(_ animated: Bool) {
        updateLabelTimer?.invalidate()
        datasetEncoder = nil
    }

    override func viewDidAppear(_ animated: Bool) {
        startSession()
        locationManager.startUpdatingLocation()
        if CLLocationManager.headingAvailable() {
            locationManager.startUpdatingHeading()
        }
    }

    private func startSession() {
        let config = ARWorldTrackingConfiguration()
        // Keep arbitrary walking paths geographically oriented so the Windows
        // importer can align the local corridor with GPS and GIS layers.
        config.worldAlignment = .gravityAndHeading
        config.planeDetection = [.horizontal]
        if ARWorldTrackingConfiguration.supportsSceneReconstruction(
            .meshWithClassification
        ) {
            config.sceneReconstruction = .meshWithClassification
        }
        arConfiguration = config
        if !ARWorldTrackingConfiguration.isSupported || !ARWorldTrackingConfiguration.supportsFrameSemantics(.sceneDepth) {
            print("AR is not supported.")
            unsupported = true
        } else {
            config.frameSemantics.insert(.sceneDepth)
            if ARWorldTrackingConfiguration.supportsFrameSemantics(
                .smoothedSceneDepth
            ) {
                config.frameSemantics.insert(.smoothedSceneDepth)
            }
            session.run(config)
        }
    }
    
    private func toggleRecording(_ recording: Bool) {
        if unsupported {
            showUnsupportedAlert()
            return
        }
        if recording && self.startedRecording == nil {
            guard lockedOrigin != nil else {
                originStatusLabel.text = "請先站在起點，將手機朝行進方向並鎖定"
                originStatusLabel.textColor = .systemYellow
                recordButton.setCaptureEnabled(false)
                return
            }
            startRecording()
        } else if self.startedRecording != nil && !recording {
            requestStopRecording()
        } else {
            print("This should not happen. We are either not recording and want to stop, or we are recording and want to start.")
        }
    }

    private func startRecording() {
        guard let origin = lockedOrigin else { return }
        self.startedRecording = Date()
        travelledMeters = 0
        lastProgressPosition = nil
        lastProgressSampleTimestamp = 0
        turnWasAnnounced = false
        completionWasAnnounced = false
        isReturnTrip = false
        endpointAwaitingConfirmation = false
        endpointGroundCaptured = false
        endpointConfirmedForReturn = false
        returnEndpointMapConfirmed = false
        resetWalkGuide()
        missionProgress.progress = 0
        aimLabel.text = "鏡頭保持水平；App 會依畫面採集關鍵照片"
        pendingFacePrompt = mission.captureProfile == .sixFace
            ? "第 1 個節點｜1/6 對準前方，穩定後自動拍照"
            : nil
        captureCountLabel.text = mission.captureProfile == .sixFace
            ? "節點 1｜六向 0/6"
            : "已自動拍攝 0 張"
        turnAroundButton.isEnabled = true
        turnAroundButton.alpha = 1.0
        turnAroundButton.setTitle("我已到終點", for: .normal)
        if mission.captureMode == .freeRoute {
            guidanceLabel.text = "沿人行道前進；到終點後先確認終點，再開始回程"
            missionProgress.isHidden = true
            turnAroundButton.isHidden = false
        } else {
            guidanceLabel.text = "沿人行道向前走，手機維持目視高度"
            missionProgress.isHidden = false
        }
        if mission.captureProfile == .sixFace {
            guidanceLabel.text = "六面調查僅供重點位置；依畫面逐向轉動"
        }
        updateTime()
        updateLabelTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            self.updateTime()
        }
        datasetEncoder = DatasetEncoder(mission: mission, origin: origin)
        if let lockedOriginLocation {
            datasetEncoder?.add(location: lockedOriginLocation)
        }
        lockOriginButton.isEnabled = false
        lockOriginButton.isHidden = true
        originStatusLabel.isHidden = true
        locationManager.startUpdatingLocation()
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
    }

    private func requestStopRecording() {
        guard let encoder = datasetEncoder else {
            recordButton.setRecordingState(true)
            return
        }
        if mission.captureMode == .freeRoute {
            stopRecording(qcApproved: true)
            return
        }
        guard isReturnTrip else {
            recordButton.setRecordingState(true)
            let alert = UIAlertController(
                title: "尚未完成回程",
                message: "請先到終點確認後，沿原路回到起點再結束採集。",
                preferredStyle: .alert
            )
            alert.addAction(UIAlertAction(title: "繼續採集", style: .default))
            present(alert, animated: true)
            return
        }
        recordButton.setRecordingState(true)
        encoder.prepareReturnEndpointEvidence(frame: session.currentFrame, at: travelledMeters) { evidence in
            guard evidence.returnEndpointStationID != nil else {
                let alert = UIAlertController(
                    title: "尚未拍到回程起點",
                    message: "請把鏡頭保持水平，回到原起點後再按結束。",
                    preferredStyle: .alert
                )
                alert.addAction(UIAlertAction(title: "繼續採集", style: .default))
                self.present(alert, animated: true)
                return
            }
            guard !self.returnEndpointMapConfirmed,
                  let binding = self.mission.mapBinding else {
                self.presentFieldQC(evidence: evidence)
                return
            }
            let controller = MissionEndpointConfirmationViewController(
                binding: binding,
                expectedChainageMeters: binding.captureStartChainageMeters,
                endpointTitle: "確認已回到起點"
            ) { confirmed in
                guard confirmed else { return }
                self.returnEndpointMapConfirmed = true
                self.presentFieldQC(evidence: evidence)
            }
            self.present(controller, animated: true)
        }
    }

    private func presentFieldQC(evidence: WalkCaptureEvidenceSnapshot) {
        let minimumLegCoverage = max(1, mission.targetLengthMeters * 0.75)
        let expectedPerLeg = max(
            2,
            Int(ceil(mission.targetLengthMeters / mission.capturePolicy.nominalSpacingMeters)) + 1
        )
        let issues = CaptureQualityGate.completionIssues(
            hasStartAnchor: evidence.startAnchorStationID != nil,
            hasEndAnchor: evidence.outboundEndpointStationID != nil && evidence.returnEndpointStationID != nil,
            hasOutboundLeg: evidence.outboundStationCount >= 2 && evidence.outboundCoveredMeters >= minimumLegCoverage,
            hasReturnLeg: evidence.returnStationCount >= 2 && evidence.returnCoveredMeters >= minimumLegCoverage,
            hasRequiredReferences: evidence.outboundStationCount >= expectedPerLeg
                && evidence.returnStationCount >= expectedPerLeg
                && evidence.outboundEndpointGroundStationID != nil
                && evidence.returnStartAnchorStationID != nil
                && returnEndpointMapConfirmed
        )
        let blocks = issues.filter(\.blocksCompletion)
        guard blocks.isEmpty else {
            recordButton.setRecordingState(true)
            let labels = blocks.map { issue -> String in
                switch issue {
                case .missingAnchor: return "起點或終點尚未確認"
                case .incompleteLeg: return "去程或回程尚未完成"
                case .missingRequiredReference: return "必要照片仍有缺漏"
                default: return "必要資料仍有缺漏"
                }
            }
            let alert = UIAlertController(
                title: "還不能完成",
                message: labels.joined(separator: "\n"),
                preferredStyle: .alert
            )
            alert.addAction(UIAlertAction(title: "繼續拍攝", style: .default))
            present(alert, animated: true)
            return
        }

        var warnings: [String] = []
        if case .normal? = session.currentFrame?.camera.trackingState {
            // Final-frame tracking is healthy.
        } else {
            warnings.append("目前追蹤不穩，建議停穩後再完成")
        }
        if evidence.imageQualityObservationCount == 0 {
            warnings.append("這次沒有可用的裝置端亮度／清晰度分析，後端仍會再檢查")
        } else if evidence.imageQualityIssueCounts.isEmpty {
            warnings.append(
                "已用 \(evidence.imageQualityAnalyzerVersion) 檢查 \(evidence.imageQualityObservationCount) 張；未達警告門檻"
            )
        } else {
            let labels = evidence.imageQualityIssueCounts.keys.sorted().compactMap { code -> String? in
                guard let count = evidence.imageQualityIssueCounts[code] else { return nil }
                let title: String
                switch code {
                case "blurred": title = "可能模糊"
                case "too_dark": title = "太暗"
                case "overexposed": title = "過曝"
                case "lens_occluded": title = "鏡頭可能被遮住"
                default: title = code
                }
                return "\(title) \(count) 張"
            }
            warnings.append(
                "裝置端影像提醒：\(labels.joined(separator: "、"))；影響 \(evidence.imageQualityAffectedStationIDs.count) 個節點"
            )
        }
        let message = "起點、終點、去程、回程與必要照片已齊全。\n\n" + warnings.joined(separator: "\n")
        let alert = UIAlertController(title: "現場資料完整", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "返回補拍", style: .cancel, handler: { _ in
            self.recordButton.setRecordingState(true)
        }))
        alert.addAction(UIAlertAction(title: "完成並安全上傳", style: .default, handler: { _ in
            self.fieldQCApproved = true
            self.stopRecording(qcApproved: true)
        }))
        present(alert, animated: true)
    }

    private func stopRecording(qcApproved: Bool = false) {
        guard mission.captureMode != .mappedSegment || qcApproved || fieldQCApproved else {
            recordButton.setRecordingState(true)
            return
        }
        guard let started = self.startedRecording else {
            print("Hasn't started recording. Something is wrong.")
            return
        }
        startedRecording = nil
        updateLabelTimer?.invalidate()
        updateLabelTimer = nil
        locationManager.stopUpdatingLocation()
        locationManager.stopUpdatingHeading()
        turnAroundButton.isHidden = true
        datasetEncoder?.addFinal(
            frame: session.currentFrame,
            travelDistance: travelledMeters
        )
        datasetEncoder?.wrapUp(travelDistance: travelledMeters)
        hideWalkGuide()
        if let encoder = datasetEncoder {
            switch encoder.status {
                case .allGood:
                    saveRecording(started, encoder)
                case .encodingError:
                    showError()
                case .directoryCreationError:
                    showError()
            }
        } else {
            print("No dataset encoder. Something is wrong.")
        }
        self.dismissFunction?()
    }

    private func saveRecording(_ started: Date, _ encoder: DatasetEncoder) {
        let duration = Date().timeIntervalSince(started)
        let entity = NSEntityDescription.entity(forEntityName: "Recording", in: self.dataContext)!
        let recording: Recording = Recording(entity: entity, insertInto: self.dataContext)
        recording.setValue(datasetEncoder!.id, forKey: "id")
        recording.setValue(duration, forKey: "duration")
        recording.setValue(started, forKey: "createdAt")
        recording.setValue(mission.segmentID, forKey: "name")
        recording.setValue(datasetEncoder!.rgbFilePath.relativeString, forKey: "rgbFilePath")
        recording.setValue(datasetEncoder!.depthFilePath.relativeString, forKey: "depthFilePath")
        do {
            try self.dataContext.save()
            PrivateWalkScanTransferQueue.shared.enqueue(recording: recording)
        } catch let error as NSError {
            print("Could not save recording. \(error), \(error.userInfo)")
        }
    }

    private func showError() {
        let controller = UIAlertController(title: "儲存失敗",
            message: "自動照片或 LiDAR 深度資料未能完整保存，請重新採集這一段。",
            preferredStyle: .alert)
        controller.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default Action"), style: .default, handler: { _ in
            self.dismiss(animated: true, completion: nil)
        }))
        self.present(controller, animated: true, completion: nil)
    }

    private func updateTime() {
        guard let started = self.startedRecording else { return }
        let seconds = Date().timeIntervalSince(started)
        let minutes: Int = Int(floor(seconds / 60).truncatingRemainder(dividingBy: 60))
        let hours: Int = Int(floor(seconds / 3600))
        let roundSeconds: Int = Int(floor(seconds.truncatingRemainder(dividingBy: 60)))
        self.timeLabel.text = String(format: "%02d:%02d:%02d", hours, minutes, roundSeconds)
    }

    @objc func viewTapped() {
        switch renderer!.renderMode {
            case .depth:
                renderer!.renderMode = RenderMode.rgb
                rgbView.isHidden = false
                depthView.isHidden = true
            case .rgb:
                renderer!.renderMode = RenderMode.depth
                depthView.isHidden = false
                rgbView.isHidden = true
        }
    }
    
    @IBAction func fpsButtonTapped() {
        chosenFpsSetting = (chosenFpsSetting + 1) % AvailableFpsSettings.count
        updateFpsSetting()
        UserDefaults.standard.set(chosenFpsSetting, forKey: FpsUserDefaultsKey)
    }

    func session(_ session: ARSession, didUpdate frame: ARFrame) {
        self.renderer!.render(frame: frame)
        updateTrackingLabel(frame.camera.trackingState)
        updateAimGuide(frame.camera)
        if startedRecording != nil {
            updateMissionProgress(frame: frame)
            updateWalkGuide(frame: frame)
            if let encoder = datasetEncoder {
                captureEndpointGroundIfAimed(frame: frame, encoder: encoder)
                encoder.addRouteFrame(frame)
                if let update = encoder.add(
                    frame: frame,
                    travelDistance: travelledMeters
                ) {
                    announceStationCapture(update: update)
                }
            } else {
                print("There is no photo dataset encoder.")
            }
        } else if lockedOrigin != nil {
            updateWalkGuide(frame: frame)
        }
    }

    private func setViewProperties() {
        self.view.backgroundColor = UIColor(named: "BackgroundColor")
    }

    @objc private func markReturnTrip() {
        guard startedRecording != nil else { return }
        if !endpointAwaitingConfirmation {
            // Endpoint evidence is deliberately saved before turning around.
            // Starting the return leg remains a separate user action.
            datasetEncoder?.confirmOutboundEndpoint(
                frame: session.currentFrame,
                at: travelledMeters
            )
            endpointAwaitingConfirmation = true
            endpointGroundCaptured = false
            turnAroundButton.setTitle("請下斜拍端點坡道", for: .normal)
            guidanceLabel.text = "端點前視已拍。請把手機下斜，讓坡道、鋪面與穿越線開口入鏡。"
            aimLabel.text = "請下斜拍端點坡道"
            aimLabel.textColor = .systemOrange
            UIAccessibility.post(notification: .announcement, argument: "端點前視已拍，請將手機下斜拍攝坡道與鋪面")
            return
        }

        if !endpointConfirmedForReturn {
            guard endpointGroundCaptured else {
                guidanceLabel.text = "先將手機下斜，App 會自動拍下端點坡道與鋪面。"
                aimLabel.text = "尚未拍到端點地面"
                aimLabel.textColor = .systemOrange
                UIAccessibility.post(notification: .announcement, argument: "尚未拍到端點地面，請把手機下斜")
                return
            }
            guard let binding = mission.mapBinding else {
                guidanceLabel.text = "此任務缺少已驗證圖資，不能確認終點"
                aimLabel.text = "請返回任務地圖"
                aimLabel.textColor = .systemRed
                return
            }
            let controller = MissionEndpointConfirmationViewController(binding: binding) { confirmed in
                guard confirmed else { return }
                self.endpointConfirmedForReturn = true
                self.turnAroundButton.setTitle("開始回程", for: .normal)
                self.guidanceLabel.text = "終點已確認。請轉身後按開始回程"
                self.aimLabel.text = "終點已確認"
                self.aimLabel.textColor = .systemGreen
                UIAccessibility.post(notification: .announcement, argument: "終點已確認，請轉身後開始回程")
            }
            present(controller, animated: true)
            return
        }

        if let update = datasetEncoder?.markReturnTrip(
            frame: session.currentFrame,
            at: travelledMeters
        ) {
            announceStationCapture(update: update)
        }
        isReturnTrip = true
        turnAroundButton.isEnabled = false
        turnAroundButton.alpha = 0.55
        turnAroundButton.setTitle("回程拍攝中", for: .normal)
        guidanceLabel.text = "已進入回程；沿原路走回，App 會自動保留關鍵照片"
        aimLabel.text = "回程已標記"
        aimLabel.textColor = .systemGreen
        UINotificationFeedbackGenerator().notificationOccurred(.success)
        UIAccessibility.post(notification: .announcement, argument: "已進入回程，請沿原路走回")
    }

    private func captureEndpointGroundIfAimed(
        frame: ARFrame,
        encoder: DatasetEncoder
    ) {
        guard endpointAwaitingConfirmation,
              !endpointGroundCaptured,
              !endpointConfirmedForReturn else { return }
        let forwardY = -frame.camera.transform.columns.2.y
        guard forwardY <= -0.28,
              let update = encoder.addOutboundEndpointGround(
                frame: frame,
                at: travelledMeters
              ) else { return }
        endpointGroundCaptured = true
        announceStationCapture(update: update)
        turnAroundButton.setTitle("在地圖確認終點", for: .normal)
        guidanceLabel.text = "端點坡道已拍。按下方按鈕，在地圖確認你站的端點。"
        aimLabel.text = "端點資料已完成"
        aimLabel.textColor = .systemGreen
        UIAccessibility.post(notification: .announcement, argument: "端點坡道已拍，請在地圖確認終點")
    }

    private func setupMissionOverlay() {
        let blur = UIVisualEffectView(effect: UIBlurEffect(style: .systemThinMaterialDark))
        blur.translatesAutoresizingMaskIntoConstraints = false
        blur.layer.cornerRadius = 18
        blur.clipsToBounds = true

        gateOverlayView.translatesAutoresizingMaskIntoConstraints = false
        gateOverlayView.isUserInteractionEnabled = false
        gateOverlayView.backgroundColor = .clear
        view.addSubview(gateOverlayView)
        NSLayoutConstraint.activate([
            gateOverlayView.topAnchor.constraint(equalTo: view.topAnchor),
            gateOverlayView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            gateOverlayView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            gateOverlayView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        routeGuideLayer.fillColor = UIColor.clear.cgColor
        routeGuideLayer.strokeColor = UIColor.systemGreen
            .withAlphaComponent(0.48).cgColor
        routeGuideLayer.lineWidth = 3
        routeGuideLayer.lineCap = .round
        routeGuideLayer.lineDashPattern = [8, 7]
        gateOverlayView.layer.addSublayer(routeGuideLayer)

        gateFillLayer.fillColor = UIColor.systemGreen
            .withAlphaComponent(0.13).cgColor
        gateFillLayer.strokeColor = UIColor.clear.cgColor
        gateOverlayView.layer.addSublayer(gateFillLayer)

        gateOutlineLayer.fillColor = UIColor.clear.cgColor
        gateOutlineLayer.strokeColor = UIColor.systemGreen.cgColor
        gateOutlineLayer.lineWidth = 4
        gateOutlineLayer.lineJoin = .round
        gateOutlineLayer.shadowColor = UIColor.systemGreen.cgColor
        gateOutlineLayer.shadowOpacity = 0.45
        gateOutlineLayer.shadowRadius = 7
        gateOverlayView.layer.addSublayer(gateOutlineLayer)

        segmentLabel.translatesAutoresizingMaskIntoConstraints = false
        segmentLabel.font = .systemFont(ofSize: 14, weight: .bold)
        segmentLabel.textColor = .white
        // IDs stay in the private WalkScan metadata; field users only need the task.
        segmentLabel.text = "人行道採集"

        guidanceLabel.translatesAutoresizingMaskIntoConstraints = false
        guidanceLabel.font = .systemFont(ofSize: 15, weight: .semibold)
        guidanceLabel.textColor = .white
        guidanceLabel.numberOfLines = 1
        guidanceLabel.adjustsFontSizeToFitWidth = true
        guidanceLabel.minimumScaleFactor = 0.78
        guidanceLabel.text = "點下方紅鍵開始採集"

        distanceLabel.translatesAutoresizingMaskIntoConstraints = false
        distanceLabel.font = .monospacedDigitSystemFont(ofSize: 13, weight: .medium)
        distanceLabel.textColor = .white
        distanceLabel.text = mission.captureMode == .freeRoute
            ? "已記錄 0.0 公尺"
            : "0.0 / \(String(format: "%.0f", mission.expectedTravelMeters)) 公尺"

        captureCountLabel.translatesAutoresizingMaskIntoConstraints = false
        captureCountLabel.font = .monospacedDigitSystemFont(ofSize: 13, weight: .semibold)
        captureCountLabel.textColor = .systemCyan
        captureCountLabel.text = "已自動拍攝 0 張"

        turnAroundButton.translatesAutoresizingMaskIntoConstraints = false
        turnAroundButton.setTitle("我已轉身｜開始回程", for: .normal)
        turnAroundButton.titleLabel?.font = .systemFont(ofSize: 16, weight: .bold)
        turnAroundButton.tintColor = .white
        turnAroundButton.backgroundColor = UIColor.systemOrange.withAlphaComponent(0.90)
        turnAroundButton.layer.cornerRadius = 12
        turnAroundButton.contentEdgeInsets = UIEdgeInsets(top: 11, left: 14, bottom: 11, right: 14)
        turnAroundButton.addTarget(self, action: #selector(markReturnTrip), for: .touchUpInside)
        turnAroundButton.isHidden = true

        trackingLabel.translatesAutoresizingMaskIntoConstraints = false
        trackingLabel.font = .systemFont(ofSize: 12, weight: .medium)
        trackingLabel.textColor = .systemYellow
        trackingLabel.text = "正在建立空間定位…"

        preflightLabel.translatesAutoresizingMaskIntoConstraints = false
        preflightLabel.font = .systemFont(ofSize: 12, weight: .medium)
        preflightLabel.textColor = .systemYellow
        preflightLabel.numberOfLines = 2
        preflightLabel.text = "正在檢查 LiDAR、定位、電量與儲存空間…"

        originStatusLabel.translatesAutoresizingMaskIntoConstraints = false
        originStatusLabel.font = .monospacedDigitSystemFont(
            ofSize: 12,
            weight: .medium
        )
        originStatusLabel.textColor = .systemYellow
        originStatusLabel.numberOfLines = 2
        originStatusLabel.text = "正在取得起點位置與手機方位…"

        lockOriginButton.translatesAutoresizingMaskIntoConstraints = false
        lockOriginButton.setTitle("鎖定起點與行進方向", for: .normal)
        lockOriginButton.titleLabel?.font = .systemFont(ofSize: 15, weight: .bold)
        lockOriginButton.tintColor = .white
        lockOriginButton.backgroundColor = UIColor.systemBlue.withAlphaComponent(0.82)
        lockOriginButton.layer.cornerRadius = 12
        lockOriginButton.contentEdgeInsets = UIEdgeInsets(
            top: 10,
            left: 14,
            bottom: 10,
            right: 14
        )
        lockOriginButton.addTarget(
            self,
            action: #selector(lockCaptureOrigin),
            for: .touchUpInside
        )

        aimLabel.translatesAutoresizingMaskIntoConstraints = false
        aimLabel.font = .systemFont(ofSize: 12, weight: .medium)
        aimLabel.textColor = .white
        aimLabel.text = "將圓圈對準前方，手機保持平穩"

        diagnosticsButton.translatesAutoresizingMaskIntoConstraints = false
        diagnosticsButton.setImage(
            UIImage(systemName: "chevron.down.circle.fill"),
            for: .normal
        )
        diagnosticsButton.tintColor = UIColor.white.withAlphaComponent(0.82)
        diagnosticsButton.accessibilityLabel = "展開定位與裝置詳情"
        diagnosticsButton.addTarget(
            self,
            action: #selector(toggleDiagnostics),
            for: .touchUpInside
        )

        missionProgress.translatesAutoresizingMaskIntoConstraints = false
        missionProgress.trackTintColor = UIColor.white.withAlphaComponent(0.2)
        missionProgress.progressTintColor = .systemGreen
        missionProgress.layer.cornerRadius = 3
        missionProgress.clipsToBounds = true

        let headerRow = UIStackView(arrangedSubviews: [
            guidanceLabel,
            diagnosticsButton
        ])
        headerRow.axis = .horizontal
        headerRow.alignment = .center
        headerRow.spacing = 8

        let metricsRow = UIStackView(arrangedSubviews: [
            distanceLabel,
            UIView(),
            captureCountLabel
        ])
        metricsRow.axis = .horizontal
        metricsRow.alignment = .center
        metricsRow.spacing = 8

        let diagnostics = UIStackView(arrangedSubviews: [
            preflightLabel,
            trackingLabel,
            aimLabel
        ])
        diagnostics.axis = .vertical
        diagnostics.spacing = 3
        diagnostics.isHidden = true
        diagnosticsStack = diagnostics

        let stack = UIStackView(arrangedSubviews: [
            headerRow,
            originStatusLabel,
            lockOriginButton,
            metricsRow,
            turnAroundButton,
            missionProgress,
            diagnostics
        ])
        stack.axis = .vertical
        stack.spacing = 5
        stack.translatesAutoresizingMaskIntoConstraints = false
        blur.contentView.addSubview(stack)
        view.addSubview(blur)

        captureReticle.translatesAutoresizingMaskIntoConstraints = false
        captureReticle.layer.borderWidth = 3
        captureReticle.layer.borderColor = UIColor.systemGreen.cgColor
        captureReticle.layer.cornerRadius = 34
        captureReticle.backgroundColor = UIColor.clear
        view.addSubview(captureReticle)

        let arrow = UIImageView(image: UIImage(systemName: "arrow.up"))
        arrow.translatesAutoresizingMaskIntoConstraints = false
        arrow.tintColor = .systemGreen
        arrow.contentMode = .scaleAspectFit
        captureReticle.addSubview(arrow)

        NSLayoutConstraint.activate([
            blur.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 8),
            blur.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10),
            blur.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -10),

            stack.topAnchor.constraint(equalTo: blur.contentView.topAnchor, constant: 9),
            stack.leadingAnchor.constraint(equalTo: blur.contentView.leadingAnchor, constant: 12),
            stack.trailingAnchor.constraint(equalTo: blur.contentView.trailingAnchor, constant: -12),
            stack.bottomAnchor.constraint(equalTo: blur.contentView.bottomAnchor, constant: -9),
            missionProgress.heightAnchor.constraint(equalToConstant: 4),
            diagnosticsButton.widthAnchor.constraint(equalToConstant: 30),
            diagnosticsButton.heightAnchor.constraint(equalToConstant: 30),

            captureReticle.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            captureReticle.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -40),
            captureReticle.widthAnchor.constraint(equalToConstant: 68),
            captureReticle.heightAnchor.constraint(equalToConstant: 68),

            arrow.centerXAnchor.constraint(equalTo: captureReticle.centerXAnchor),
            arrow.centerYAnchor.constraint(equalTo: captureReticle.centerYAnchor),
            arrow.widthAnchor.constraint(equalToConstant: 28),
            arrow.heightAnchor.constraint(equalToConstant: 28)
        ])
    }

    @objc private func toggleDiagnostics() {
        diagnosticsExpanded.toggle()
        diagnosticsStack?.isHidden = !diagnosticsExpanded
        diagnosticsButton.setImage(
            UIImage(
                systemName: diagnosticsExpanded
                    ? "chevron.up.circle.fill"
                    : "chevron.down.circle.fill"
            ),
            for: .normal
        )
        diagnosticsButton.accessibilityLabel = diagnosticsExpanded
            ? "收起定位與裝置詳情"
            : "展開定位與裝置詳情"
    }

    @objc private func lockCaptureOrigin() {
        guard let location = latestLocation,
              location.horizontalAccuracy >= 0 else {
            originStatusLabel.text = "尚未取得GPS位置，請停在起點稍候"
            originStatusLabel.textColor = .systemYellow
            return
        }
        guard location.horizontalAccuracy <= 35 else {
            originStatusLabel.text = String(
                format: "GPS精度目前 ±%.0f公尺，請停留等待精度改善",
                location.horizontalAccuracy
            )
            originStatusLabel.textColor = .systemYellow
            return
        }
        guard let heading = latestHeading,
              heading.headingAccuracy >= 0,
              heading.headingAccuracy <= 25 else {
            originStatusLabel.text = "方位尚未穩定，請將手機朝行進方向稍候"
            originStatusLabel.textColor = .systemYellow
            return
        }

        let degrees = heading.trueHeading >= 0
            ? heading.trueHeading
            : heading.magneticHeading
        lockedOriginLocation = location
        lockedOrigin = WalkCaptureOrigin(
            latitude: location.coordinate.latitude,
            longitude: location.coordinate.longitude,
            altitude: location.altitude,
            horizontalAccuracyMeters: location.horizontalAccuracy,
            verticalAccuracyMeters: location.verticalAccuracy,
            headingDegrees: degrees,
            headingAccuracyDegrees: heading.headingAccuracy,
            lockedAt: Date()
        )

        originStatusLabel.text = String(
            format: "起點已鎖定｜GPS ±%.0f公尺｜%@ %.0f°",
            location.horizontalAccuracy,
            cardinalDirection(degrees),
            degrees
        )
        originStatusLabel.textColor = .systemGreen
        lockOriginButton.setTitle("起點已鎖定｜點此重設", for: .normal)
        originStatusLabel.isHidden = true
        recordButton.setCaptureEnabled(true)
        resetWalkGuide()
        guideCanCreateGate = true
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
    }

    private func updateOriginStatus() {
        guard lockedOrigin == nil, startedRecording == nil else { return }

        let locationText: String
        if let location = latestLocation,
           location.horizontalAccuracy >= 0 {
            locationText = String(
                format: "GPS ±%.0f公尺",
                location.horizontalAccuracy
            )
        } else {
            locationText = "GPS 等待中"
        }

        let headingText: String
        if let heading = latestHeading,
           heading.headingAccuracy >= 0 {
            let degrees = heading.trueHeading >= 0
                ? heading.trueHeading
                : heading.magneticHeading
            headingText = String(
                format: "%@ %.0f°",
                cardinalDirection(degrees),
                degrees
            )
        } else {
            headingText = "方位等待中"
        }
        originStatusLabel.text = "\(locationText)｜\(headingText)"
    }

    private func cardinalDirection(_ degrees: Double) -> String {
        let directions = ["北", "東北", "東", "東南", "南", "西南", "西", "西北"]
        let normalized = degrees.truncatingRemainder(dividingBy: 360)
        let positive = normalized >= 0 ? normalized : normalized + 360
        let index = Int((positive + 22.5) / 45.0) % directions.count
        return directions[index]
    }

    private func updateMissionProgress(frame: ARFrame) {
        guard frame.timestamp - lastProgressSampleTimestamp >= 0.25 else { return }
        lastProgressSampleTimestamp = frame.timestamp

        let transform = frame.camera.transform
        let current = SIMD3<Float>(
            transform.columns.3.x,
            0,
            transform.columns.3.z
        )
        defer { lastProgressPosition = current }
        guard let previous = lastProgressPosition else { return }

        let step = simd_distance(current, previous)
        // Ignore tracking jitter and implausible relocalisation jumps.
        guard step >= 0.02, step <= 0.75 else { return }
        travelledMeters += Double(step)

        if mission.captureMode == .freeRoute {
            distanceLabel.text = String(format: "已記錄 %.1f 公尺", travelledMeters)
            guidanceLabel.text = isReturnTrip
                ? "回程拍攝中；沿原路走回"
                : "去程拍攝中；轉身後按一次按鈕"
            return
        }

        let expected = max(mission.expectedTravelMeters, 0.1)
        let progress = min(Float(travelledMeters / expected), 1)
        missionProgress.setProgress(progress, animated: true)
        distanceLabel.text = String(
            format: "%.1f / %.0f 公尺",
            travelledMeters,
            expected
        )

        if !completionWasAnnounced,
           travelledMeters >= expected {
            completionWasAnnounced = true
            guidanceLabel.text = "往返完成，點下方紅鍵結束並歸檔"
            missionProgress.progressTintColor = .systemCyan
            UINotificationFeedbackGenerator().notificationOccurred(.success)
        } else if mission.requiresReturnTrip,
                  !turnWasAnnounced,
                  travelledMeters >= mission.targetLengthMeters {
            turnWasAnnounced = true
            guideAwaitingReturnTurn = true
            guideReturnReferenceDirection =
                activeGuideGate?.direction ?? previousGuideDirection
            guidanceLabel.text = "已到端點，請轉身沿原路返回"
            UINotificationFeedbackGenerator().notificationOccurred(.warning)
        } else if completionWasAnnounced {
            guidanceLabel.text = "往返完成，點下方紅鍵結束並歸檔"
        } else if mission.requiresReturnTrip && turnWasAnnounced {
            guidanceLabel.text = "沿原路返回起點"
        }
    }

    private func updateTrackingLabel(_ state: ARCamera.TrackingState) {
        switch state {
        case .normal:
            trackingLabel.text = "LiDAR 與空間定位正常"
            trackingLabel.textColor = .systemGreen
        case .limited(let reason):
            trackingLabel.textColor = .systemYellow
            switch reason {
            case .excessiveMotion:
                trackingLabel.text = "請放慢移動速度"
            case .insufficientFeatures:
                trackingLabel.text = "請讓畫面包含地面與周邊物件"
            case .initializing, .relocalizing:
                trackingLabel.text = "正在建立空間定位…"
            @unknown default:
                trackingLabel.text = "定位品質受限，請慢慢移動"
            }
        case .notAvailable:
            trackingLabel.text = "暫時無法定位"
            trackingLabel.textColor = .systemRed
        }
        updatePreflightLabel()
    }

    private func updatePreflightLabel() {
        var notices: [String] = []
        if unsupported {
            notices.append("LiDAR 不可用")
        }
        if ProcessInfo.processInfo.isLowPowerModeEnabled {
            notices.append("低耗電模式已開啟")
        }
        let battery = UIDevice.current.batteryLevel
        if battery >= 0, battery < 0.20 {
            notices.append("電量低於 20%")
        }
        if let documentURL = FileManager.default.urls(
            for: .documentDirectory,
            in: .userDomainMask
        ).first,
           let values = try? documentURL.resourceValues(
            forKeys: [.volumeAvailableCapacityForImportantUsageKey]
           ),
           let available = values.volumeAvailableCapacityForImportantUsage,
           available < 750_000_000 {
            notices.append("可用空間低於 750 MB")
        }
        if notices.isEmpty {
            preflightLabel.text = "裝置檢查正常"
            preflightLabel.textColor = .systemGreen
        } else {
            preflightLabel.text = notices.joined(separator: "｜")
            preflightLabel.textColor = .systemYellow
        }
    }

    private func updateAimGuide(_ camera: ARCamera) {
        guard CACurrentMediaTime() >= stationFeedbackVisibleUntil else { return }
        let forwardY = -camera.transform.columns.2.y
        let isReady = abs(forwardY) <= 0.32

        if let pendingFacePrompt, startedRecording != nil {
            aimLabel.text = pendingFacePrompt
            aimLabel.textColor = .systemCyan
        } else if abs(forwardY) > 0.32 {
            aimLabel.text = "請讓鏡頭接近水平，保留前方與地面"
            aimLabel.textColor = .systemYellow
        } else {
            aimLabel.text = startedRecording == nil
                ? "方向良好，按紅鍵後開始"
                : "方向良好；起點、約每 4 公尺與尾端自動拍攝"
            aimLabel.textColor = .systemGreen
        }

        captureReticle.layer.borderColor = (
            isReady ? UIColor.systemGreen : UIColor.systemYellow
        ).cgColor
    }

    private func announceStationCapture(update: WalkCaptureUpdate) {
        let count = update.stationSequence + 1
        stationFeedbackVisibleUntil = CACurrentMediaTime() + 0.8
        captureCountLabel.text = mission.captureProfile == .sixFace
            ? "節點 \(count)｜六向 \(update.capturedFaceCount)/\(update.requiredFaceCount)"
            : "已自動拍攝 \(count) 張"
        if update.isStationComplete {
            pendingFacePrompt = nil
            aimLabel.text = "第 \(count) 個空間節點已完成"
            guidanceLabel.text = "繼續沿動線前進至下一個拍攝點"
            completeGuideStation(sequence: update.stationSequence)
        } else if let prompt = update.nextPrompt {
            pendingFacePrompt = "停下｜\(update.capturedFaceCount + 1)/\(update.requiredFaceCount) \(prompt)"
            aimLabel.text = "已取得\(update.face.prompt)；下一步：\(prompt)"
            guidanceLabel.text = "請停在原地，依準星完成這個節點"
            UIAccessibility.post(notification: .announcement, argument: prompt)
        } else {
            aimLabel.text = "第 \(count) 個節點資料不完整，可於完成後補拍"
        }
        aimLabel.textColor = .systemCyan
        UIImpactFeedbackGenerator(style: .light).impactOccurred()

        UIView.animate(
            withDuration: 0.08,
            animations: {
                self.captureReticle.backgroundColor = UIColor.white.withAlphaComponent(0.65)
                self.captureReticle.transform = CGAffineTransform(scaleX: 1.12, y: 1.12)
            },
            completion: { _ in
                UIView.animate(withDuration: 0.18) {
                    self.captureReticle.backgroundColor = .clear
                    self.captureReticle.transform = .identity
                }
            }
        )
    }

    private func resetWalkGuide() {
        activeGuideGate = nil
        previousGuideDirection = nil
        guideCanCreateGate = mission.captureProfile == .quickRoute
        guideGateReached = false
        guideNextSequence = 1
        guideCompletedDistanceMeters = 0
        lastGuidePlanTimestamp = -1
        lastGuideRenderState = ""
        guideAwaitingReturnTurn = false
        guideReturnReferenceDirection = nil
        hideWalkGuide()
    }

    private func hideWalkGuide() {
        gateFillLayer.path = nil
        gateOutlineLayer.path = nil
        routeGuideLayer.path = nil
        gateOverlayView.isHidden = true
    }

    private func completeGuideStation(sequence: Int) {
        if sequence == 0 && activeGuideGate == nil {
            guideCanCreateGate = true
            return
        }
        guard guideGateReached,
              sequence == guideNextSequence else {
            return
        }
        activeGuideGate = nil
        guideGateReached = false
        guideNextSequence += 1
        guideCanCreateGate = true
        lastGuidePlanTimestamp = -1
        lastGuideRenderState = ""
    }

    private func updateWalkGuide(frame: ARFrame) {
        guard case .normal = frame.camera.trackingState else {
            gateOverlayView.isHidden = true
            return
        }

        if activeGuideGate == nil,
           guideCanCreateGate,
           guideAwaitingReturnTurn {
            var forward = -SIMD3<Float>(
                frame.camera.transform.columns.2.x,
                0,
                frame.camera.transform.columns.2.z
            )
            if simd_length(forward) > 0.001 {
                forward = simd_normalize(forward)
            }
            if let reference = guideReturnReferenceDirection,
               simd_dot(forward, reference) <= -0.55 {
                guideAwaitingReturnTurn = false
                previousGuideDirection = nil
                lastGuidePlanTimestamp = -1
            } else {
                hideWalkGuide()
                aimLabel.text = "請轉身面向回程方向，下一道光門會自動出現"
                aimLabel.textColor = .systemYellow
                return
            }
        }

        if activeGuideGate == nil,
           guideCanCreateGate,
           frame.timestamp - lastGuidePlanTimestamp >= 0.20 {
            lastGuidePlanTimestamp = frame.timestamp
            if let plan = inferRollingWalkPlan(frame: frame) {
                let cameraPosition = worldPosition(frame.camera.transform)
                let center = SIMD3<Float>(
                    cameraPosition.x + plan.direction.x * 2.0,
                    plan.floorY,
                    cameraPosition.z + plan.direction.z * 2.0
                )
                activeGuideGate = WalkGuideGate(
                    sequence: guideNextSequence,
                    center: center,
                    direction: plan.direction,
                    widthMeters: plan.widthMeters,
                    floorY: plan.floorY,
                    confidence: plan.confidence
                )
                previousGuideDirection = plan.direction
                guideCanCreateGate = false
            }
        }

        guard let gate = activeGuideGate else {
            hideWalkGuide()
            return
        }
        renderWalkGuide(gate: gate, frame: frame)
        guard startedRecording != nil else { return }
        guard !guideGateReached else { return }

        let cameraPosition = worldPosition(frame.camera.transform)
        let cameraToGate = SIMD3<Float>(
            gate.center.x - cameraPosition.x,
            0,
            gate.center.z - cameraPosition.z
        )
        let left = SIMD3<Float>(
            -gate.direction.z,
            0,
            gate.direction.x
        )
        let forwardDistance = simd_dot(cameraToGate, gate.direction)
        let lateralDistance = abs(simd_dot(cameraToGate, left))
        if forwardDistance <= 0.08,
           lateralDistance <= max(0.72, gate.widthMeters * 0.60) {
            guideGateReached = true
            guideCompletedDistanceMeters = max(
                guideCompletedDistanceMeters,
                Double(gate.sequence) * 2.0
            )
            guidanceLabel.text = mission.captureProfile == .sixFace
                ? "已穿過第 \(gate.sequence) 道光門；請停下完成五個方向"
                : "已穿過第 \(gate.sequence) 道光門；正在自動保存"
            aimLabel.text = "光門通過"
            aimLabel.textColor = .systemCyan
            UINotificationFeedbackGenerator().notificationOccurred(.success)
        }
    }

    private func inferRollingWalkPlan(frame: ARFrame) -> WalkGuidePlan? {
        let verticalLook = -frame.camera.transform.columns.2.y
        guard abs(verticalLook) <= 0.38 else {
            return nil
        }
        let cameraTransform = frame.camera.transform
        let cameraPosition = worldPosition(cameraTransform)
        var cameraForward = -SIMD3<Float>(
            cameraTransform.columns.2.x,
            0,
            cameraTransform.columns.2.z
        )
        guard simd_length(cameraForward) > 0.001 else { return nil }
        cameraForward = simd_normalize(cameraForward)

        let sampledPoints = sampleFloorPoints(
            frame: frame,
            viewportSize: rgbView.bounds.size
        )
        let plausible = sampledPoints.filter { point in
            let drop = cameraPosition.y - point.y
            let horizontal = simd_distance(
                SIMD2<Float>(cameraPosition.x, cameraPosition.z),
                SIMD2<Float>(point.x, point.z)
            )
            return drop >= 0.55
                && drop <= 2.35
                && horizontal >= 0.35
                && horizontal <= 5.2
        }

        let fallbackFloor = cameraPosition.y - 1.45
        guard plausible.count >= 5 else {
            return WalkGuidePlan(
                direction: smoothedGuideDirection(
                    cameraForward,
                    cameraForward: cameraForward
                ),
                floorY: fallbackFloor,
                widthMeters: 1.40,
                confidence: 0.28
            )
        }

        let sortedY = plausible.map(\.y).sorted()
        let floorIndex = min(
            sortedY.count - 1,
            max(0, Int(Double(sortedY.count) * 0.35))
        )
        let floorY = sortedY[floorIndex]
        let floorPoints = plausible.filter { abs($0.y - floorY) <= 0.18 }
        guard floorPoints.count >= 4 else {
            return WalkGuidePlan(
                direction: smoothedGuideDirection(
                    cameraForward,
                    cameraForward: cameraForward
                ),
                floorY: floorY,
                widthMeters: 1.35,
                confidence: 0.38
            )
        }

        var directionSum = SIMD3<Float>(repeating: 0)
        var directionWeight: Float = 0
        for point in floorPoints {
            var vector = SIMD3<Float>(
                point.x - cameraPosition.x,
                0,
                point.z - cameraPosition.z
            )
            let distance = simd_length(vector)
            guard distance >= 0.70 else { continue }
            vector /= distance
            let facing = max(0, simd_dot(vector, cameraForward))
            let weight = min(distance, 4.0) * facing * facing
            directionSum += vector * weight
            directionWeight += weight
        }

        let observedDirection: SIMD3<Float>
        if directionWeight > 0.01,
           simd_length(directionSum) > 0.001 {
            observedDirection = simd_normalize(directionSum)
        } else {
            observedDirection = cameraForward
        }
        let blended = simd_normalize(
            observedDirection * 0.42 + cameraForward * 0.58
        )
        let direction = smoothedGuideDirection(
            blended,
            cameraForward: cameraForward
        )
        let left = SIMD3<Float>(-direction.z, 0, direction.x)
        let lateralValues = floorPoints.map { point in
            simd_dot(
                SIMD3<Float>(
                    point.x - cameraPosition.x,
                    0,
                    point.z - cameraPosition.z
                ),
                left
            )
        }
        let lateralSpan = (lateralValues.max() ?? 0)
            - (lateralValues.min() ?? 0)
        let width = min(2.2, max(1.05, lateralSpan * 0.82))
        let confidence = min(
            0.92,
            0.42 + Float(floorPoints.count) / 65.0
        )
        return WalkGuidePlan(
            direction: direction,
            floorY: floorY,
            widthMeters: width,
            confidence: confidence
        )
    }

    private func smoothedGuideDirection(
        _ candidate: SIMD3<Float>,
        cameraForward: SIMD3<Float>
    ) -> SIMD3<Float> {
        guard let previousGuideDirection,
              simd_dot(previousGuideDirection, cameraForward) > -0.15 else {
            return simd_normalize(candidate)
        }
        let mixed = previousGuideDirection * 0.46 + candidate * 0.54
        guard simd_length(mixed) > 0.001 else {
            return simd_normalize(candidate)
        }
        return simd_normalize(mixed)
    }

    private func sampleFloorPoints(
        frame: ARFrame,
        viewportSize: CGSize
    ) -> [SIMD3<Float>] {
        guard viewportSize.width > 0,
              viewportSize.height > 0,
              let sceneDepth = frame.smoothedSceneDepth ?? frame.sceneDepth else {
            return []
        }
        let depthMap = sceneDepth.depthMap
        let confidenceMap = sceneDepth.confidenceMap
        CVPixelBufferLockBaseAddress(depthMap, .readOnly)
        if let confidenceMap {
            CVPixelBufferLockBaseAddress(confidenceMap, .readOnly)
        }
        defer {
            CVPixelBufferUnlockBaseAddress(depthMap, .readOnly)
            if let confidenceMap {
                CVPixelBufferUnlockBaseAddress(confidenceMap, .readOnly)
            }
        }

        guard let depthBase = CVPixelBufferGetBaseAddress(depthMap) else {
            return []
        }
        let depthWidth = CVPixelBufferGetWidth(depthMap)
        let depthHeight = CVPixelBufferGetHeight(depthMap)
        let depthRowBytes = CVPixelBufferGetBytesPerRow(depthMap)
        let confidenceBase: UnsafeMutableRawPointer?
        let confidenceRowBytes: Int
        if let confidenceMap {
            confidenceBase = CVPixelBufferGetBaseAddress(confidenceMap)
            confidenceRowBytes = CVPixelBufferGetBytesPerRow(confidenceMap)
        } else {
            confidenceBase = nil
            confidenceRowBytes = 0
        }
        let capturedWidth = Float(
            CVPixelBufferGetWidth(frame.capturedImage)
        )
        let capturedHeight = Float(
            CVPixelBufferGetHeight(frame.capturedImage)
        )
        let scaleX = Float(depthWidth) / max(capturedWidth, 1)
        let scaleY = Float(depthHeight) / max(capturedHeight, 1)
        let intrinsics = frame.camera.intrinsics
        let fx = intrinsics.columns.0.x * scaleX
        let fy = intrinsics.columns.1.y * scaleY
        let cx = intrinsics.columns.2.x * scaleX
        let cy = intrinsics.columns.2.y * scaleY
        guard fx > 0.001, fy > 0.001 else { return [] }

        let displayToImage = frame.displayTransform(
            for: .portrait,
            viewportSize: viewportSize
        ).inverted()
        let screenXs: [CGFloat] = [
            0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80
        ]
        let screenYs: [CGFloat] = [
            0.53, 0.60, 0.67, 0.74, 0.81, 0.88
        ]
        var points: [SIMD3<Float>] = []
        points.reserveCapacity(screenXs.count * screenYs.count)

        for screenY in screenYs {
            for screenX in screenXs {
                let imagePoint = CGPoint(
                    x: screenX,
                    y: screenY
                ).applying(displayToImage)
                guard imagePoint.x >= 0,
                      imagePoint.x <= 1,
                      imagePoint.y >= 0,
                      imagePoint.y <= 1 else {
                    continue
                }
                let u = min(
                    depthWidth - 1,
                    max(0, Int(imagePoint.x * CGFloat(depthWidth - 1)))
                )
                let v = min(
                    depthHeight - 1,
                    max(0, Int(imagePoint.y * CGFloat(depthHeight - 1)))
                )
                let depthRow = depthBase.advanced(
                    by: v * depthRowBytes
                ).assumingMemoryBound(to: Float32.self)
                let depth = depthRow[u]
                guard depth.isFinite,
                      depth >= 0.25,
                      depth <= 5.2 else {
                    continue
                }
                if let confidenceBase {
                    let row = confidenceBase.advanced(
                        by: v * confidenceRowBytes
                    ).assumingMemoryBound(to: UInt8.self)
                    guard row[u] >= 1 else { continue }
                }
                let cameraPoint = SIMD4<Float>(
                    (Float(u) - cx) * depth / fx,
                    -(Float(v) - cy) * depth / fy,
                    -depth,
                    1
                )
                let worldPoint = frame.camera.transform * cameraPoint
                points.append(
                    SIMD3<Float>(
                        worldPoint.x,
                        worldPoint.y,
                        worldPoint.z
                    )
                )
            }
        }
        return points
    }

    private func renderWalkGuide(
        gate: WalkGuideGate,
        frame: ARFrame
    ) {
        let viewportSize = gateOverlayView.bounds.size
        guard viewportSize.width > 0, viewportSize.height > 0 else { return }
        let cameraPosition = worldPosition(frame.camera.transform)
        var cameraForward = -SIMD3<Float>(
            frame.camera.transform.columns.2.x,
            0,
            frame.camera.transform.columns.2.z
        )
        guard simd_length(cameraForward) > 0.001 else {
            hideWalkGuide()
            return
        }
        cameraForward = simd_normalize(cameraForward)
        let toGate = SIMD3<Float>(
            gate.center.x - cameraPosition.x,
            0,
            gate.center.z - cameraPosition.z
        )
        guard simd_dot(toGate, cameraForward) > -0.35 else {
            hideWalkGuide()
            return
        }

        let left = SIMD3<Float>(
            -gate.direction.z,
            0,
            gate.direction.x
        )
        let halfWidth = gate.widthMeters * 0.5
        let lowerY = gate.floorY + 0.04
        let upperY = gate.floorY + 2.05
        let lowerLeft = gate.center + left * halfWidth
            + SIMD3<Float>(0, lowerY - gate.center.y, 0)
        let lowerRight = gate.center - left * halfWidth
            + SIMD3<Float>(0, lowerY - gate.center.y, 0)
        let upperLeft = gate.center + left * halfWidth
            + SIMD3<Float>(0, upperY - gate.center.y, 0)
        let upperRight = gate.center - left * halfWidth
            + SIMD3<Float>(0, upperY - gate.center.y, 0)
        let projected = [
            lowerLeft,
            upperLeft,
            upperRight,
            lowerRight
        ].map {
            frame.camera.projectPoint(
                $0,
                orientation: .portrait,
                viewportSize: viewportSize
            )
        }
        guard projected.allSatisfy({
            $0.x.isFinite && $0.y.isFinite
        }) else {
            hideWalkGuide()
            return
        }

        let gatePath = UIBezierPath()
        gatePath.move(to: projected[0])
        projected.dropFirst().forEach { gatePath.addLine(to: $0) }
        gatePath.close()
        gateOutlineLayer.path = gatePath.cgPath
        gateFillLayer.path = gatePath.cgPath

        let bottomCenter = CGPoint(
            x: (projected[0].x + projected[3].x) * 0.5,
            y: (projected[0].y + projected[3].y) * 0.5
        )
        let routePath = UIBezierPath()
        routePath.move(
            to: CGPoint(
                x: viewportSize.width * 0.5,
                y: viewportSize.height * 0.91
            )
        )
        routePath.addLine(to: bottomCenter)
        routeGuideLayer.path = routePath.cgPath

        let signedLateral = simd_dot(toGate, left)
        let allowed = max(0.55, gate.widthMeters * 0.45)
        let color: UIColor
        let state: String
        if guideGateReached {
            color = .systemCyan
            state = "reached"
        } else if abs(signedLateral) <= allowed {
            color = .systemGreen
            state = "aligned"
        } else {
            color = .systemYellow
            state = signedLateral > 0 ? "left" : "right"
        }
        gateOutlineLayer.strokeColor = color.cgColor
        gateOutlineLayer.shadowColor = color.cgColor
        gateFillLayer.fillColor = color.withAlphaComponent(0.13).cgColor
        routeGuideLayer.strokeColor = color.withAlphaComponent(0.50).cgColor
        gateOverlayView.isHidden = false

        guard pendingFacePrompt == nil,
              CACurrentMediaTime() >= stationFeedbackVisibleUntil,
              state != lastGuideRenderState else {
            return
        }
        lastGuideRenderState = state
        if state == "left" {
            aimLabel.text = "向左靠近光門"
            aimLabel.textColor = .systemYellow
        } else if state == "right" {
            aimLabel.text = "向右靠近光門"
            aimLabel.textColor = .systemYellow
        } else if state == "aligned" {
            aimLabel.text = String(
                format: "沿綠線穿過第 %d 道光門｜地面信心 %.0f%%",
                gate.sequence,
                gate.confidence * 100
            )
            aimLabel.textColor = .systemGreen
        }
    }

    private func worldPosition(
        _ transform: simd_float4x4
    ) -> SIMD3<Float> {
        SIMD3<Float>(
            transform.columns.3.x,
            transform.columns.3.y,
            transform.columns.3.z
        )
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let newest = locations.last else { return }
        latestLocation = newest
        locations.forEach { datasetEncoder?.add(location: $0) }
        updateOriginStatus()
    }

    func locationManager(_ manager: CLLocationManager, didUpdateHeading newHeading: CLHeading) {
        guard newHeading.headingAccuracy >= 0 else { return }
        latestHeading = newHeading
        updateOriginStatus()
    }
    
    private func updateFpsSetting() {
        let fps = AvailableFpsSettings[chosenFpsSetting]
        let buttonLabel: String = "\(fps) fps"
        fpsButton.setTitle(buttonLabel, for: UIControl.State.normal)
    }
    
    private func showUnsupportedAlert() {
        let alert = UIAlertController(title: "Unsupported device", message: "This device doesn't seem to have the required level of ARKit support.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
            self.dismissFunction?()
        }))
        self.present(alert, animated: true)
    }
    
    private func countSessions() -> Int {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return 0 }
        let request = NSFetchRequest<NSManagedObject>(entityName: "Recording")
        do {
            let fetched: [NSManagedObject] = try appDelegate.persistentContainer.viewContext.fetch(request)
            return fetched.count
        } catch let error {
            print("Could not fetch sessions for counting. \(error.localizedDescription)")
        }
        return 0
    }
}
