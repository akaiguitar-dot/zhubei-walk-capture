//
//  InformationView.swift
//  StrayScanner
//
//  Created by Kenneth Blomqvist on 2/28/21.
//

import SwiftUI

struct InformationView: View {
    let paddingLeftRight: CGFloat = 15
    let paddingTextTop: CGFloat = 10

    var body: some View {
        ZStack {
            Color("BackgroundColor").ignoresSafeArea()
            ScrollView {
                VStack(alignment: .leading) {
                    Text("竹北人行道採集")
                        .font(.title)
                        .fontWeight(.bold)

                    bodyText("""
                    這個 App 把你走過的人行道整理成有順序的空間證據。它會保存照片、LiDAR 深度、手機方向、連續路徑與定位，再交由 Windows 電腦產生網站所需的路徑、節點與六面空間資料。
                    """)

                    heading("兩種採集模式")
                    bodyText("""
                    快速路線：沿著人行道前進，約每 4 公尺自動保存一個前向節點。

                    事件補拍：只在需要時拍地面、建築側或道路側；缺少的方向會被標記，不會假裝資料完整。
                    """)

                    heading("現場操作")
                    bodyText("""
                    1. 選擇 GIS 路段或自由動線。
                    2. 選擇快速路線或六面採集。
                    3. 六面模式要指定建築位於左側或右側。
                    4. 等待定位、LiDAR、電量與儲存空間檢查完成。
                    5. 鎖定起點後，App 會在前方地面建立第一道 AR 光門。
                    6. 按開始後只要沿綠線穿過光門；通過時會自動拍照並震動。
                    7. App 會依新的地面與手機朝向繼續建立下一道光門。
                    8. 結束後資料會保存在手機，並排入私密傳送。
                    """)

                    heading("資料與隱私")
                    bodyText("""
                    原始 .walkscan 可能包含精確位置、未遮蔽照片與感測資料，只會傳到你設定的區域網路 Windows 接收器，不會成為公共通報內容。

                    若設定自己的 HTTPS 私人雲端與金鑰，也能在外出採集後直接排隊上傳並開始處理。

                    快速問題通報是另一條流程。照片會先在手機上偵測並遮蔽臉部與疑似車牌，保存成獨立草稿；未審核內容不公開。
                    """)

                    heading("坡度說明")
                    bodyText("""
                    電腦可利用 LiDAR 深度與手機姿態推估地面橫向坡度及縱向坡度。這是現場問題辨識的參考資料，不是工程測量或法規認證數值。
                    """)

                    heading("開源基礎")
                    bodyText("LiDAR RGB-D 採集核心源自 Stray Scanner 開源專案，本版本加入人行道任務、節點引導、資料契約與私密傳送。")
                    link(text: "查看原始開源專案", destination: "https://github.com/StrayRobots/scanner")

                    heading("免責聲明")
                    bodyText("本工具用於人行環境觀察與資料整理。使用者仍須遵守現場安全、隱私與相關法規；所有自動分析結果都應保留人工覆核的可能。")
                    Spacer()
                }
                .padding(.all, paddingLeftRight)
            }
            .frame(
                minWidth: 0,
                maxWidth: .infinity,
                maxHeight: .infinity,
                alignment: .topLeading
            )
        }
    }

    private func heading(_ text: String) -> some View {
        Text(text)
            .font(.title3)
            .fontWeight(.bold)
            .padding(.top, 20)
    }

    private func bodyText(_ text: String) -> some View {
        Text(text)
            .font(.body)
            .multilineTextAlignment(.leading)
            .lineSpacing(1.25)
            .padding(.top, paddingTextTop)
    }

    private func link(text: String, destination: String) -> some View {
        Text(text)
            .font(.body)
            .foregroundColor(Color.blue)
            .padding(.top, paddingTextTop)
            .onTapGesture {
                guard let destinationURL = URL(string: destination) else { return }
                UIApplication.shared.open(destinationURL)
            }
    }
}

struct InformationView_Previews: PreviewProvider {
    static var previews: some View {
        InformationView()
    }
}
