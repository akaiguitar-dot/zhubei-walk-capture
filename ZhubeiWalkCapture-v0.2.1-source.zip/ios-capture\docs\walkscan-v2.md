# WalkScan v2：人行動線採集資料契約

> 此文件保留供既有錄影資料包參考。新版 App 已改用不錄影的
> [WalkScan v3 自動照片格式](walkscan-v3.md)。

WalkScan v2 的目的不是直接在手機內製作完整實景模型，而是保存足以讓電腦重建「可讀的點、線、面動線空間」的觀測資料。

## 兩種採集模式

- `mapped_segment`：已知 GIS 路段編號與長度，可檢查去程、回程和完成度。
- `free_route`：不預設長度。使用者可自由行走與轉彎，直到手動停止。

兩種模式都保存 ARKit 相機軌跡。ARKit 使用 `gravityAndHeading` 對齊，正 x、y、z 軸分別朝東、上、南。電腦端會將軌跡平滑為動線中心線，依局部前進方向建立垂直剖面；因此最後的空間帶可以沿著實際路徑彎曲，而不是只能建立筆直矩形。

## 每 1 公尺空間節點

App 依 ARKit 的累積水平位移，每 1 公尺建立一個 station。每個 station 包含：

- 唯一編號，例如 `ZB-WALK-00428-F-003` 或 `FREE-TEST-P-003`
- 去程、回程或自由路線標記
- 路徑上的公尺位置
- 對應的彩色照片
- 對應的 LiDAR 深度圖與可信度圖
- 對應的錄影及 odometry 幀號
- 相機三維位置、四元數方向、Euler 角
- 相機內部參數
- ARKit 追蹤品質
- ARKit 開機相對時間與可和 GPS 對齊的 Unix epoch 時間

完整相機軌跡仍逐幀保存在 `odometry.csv`，station 只是穩定、可編號、便於網站與重建程式引用的主節點。

## 資料夾

```text
mission.json
stations.json
stations/
  station-000000.jpg
  station-000001.jpg
rgb.mp4
odometry.csv
imu.csv
locations.csv
camera_matrix.csv
depth/
  000000.png
confidence/
  000000.png
distortion/
  000000.bin
```

## 電腦端預定用途

1. 由 `odometry.csv` 建立實際走過的中心線。
2. 以 station 的彩色影像、深度與相機參數投影固定環境點。
3. 沿中心線生成地面、建築側、道路側與頂部遮蔽等結構面。
4. 將結果綁定 GIS 路段，或將自由路線另存成新的候選動線。
5. 網站點選路段時，從行人視高顯示非沉浸式、可旋轉但以兩端透視為主的點線面空間。
