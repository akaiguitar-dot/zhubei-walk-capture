//
//  SessionList.swift
//  Stray Scanner
//
//  Created by Kenneth Blomqvist on 11/15/20.
//  Copyright © 2020 Stray Robots. All rights reserved.
//

import SwiftUI
import CoreData
import CoreLocation

enum WalkCaptureMode: String, Codable, Equatable {
    case mappedSegment = "mapped_segment"
    case freeRoute = "free_route"
}

enum WalkCaptureProfile: String, Codable, Equatable {
    case quickRoute = "quick_route"
    case sixFace = "six_face"

    var title: String {
        switch self {
        case .quickRoute:
            return "快速動線"
        case .sixFace:
            return "六面調查"
        }
    }
}

/// Photo-first capture is deliberately sparse.  The web/GIS pipeline uses the
/// sidewalk feature as geometry authority; AR distance here only spaces
/// evidence photographs and must never be presented as a survey measurement.
struct WalkCapturePolicy: Codable, Equatable {
    let policyID: String
    let nominalSpacingMeters: Double
    let minimumEndpointSeparationMeters: Double
    let requireBidirectionalPass: Bool

    static let photoFirstV1 = WalkCapturePolicy(
        policyID: "photo-first-fixed-4m-v1",
        nominalSpacingMeters: 4.0,
        minimumEndpointSeparationMeters: 0.75,
        requireBidirectionalPass: true
    )
}

/// The human-facing capture flow.  Raw WalkScan v4 media remains immutable;
/// this state only governs what the operator may do next.
enum CaptureMissionState: String, Codable, CaseIterable, Equatable {
    case mapSelection = "map_selection"
    case startAnchor = "start_anchor"
    case outbound = "outbound_capture"
    case arrivedPendingEndConfirmation = "arrived_pending_end_confirmation"
    case returnReady = "return_ready"
    case returnCapture = "return_capture"
    case fieldQC = "field_qc"
    case uploading
    case processing
    case recaptureTasks = "recapture_tasks"

    enum Event {
        case selectFeature, confirmStartAnchor, arriveAtEnd
        case confirmEndAnchor, startReturn, finishReturn
        case passFieldQC, uploadAccepted, processingNeedsRecapture
        case beginRecapture, cancelRecapture
    }

    enum TransitionError: Error, Equatable {
        case illegal(from: CaptureMissionState, event: String)
    }

    mutating func apply(_ event: Event) throws {
        let next: CaptureMissionState?
        switch (self, event) {
        case (.mapSelection, .selectFeature): next = .startAnchor
        case (.startAnchor, .confirmStartAnchor): next = .outbound
        case (.outbound, .arriveAtEnd): next = .arrivedPendingEndConfirmation
        case (.arrivedPendingEndConfirmation, .confirmEndAnchor): next = .returnReady
        case (.returnReady, .startReturn): next = .returnCapture
        case (.returnCapture, .finishReturn): next = .fieldQC
        case (.fieldQC, .passFieldQC): next = .uploading
        case (.uploading, .uploadAccepted): next = .processing
        case (.processing, .processingNeedsRecapture): next = .recaptureTasks
        case (.recaptureTasks, .beginRecapture): next = .startAnchor
        case (.recaptureTasks, .cancelRecapture): next = .processing
        default: next = nil
        }
        guard let next else {
            throw TransitionError.illegal(from: self, event: String(describing: event))
        }
        self = next
    }
}

struct CaptureImageStatistics: Codable, Equatable {
    var centralLaplacianVariance: Double
    var meanLuminance: Double
    var darkPixelFraction: Double
    var clippedHighlightFraction: Double
    var centralEdgeDensity: Double
    var fullFrameEdgeDensity: Double
    var luminanceStandardDeviation: Double
}

enum CaptureQualityIssue: Equatable {
    case blurred, tooDark, overexposed, lensOccluded, poseJump, relocalizing
    case missingAnchor, incompleteLeg, missingRequiredReference

    var blocksCompletion: Bool {
        switch self {
        case .missingAnchor, .incompleteLeg, .missingRequiredReference: return true
        default: return false
        }
    }

    var code: String {
        switch self {
        case .blurred: return "blurred"
        case .tooDark: return "too_dark"
        case .overexposed: return "overexposed"
        case .lensOccluded: return "lens_occluded"
        case .poseJump: return "pose_jump"
        case .relocalizing: return "relocalizing"
        case .missingAnchor: return "missing_anchor"
        case .incompleteLeg: return "incomplete_leg"
        case .missingRequiredReference: return "missing_required_reference"
        }
    }
}

/// Warnings invite an immediate retake; only missing anchors/legs/references
/// block local completion.  Advanced matching is deliberately a website job.
enum CaptureQualityGate {
    static func imageIssues(_ value: CaptureImageStatistics) -> [CaptureQualityIssue] {
        let thresholds = CaptureLumaAnalyzer.configuration
        var issues: [CaptureQualityIssue] = []
        if value.centralLaplacianVariance < thresholds.blurLaplacianVarianceThreshold { issues.append(.blurred) }
        if value.meanLuminance < thresholds.minimumMeanLuminance
            || value.darkPixelFraction > thresholds.maximumDarkPixelFraction { issues.append(.tooDark) }
        if value.clippedHighlightFraction > thresholds.maximumClippedHighlightFraction { issues.append(.overexposed) }
        if value.centralEdgeDensity < thresholds.minimumCentralEdgeDensity
            && value.luminanceStandardDeviation < thresholds.maximumOccludedCentralLumaStandardDeviation
            && value.fullFrameEdgeDensity > value.centralEdgeDensity {
            issues.append(.lensOccluded)
        }
        return issues
    }

    static func completionIssues(
        hasStartAnchor: Bool,
        hasEndAnchor: Bool,
        hasOutboundLeg: Bool,
        hasReturnLeg: Bool,
        hasRequiredReferences: Bool
    ) -> [CaptureQualityIssue] {
        var issues: [CaptureQualityIssue] = []
        if !hasStartAnchor || !hasEndAnchor { issues.append(.missingAnchor) }
        if !hasOutboundLeg || !hasReturnLeg { issues.append(.incompleteLeg) }
        if !hasRequiredReferences { issues.append(.missingRequiredReference) }
        return issues
    }
}

/// Final R1 pack fields intentionally remain opaque until Website/GIS provides
/// its canonical payload and fixtures.  The app verifies supplied bytes only.
protocol CapturePackProvider {
    func activePackData() throws -> Data?
    func fixtureData(named name: String) throws -> Data?
}

struct PendingCapturePackProvider: CapturePackProvider {
    func activePackData() throws -> Data? { nil }
    func fixtureData(named name: String) throws -> Data? { nil }
}

enum WalkBuildingSide: String, Codable, Equatable {
    case left
    case right

    var title: String {
        self == .left ? "左側" : "右側"
    }
}

struct WalkMission: Codable, Equatable {
    struct MapBinding: Codable, Equatable {
        let datasetID: String
        let datasetRevisionID: String
        let featureID: String
        let subsegmentID: String
        let geometryRevisionID: String
        let geometryHash: String
        let axisStartNodeID: String
        let axisEndNodeID: String
        let axisLengthMm: Int
        let vertexChainageMm: [Int]
        let selectedSegmentIndex: Int
        let selectedSegmentFraction: Double
        let selectedChainageMeters: Double
        let selectedNormalizedMeasure: Double
        let originalLatitude: Double
        let originalLongitude: Double
        let horizontalAccuracyMeters: Double
        let captureDirection: String
        let captureStartChainageMeters: Double
        let captureEndChainageMeters: Double
        let snappedLatitude: Double
        let snappedLongitude: Double
        let snapDistanceMeters: Double
        let selectionMethod: String
        let packStatus: String
        let axisCoordinates: [[Double]]
        let polygonRings: [[[Double]]]
    }

    let segmentID: String
    let targetLengthMeters: Double
    let requiresReturnTrip: Bool
    let captureMode: WalkCaptureMode
    let captureProfile: WalkCaptureProfile
    let buildingSide: WalkBuildingSide
    let capturePolicy: WalkCapturePolicy
    let mapBinding: MapBinding?

    init(
        segmentID: String,
        targetLengthMeters: Double,
        requiresReturnTrip: Bool,
        captureMode: WalkCaptureMode = .freeRoute,
        captureProfile: WalkCaptureProfile = .quickRoute,
        buildingSide: WalkBuildingSide = .left,
        capturePolicy: WalkCapturePolicy = .photoFirstV1,
        mapBinding: MapBinding? = nil
    ) {
        self.segmentID = segmentID
        self.targetLengthMeters = targetLengthMeters
        self.requiresReturnTrip = requiresReturnTrip
        self.captureMode = captureMode
        self.captureProfile = captureProfile
        self.buildingSide = buildingSide
        self.capturePolicy = capturePolicy
        self.mapBinding = mapBinding
    }

    var expectedTravelMeters: Double {
        guard captureMode == .mappedSegment else { return 0 }
        return targetLengthMeters * (requiresReturnTrip ? 2.0 : 1.0)
    }
}

class SessionListViewModel: ObservableObject {
    private var dataContext: NSManagedObjectContext?
    @Published var sessions: [Recording] = []

    init() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        dataContext = appDelegate.persistentContainer.viewContext
        self.sessions = []
        NotificationCenter.default.addObserver(self, selector: #selector(sessionsChanged), name: NSNotification.Name("sessionsChanged"), object: nil)
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
    }

    func fetchSessions() {
        let request = NSFetchRequest<NSManagedObject>(entityName: "Recording")
        request.sortDescriptors = [NSSortDescriptor(key: "createdAt", ascending: false)]
        do {
            let fetched: [NSManagedObject] = try dataContext?.fetch(request) ?? []
            sessions = fetched.map { session in
                return session as! Recording
            }

        } catch let error as NSError {
            print("Something went wrong. Error: \(error), \(error.userInfo)")
        }
    }

    @objc func sessionsChanged() {
        fetchSessions()
    }

}

struct SessionList: View {
    @ObservedObject var viewModel = SessionListViewModel()
    @State private var segmentID = "ZB-WALK-0001"
    @State private var captureMode: WalkCaptureMode = .freeRoute
    @State private var captureProfile: WalkCaptureProfile = .quickRoute
    @State private var buildingSide: WalkBuildingSide = .left
    @State private var pairingCode = ""
    @State private var cloudNotice: String?
    @State private var pendingPrivateTransfers = 0
    @State private var localCommunityDrafts = 0
    @State private var activeMission: WalkMission?
    @State private var showingRecorder = false
    @State private var validationMessage: String?
    @State private var captureState: CaptureMissionState = .mapSelection
    @State private var showingHistory = false

    private var mission: WalkMission? {
        let trimmedID = segmentID.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        guard !trimmedID.isEmpty else { return nil }
        return WalkMission(
            segmentID: trimmedID,
            targetLengthMeters: 0,
            requiresReturnTrip: true,
            captureMode: .freeRoute,
            captureProfile: captureProfile,
            buildingSide: buildingSide
        )
    }

    var body: some View {
        CaptureMissionMapHome(
            pendingPrivateTransfers: pendingPrivateTransfers,
            recentCount: viewModel.sessions.count,
            onStartMission: { selectedMission in
                activeMission = selectedMission
                showingRecorder = true
            },
            onOpenHistory: { showingHistory = true }
        )
        .onAppear(perform: refreshSessions)
        .sheet(isPresented: $showingHistory) {
            SessionHistorySheet(sessions: viewModel.sessions)
        }
        .fullScreenCover(isPresented: $showingRecorder, onDismiss: {
            activeMission = nil
            captureState = .mapSelection
            refreshSessions()
        }) {
            if let activeMission {
                NewSessionView(mission: activeMission)
            }
        }
        .onReceive(
            NotificationCenter.default.publisher(
                for: PrivateWalkScanTransferQueue.statusChanged
            )
        ) { _ in
            pendingPrivateTransfers = PrivateWalkScanTransferQueue.shared.pendingCount()
        }
    }

    /// Kept temporarily as a diagnostic fallback while the R1 GIS pack is
    /// delivered.  It is intentionally not reachable from the normal UI.
    private var legacyBody: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("竹北人行道採集")
                            .font(.largeTitle.bold())
                        Text("站在起點鎖定方向，向前走、自然轉身後按一次按鈕，再沿原路走回。")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }

                    NavigationLink(destination: QuickCommunityReportView()) {
                        HStack(spacing: 14) {
                            Image(systemName: "camera.viewfinder")
                                .font(.title2)
                                .foregroundColor(.orange)
                            VStack(alignment: .leading, spacing: 3) {
                                Text("快速記錄人行空間問題")
                                    .font(.headline)
                                Text(
                                    localCommunityDrafts == 0
                                        ? "原圖留在手機，確認遮蔽後才建立可上傳草稿"
                                        : "手機內有 \(localCommunityDrafts) 份未公開草稿"
                                )
                                    .font(.footnote)
                                    .foregroundColor(.secondary)
                            }
                            Spacer()
                            Image(systemName: "chevron.right")
                                .foregroundColor(.secondary)
                        }
                        .padding(16)
                        .background(Color(.secondarySystemBackground))
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                    }
                    .buttonStyle(.plain)

                    VStack(alignment: .leading, spacing: 14) {
                        Text("這次要怎麼採集？")
                            .font(.headline)

                        Picker("資料深度", selection: $captureProfile) {
                            Text("一般往返").tag(WalkCaptureProfile.quickRoute)
                            Text("重點六面").tag(WalkCaptureProfile.sixFace)
                        }
                        .pickerStyle(.segmented)

                        if captureProfile == .sixFace {
                            Picker("面向行進方向時，建築位於", selection: $buildingSide) {
                                Text("建築在左").tag(WalkBuildingSide.left)
                                Text("建築在右").tag(WalkBuildingSide.right)
                            }
                            .pickerStyle(.segmented)

                            Text("約每 4 公尺保存前方照片；問題點可補拍地面、建築側或道路側。")
                                .font(.footnote)
                                .foregroundColor(.secondary)
                        }

                        TextField("路段編號，例如 ZB-WALK-00428", text: $segmentID)
                            .textInputAutocapitalization(.characters)
                            .autocorrectionDisabled()
                            .padding(14)
                            .background(Color(.secondarySystemBackground))
                            .clipShape(RoundedRectangle(cornerRadius: 14))

                        Text("不用填長度。去程與回程約每 4 公尺自動拍照；終點確認後再開始回程。")
                            .font(.footnote)
                            .foregroundColor(.secondary)
                            .padding(14)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(Color(.secondarySystemBackground))
                            .clipShape(RoundedRectangle(cornerRadius: 14))

                        if let mission {
                            Label("自由動線｜去程後手動標記回程", systemImage: "point.topleft.down.to.point.bottomright.curvepath")
                                .font(.footnote)
                                .foregroundColor(.secondary)
                            Label(
                                mission.captureProfile == .sixFace
                                    ? "六面調查｜建築在\(mission.buildingSide.title)"
                                    : "快速動線｜約每 4 公尺一張",
                                systemImage: mission.captureProfile == .sixFace
                                    ? "cube.transparent"
                                    : "figure.walk.motion"
                            )
                            .font(.footnote)
                            .foregroundColor(.secondary)
                        }

                        Button(action: beginMission) {
                            Label("開始採集", systemImage: "viewfinder")
                                .font(.title3.bold())
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 16)
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(.green)
                        .clipShape(RoundedRectangle(cornerRadius: 16))

                        NavigationLink(
                            destination: Group {
                                if let activeMission {
                                    NewSessionView(mission: activeMission)
                                }
                            },
                            isActive: $showingRecorder
                        ) {
                            EmptyView()
                        }
                    }

                    VStack(alignment: .leading, spacing: 10) {
                        Text("私人雲端自動上傳")
                            .font(.headline)
                        if WalkScanSecretStore.receiverToken.isEmpty {
                            SecureField(
                                "第一次啟用：輸入 8 位配對碼",
                                text: $pairingCode
                            )
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                                .keyboardType(.numberPad)
                                .padding(14)
                                .background(Color(.secondarySystemBackground))
                                .clipShape(RoundedRectangle(cornerRadius: 14))

                            Button("啟用這台 iPhone") {
                                cloudNotice = "正在安全配對…"
                                PrivateWalkScanTransferQueue.shared.registerDevice(
                                    pairingCode: pairingCode
                                ) { result in
                                    switch result {
                                    case .success:
                                        pairingCode = ""
                                        cloudNotice = "雲端已啟用；之後拍完會自動上傳。"
                                    case .failure(let error):
                                        cloudNotice = error.localizedDescription
                                    }
                                }
                            }
                            .buttonStyle(.borderedProminent)
                            .disabled(pairingCode.count != 8)
                        } else {
                            Label(
                                "雲端已啟用｜等待 \(pendingPrivateTransfers) 份",
                                systemImage: "checkmark.icloud.fill"
                            )
                            .foregroundColor(.green)

                            Button("上傳最近一筆／重試") {
                                if let latest = viewModel.sessions.first {
                                    PrivateWalkScanTransferQueue.shared.enqueue(
                                        recording: latest
                                    )
                                } else {
                                    PrivateWalkScanTransferQueue.shared.resumePending()
                                }
                                pendingPrivateTransfers =
                                    PrivateWalkScanTransferQueue.shared.pendingCount()
                            }
                            .buttonStyle(.bordered)
                        }

                        if let cloudNotice {
                            Text(cloudNotice)
                                .font(.footnote)
                                .foregroundColor(
                                    cloudNotice.contains("已啟用") ? .green : .secondary
                                )
                        }
                        Text("外出可用 5G；失敗會留在手機並自動續傳。")
                            .font(.footnote)
                            .foregroundColor(.secondary)
                    }

                    if !viewModel.sessions.isEmpty {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("最近完成")
                                .font(.headline)

                            ForEach(viewModel.sessions, id: \.objectID) { recording in
                                NavigationLink(destination: SessionDetailView(recording: recording)) {
                                    HStack {
                                        Image(systemName: "checkmark.circle.fill")
                                            .foregroundColor(.green)
                                        VStack(alignment: .leading, spacing: 3) {
                                            Text(recording.name ?? "未命名路段")
                                                .font(.body.bold())
                                            Text(recording.createdAt ?? Date(), style: .date)
                                                .font(.caption)
                                                .foregroundColor(.secondary)
                                        }
                                        Spacer()
                                        Image(systemName: "chevron.right")
                                            .foregroundColor(.secondary)
                                    }
                                    .padding(14)
                                    .background(Color(.secondarySystemBackground))
                                    .clipShape(RoundedRectangle(cornerRadius: 14))
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                }
                .padding(20)
            }
            .background(Color(.systemBackground).ignoresSafeArea())
            .navigationBarHidden(true)
            .onAppear(perform: refreshSessions)
            .onReceive(
                NotificationCenter.default.publisher(
                    for: PrivateWalkScanTransferQueue.statusChanged
                )
            ) { _ in
                pendingPrivateTransfers =
                    PrivateWalkScanTransferQueue.shared.pendingCount()
            }
            .alert("還不能開始", isPresented: Binding(
                get: { validationMessage != nil },
                set: { if !$0 { validationMessage = nil } }
            )) {
                Button("知道了", role: .cancel) {}
            } message: {
                Text(validationMessage ?? "")
            }
        }
    }

    private func beginMission() {
        guard let mission else {
            validationMessage = "請先輸入這次自由動線的名稱或編號。"
            return
        }
        activeMission = mission
        showingRecorder = true
    }

    private func refreshSessions() {
        DispatchQueue.main.async {
            viewModel.fetchSessions()
        }
        let delegate = UIApplication.shared.delegate as? AppDelegate
        delegate?.appDaemon?.removeDeletedEntries()
        pendingPrivateTransfers = PrivateWalkScanTransferQueue.shared.pendingCount()
        localCommunityDrafts = CommunityDraftStore.all().count
        PrivateWalkScanTransferQueue.shared.resumePending()
    }
}

/// P0 normal entry: one screen, one next action.  Map selection is disabled
/// until a signed Website/GIS R1 pack is available; no text-field segment ID
/// can create a capture mission from this screen.
struct CaptureMissionHome: View {
    @Binding var state: CaptureMissionState
    let pendingPrivateTransfers: Int
    let recentCount: Int
    let onLocateMe: () -> Void
    let onOpenReport: () -> Void
    let onOpenHistory: () -> Void

    private var title: String {
        switch state {
        case .mapSelection: return "先在地圖上選擇人行道"
        case .startAnchor: return "站在起點，確認你的位置"
        case .outbound: return "沿人行道向前走"
        case .arrivedPendingEndConfirmation: return "已到終點，請確認終點位置"
        case .returnReady: return "確認後，準備走回起點"
        case .returnCapture: return "沿原路走回起點"
        case .fieldQC: return "正在檢查這段是否拍好"
        case .uploading: return "正在安全上傳"
        case .processing: return "已送出，正在建模"
        case .recaptureTasks: return "只有局部需要補拍"
        }
    }

    private var detail: String {
        switch state {
        case .mapSelection: return "圖資下載完成後，點選一段人行道即可開始。"
        case .startAnchor: return "地圖會顯示你的定位、精度範圍與確認點。"
        case .outbound: return "手機保持水平，讓建築側與道路側都留在畫面。"
        case .arrivedPendingEndConfirmation: return "此時會暫停拍攝；確認終點後才可開始回程。"
        case .returnReady: return "請轉身，準備沿同一路段返回。"
        case .returnCapture: return "到起點後，App 會帶你進入現場檢查。"
        case .fieldQC: return "模糊、過暗與遮擋會提示重拍；不會直接丟掉資料。"
        case .uploading: return "原始照片與精確位置只會傳到私人收件區。"
        case .processing: return "後端會整理照片順序與可補拍的位置。"
        case .recaptureTasks: return "只需要依照指定的位置補拍，不會重做整段。"
        }
    }

    private var primaryLabel: String {
        switch state {
        case .mapSelection: return "人行道圖資準備中"
        case .startAnchor: return "確認起點"
        case .outbound: return "我已到終點"
        case .arrivedPendingEndConfirmation: return "在地圖確認終點"
        case .returnReady: return "開始回程"
        case .returnCapture: return "我已回到起點"
        case .fieldQC: return "確認並安全上傳"
        case .uploading: return "安全上傳中"
        case .processing: return "查看處理狀態"
        case .recaptureTasks: return "查看補拍任務"
        }
    }

    private var primaryIcon: String {
        switch state {
        case .mapSelection: return "map"
        case .startAnchor, .arrivedPendingEndConfirmation: return "mappin.and.ellipse"
        case .outbound, .returnCapture: return "figure.walk.motion"
        case .returnReady: return "arrow.uturn.backward.circle"
        case .fieldQC: return "checkmark.shield"
        case .uploading: return "icloud.and.arrow.up"
        case .processing: return "cube.transparent"
        case .recaptureTasks: return "camera.viewfinder"
        }
    }

    private var primaryDisabled: Bool {
        state == .mapSelection || state == .uploading || state == .processing || state == .recaptureTasks
    }

    var body: some View {
        NavigationView {
            VStack(alignment: .leading, spacing: 18) {
                HStack {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("竹北人行道採集")
                            .font(.largeTitle.bold())
                        Text("只要跟著下一步走；技術資料會在背景保存。")
                            .foregroundColor(.secondary)
                    }
                    Spacer()
                }

                ZStack(alignment: .bottomLeading) {
                    RoundedRectangle(cornerRadius: 22)
                        .fill(Color(.secondarySystemBackground))
                        .overlay {
                            VStack(spacing: 10) {
                                Image(systemName: "map.fill")
                                    .font(.system(size: 40))
                                    .foregroundColor(.accentColor)
                                Text("人行道路段地圖")
                                    .font(.headline)
                                Text("等待已核對的圖資")
                                    .font(.footnote)
                                    .foregroundColor(.secondary)
                            }
                        }
                        .frame(height: 270)

                    Button(action: onLocateMe) {
                        Label("定位到我", systemImage: "location.fill")
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                            .background(.ultraThinMaterial)
                            .clipShape(Capsule())
                    }
                    .accessibilityLabel("定位到我")
                    .accessibilityHint("將地圖移到目前位置並顯示定位精度")
                    .padding(16)
                }

                VStack(alignment: .leading, spacing: 8) {
                    Label(title, systemImage: primaryIcon)
                        .font(.title3.bold())
                    Text(detail)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                .padding(16)
                .background(Color(.secondarySystemBackground))
                .clipShape(RoundedRectangle(cornerRadius: 18))

                Button(action: advance) {
                    Label(primaryLabel, systemImage: primaryIcon)
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                }
                .buttonStyle(.borderedProminent)
                .tint(primaryDisabled ? .gray : .green)
                .disabled(primaryDisabled)
                .accessibilityHint(detail)

                Label(uploadStatus, systemImage: uploadIcon)
                    .font(.footnote)
                    .foregroundColor(uploadColor)

                HStack {
                    Button("快速記錄問題", action: onOpenReport)
                    Spacer()
                    Button("最近採集 \(recentCount)", action: onOpenHistory)
                }
                .font(.footnote)
                .foregroundColor(.accentColor)

                Spacer(minLength: 0)
            }
            .padding(20)
            .navigationBarHidden(true)
        }
    }

    private var uploadStatus: String {
        if pendingPrivateTransfers > 0 { return "安全上傳中" }
        if state == .processing { return "已送出，正在建模" }
        if state == .recaptureTasks { return "局部補拍待處理" }
        return "原始資料保留在手機，完成後自動安全上傳"
    }

    private var uploadIcon: String {
        pendingPrivateTransfers > 0 ? "icloud.and.arrow.up.fill" : "lock.icloud.fill"
    }

    private var uploadColor: Color {
        pendingPrivateTransfers > 0 ? .blue : .secondary
    }

    private func advance() {
        let event: CaptureMissionState.Event?
        switch state {
        case .startAnchor: event = .confirmStartAnchor
        case .outbound: event = .arriveAtEnd
        case .arrivedPendingEndConfirmation: event = .confirmEndAnchor
        case .returnReady: event = .startReturn
        case .returnCapture: event = .finishReturn
        case .fieldQC: event = .passFieldQC
        default: event = nil
        }
        guard let event else { return }
        try? state.apply(event)
    }
}

struct SessionList_Previews: PreviewProvider {
    static var previews: some View {
        SessionList()
    }
}

final class QuickReportLocationProvider: NSObject, ObservableObject, CLLocationManagerDelegate {
    @Published var location: CLLocation?
    @Published var statusText = "正在取得位置…"
    private let manager = CLLocationManager()

    override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.requestWhenInUseAuthorization()
        manager.startUpdatingLocation()
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let newest = locations.last, newest.horizontalAccuracy >= 0 else { return }
        location = newest
        statusText = String(format: "私密定位精度 ±%.0f 公尺", newest.horizontalAccuracy)
    }

    func locationManager(
        _ manager: CLLocationManager,
        didFailWithError error: Error
    ) {
        statusText = "尚未取得位置：\(error.localizedDescription)"
    }
}

struct QuickCommunityReportView: View {
    @StateObject private var locationProvider = QuickReportLocationProvider()
    @State private var category: CommunityReportCategory = .blockedSidewalk
    @State private var description = ""
    @State private var image: UIImage?
    @State private var regions: [RedactionRegion] = []
    @State private var selectedRegionID: UUID?
    @State private var isAddingRegion = false
    @State private var isShowingCamera = false
    @State private var isDetecting = false
    @State private var notice: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text("快速通報草稿")
                    .font(.largeTitle.bold())
                Text("這裡只建立尚未公開的本機草稿。原始照片不會進入上傳封包。")
                    .foregroundColor(.secondary)

                Picker("問題類別", selection: $category) {
                    ForEach(CommunityReportCategory.allCases) { item in
                        Text(item.title).tag(item)
                    }
                }
                .pickerStyle(.menu)

                TextEditor(text: $description)
                    .frame(minHeight: 92)
                    .padding(10)
                    .background(Color(.secondarySystemBackground))
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .overlay(alignment: .topLeading) {
                        if description.isEmpty {
                            Text("簡短描述實際行人遇到的問題")
                                .foregroundColor(.secondary)
                                .padding(16)
                                .allowsHitTesting(false)
                        }
                    }

                Label(locationProvider.statusText, systemImage: "location.fill")
                    .font(.footnote)
                    .foregroundColor(
                        locationProvider.location == nil ? .orange : .secondary
                    )

                if let image {
                    RedactionCanvas(
                        image: image,
                        regions: $regions,
                        selectedRegionID: $selectedRegionID,
                        isAddingRegion: $isAddingRegion
                    )
                    .frame(height: 390)
                    .clipShape(RoundedRectangle(cornerRadius: 16))

                    HStack {
                        Button(isAddingRegion ? "點照片加入遮蔽" : "新增人工遮蔽") {
                            isAddingRegion.toggle()
                        }
                        .buttonStyle(.borderedProminent)

                        Button("刪除所選遮蔽", role: .destructive) {
                            guard let selectedRegionID else { return }
                            regions.removeAll { $0.id == selectedRegionID }
                            self.selectedRegionID = nil
                        }
                        .buttonStyle(.bordered)
                        .disabled(selectedRegionID == nil)
                    }

                    Text(
                        "人臉 \(regions.filter { $0.kind == .face }.count)・"
                            + "車牌候選 \(regions.filter { $0.kind == .plateCandidate }.count)・"
                            + "人工 \(regions.filter { $0.kind == .manual }.count)"
                    )
                    .font(.footnote)
                    .foregroundColor(.secondary)
                }

                Button {
                    isShowingCamera = true
                } label: {
                    Label(
                        image == nil ? "拍攝問題照片" : "重新拍攝",
                        systemImage: "camera.fill"
                    )
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                }
                .buttonStyle(.bordered)

                Button(action: saveDraft) {
                    HStack {
                        if isDetecting {
                            ProgressView()
                        }
                        Text(isDetecting ? "正在辨識隱私區域…" : "確認遮蔽並儲存草稿")
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                }
                .buttonStyle(.borderedProminent)
                .tint(.green)
                .disabled(
                    image == nil
                        || locationProvider.location == nil
                        || description.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                        || isDetecting
                )

                if let notice {
                    Text(notice)
                        .font(.footnote)
                        .foregroundColor(notice.contains("完成") ? .green : .orange)
                }
            }
            .padding(20)
        }
        .navigationTitle("快速通報")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $isShowingCamera) {
            CommunityCameraPicker { captured in
                guard let captured else { return }
                image = captured.normalizedUp()
                regions = []
                selectedRegionID = nil
                isDetecting = true
                Task {
                    do {
                        let detected = try await OnDeviceRedaction.detectRegions(
                            in: captured.normalizedUp()
                        )
                        await MainActor.run {
                            regions = detected
                            isDetecting = false
                            notice = detected.isEmpty
                                ? "沒有自動找到人臉或車牌；仍請目視確認並可人工補遮。"
                                : "已標出候選區域，請逐一目視確認。"
                        }
                    } catch {
                        await MainActor.run {
                            isDetecting = false
                            notice = "自動辨識失敗，請使用人工遮蔽。"
                        }
                    }
                }
            }
        }
    }

    private func saveDraft() {
        guard let image,
              let location = locationProvider.location else {
            return
        }
        do {
            let redacted = OnDeviceRedaction.renderRedacted(
                image: image,
                regions: regions
            )
            _ = try CommunityDraftStore.save(
                original: image,
                redacted: redacted,
                category: category,
                description: description.trimmingCharacters(in: .whitespacesAndNewlines),
                location: location,
                regions: regions
            )
            notice = "草稿建立完成；目前仍未公開，也尚未送出。"
        } catch {
            notice = "草稿儲存失敗：\(error.localizedDescription)"
        }
    }
}

struct RedactionCanvas: View {
    let image: UIImage
    @Binding var regions: [RedactionRegion]
    @Binding var selectedRegionID: UUID?
    @Binding var isAddingRegion: Bool
    @State private var dragOrigins: [UUID: NormalizedRect] = [:]

    var body: some View {
        GeometryReader { geometry in
            let frame = aspectFitFrame(
                imageSize: image.size,
                containerSize: geometry.size
            )
            ZStack(alignment: .topLeading) {
                Color.black
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(width: frame.width, height: frame.height)
                    .position(x: frame.midX, y: frame.midY)

                ForEach($regions) { $region in
                    let rect = displayRect(region.rect, inside: frame)
                    RoundedRectangle(cornerRadius: 5)
                        .fill(Color.black.opacity(0.82))
                        .overlay(
                            RoundedRectangle(cornerRadius: 5)
                                .stroke(
                                    selectedRegionID == region.id
                                        ? Color.yellow
                                        : Color.white.opacity(0.8),
                                    lineWidth: selectedRegionID == region.id ? 3 : 1
                                )
                        )
                        .frame(width: rect.width, height: rect.height)
                        .position(x: rect.midX, y: rect.midY)
                        .onTapGesture {
                            selectedRegionID = region.id
                        }
                        .gesture(
                            DragGesture()
                                .onChanged { value in
                                    let origin = dragOrigins[region.id] ?? region.rect
                                    dragOrigins[region.id] = origin
                                    region.rect.x = clamp(
                                        origin.x + Double(value.translation.width / frame.width),
                                        0,
                                        1 - region.rect.width
                                    )
                                    region.rect.y = clamp(
                                        origin.y - Double(value.translation.height / frame.height),
                                        0,
                                        1 - region.rect.height
                                    )
                                }
                                .onEnded { _ in
                                    dragOrigins.removeValue(forKey: region.id)
                                }
                        )
                }
            }
            .contentShape(Rectangle())
            .simultaneousGesture(
                SpatialTapGesture().onEnded { value in
                    guard isAddingRegion, frame.contains(value.location) else { return }
                    let x = Double((value.location.x - frame.minX) / frame.width)
                    let yFromTop = Double((value.location.y - frame.minY) / frame.height)
                    let width = 0.20
                    let height = 0.10
                    let rect = CGRect(
                        x: clamp(x - width / 2, 0, 1 - width),
                        y: clamp((1 - yFromTop) - height / 2, 0, 1 - height),
                        width: width,
                        height: height
                    )
                    let newRegion = RedactionRegion(kind: .manual, rect: rect)
                    regions.append(newRegion)
                    selectedRegionID = newRegion.id
                    isAddingRegion = false
                }
            )
        }
    }

    private func aspectFitFrame(imageSize: CGSize, containerSize: CGSize) -> CGRect {
        guard imageSize.width > 0, imageSize.height > 0 else {
            return CGRect(origin: .zero, size: containerSize)
        }
        let scale = min(
            containerSize.width / imageSize.width,
            containerSize.height / imageSize.height
        )
        let size = CGSize(
            width: imageSize.width * scale,
            height: imageSize.height * scale
        )
        return CGRect(
            x: (containerSize.width - size.width) / 2,
            y: (containerSize.height - size.height) / 2,
            width: size.width,
            height: size.height
        )
    }

    private func displayRect(_ normalized: NormalizedRect, inside frame: CGRect) -> CGRect {
        CGRect(
            x: frame.minX + CGFloat(normalized.x) * frame.width,
            y: frame.minY + CGFloat(1 - normalized.y - normalized.height) * frame.height,
            width: CGFloat(normalized.width) * frame.width,
            height: CGFloat(normalized.height) * frame.height
        )
    }

    private func clamp<T: Comparable>(_ value: T, _ lower: T, _ upper: T) -> T {
        min(max(value, lower), upper)
    }
}

struct CommunityCameraPicker: UIViewControllerRepresentable {
    let completion: (UIImage?) -> Void
    @Environment(\.dismiss) private var dismiss

    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            picker.sourceType = .camera
            picker.cameraCaptureMode = .photo
        } else {
            picker.sourceType = .photoLibrary
        }
        return picker
    }

    func updateUIViewController(
        _ uiViewController: UIImagePickerController,
        context: Context
    ) {}

    final class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let parent: CommunityCameraPicker

        init(parent: CommunityCameraPicker) {
            self.parent = parent
        }

        func imagePickerController(
            _ picker: UIImagePickerController,
            didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]
        ) {
            parent.completion(info[.originalImage] as? UIImage)
            parent.dismiss()
        }

        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            parent.completion(nil)
            parent.dismiss()
        }
    }
}

private extension UIImage {
    func normalizedUp() -> UIImage {
        guard imageOrientation != .up else { return self }
        let format = UIGraphicsImageRendererFormat()
        format.scale = scale
        format.opaque = true
        return UIGraphicsImageRenderer(size: size, format: format).image { _ in
            draw(in: CGRect(origin: .zero, size: size))
        }
    }
}
