import Foundation
import CoreVideo

struct CaptureLumaAnalyzerConfiguration: Codable, Equatable {
    let analyzerVersion: String
    let targetLongEdgeSamples: Int
    let darkLumaThreshold: Double
    let clippedHighlightThreshold: Double
    let edgeMagnitudeThreshold: Double
    let centralRegionFraction: Double
    let blurLaplacianVarianceThreshold: Double
    let minimumMeanLuminance: Double
    let maximumDarkPixelFraction: Double
    let maximumClippedHighlightFraction: Double
    let minimumCentralEdgeDensity: Double
    let maximumOccludedCentralLumaStandardDeviation: Double

    static let fieldQCV1 = CaptureLumaAnalyzerConfiguration(
        analyzerVersion: "walkscan-luma-qc-v1",
        targetLongEdgeSamples: 160,
        darkLumaThreshold: 0.08,
        clippedHighlightThreshold: 0.98,
        edgeMagnitudeThreshold: 0.08,
        centralRegionFraction: 0.50,
        blurLaplacianVarianceThreshold: 18,
        minimumMeanLuminance: 0.08,
        maximumDarkPixelFraction: 0.85,
        maximumClippedHighlightFraction: 0.25,
        minimumCentralEdgeDensity: 0.015,
        maximumOccludedCentralLumaStandardDeviation: 0.04
    )
}

enum CaptureLumaAnalyzer {
    static let configuration = CaptureLumaAnalyzerConfiguration.fieldQCV1

    static func analyze(pixelBuffer: CVPixelBuffer) -> CaptureImageStatistics? {
        guard CVPixelBufferGetPlaneCount(pixelBuffer) > 0 else { return nil }
        CVPixelBufferLockBaseAddress(pixelBuffer, .readOnly)
        defer { CVPixelBufferUnlockBaseAddress(pixelBuffer, .readOnly) }
        guard let base = CVPixelBufferGetBaseAddressOfPlane(pixelBuffer, 0) else { return nil }
        let width = CVPixelBufferGetWidthOfPlane(pixelBuffer, 0)
        let height = CVPixelBufferGetHeightOfPlane(pixelBuffer, 0)
        let rowBytes = CVPixelBufferGetBytesPerRowOfPlane(pixelBuffer, 0)
        return analyzeLuma(
            bytes: base.assumingMemoryBound(to: UInt8.self),
            width: width,
            height: height,
            rowBytes: rowBytes
        )
    }

    static func analyzeLuma(
        bytes: UnsafePointer<UInt8>,
        width: Int,
        height: Int,
        rowBytes: Int,
        forcedStride: Int? = nil
    ) -> CaptureImageStatistics? {
        guard width >= 3, height >= 3, rowBytes >= width else { return nil }
        let stride = max(1, forcedStride ?? Int(ceil(Double(max(width, height)) / Double(configuration.targetLongEdgeSamples))))
        let sampledWidth = max(3, (width + stride - 1) / stride)
        let sampledHeight = max(3, (height + stride - 1) / stride)
        var luma = [Double](repeating: 0, count: sampledWidth * sampledHeight)

        for y in 0..<sampledHeight {
            let sourceY = min(height - 1, y * stride)
            for x in 0..<sampledWidth {
                let sourceX = min(width - 1, x * stride)
                luma[y * sampledWidth + x] = Double(bytes[sourceY * rowBytes + sourceX]) / 255
            }
        }
        return analyzeSampledLuma(luma, width: sampledWidth, height: sampledHeight)
    }

    static func analyzeLumaBytes(
        _ bytes: [UInt8],
        width: Int,
        height: Int,
        rowBytes: Int? = nil,
        forcedStride: Int = 1
    ) -> CaptureImageStatistics? {
        let resolvedRowBytes = rowBytes ?? width
        guard bytes.count >= resolvedRowBytes * height else { return nil }
        return bytes.withUnsafeBufferPointer { buffer in
            guard let base = buffer.baseAddress else { return nil }
            return analyzeLuma(
                bytes: base,
                width: width,
                height: height,
                rowBytes: resolvedRowBytes,
                forcedStride: forcedStride
            )
        }
    }

    private static func analyzeSampledLuma(
        _ luma: [Double],
        width: Int,
        height: Int
    ) -> CaptureImageStatistics {
        let count = Double(luma.count)
        let mean = luma.reduce(0, +) / count
        let darkFraction = Double(luma.filter { $0 <= configuration.darkLumaThreshold }.count) / count
        let clippedFraction = Double(luma.filter { $0 >= configuration.clippedHighlightThreshold }.count) / count

        let centralWidth = max(3, Int(Double(width) * configuration.centralRegionFraction))
        let centralHeight = max(3, Int(Double(height) * configuration.centralRegionFraction))
        let minX = max(1, (width - centralWidth) / 2)
        let maxX = min(width - 2, minX + centralWidth - 1)
        let minY = max(1, (height - centralHeight) / 2)
        let maxY = min(height - 2, minY + centralHeight - 1)

        var fullEdges = 0
        var fullInterior = 0
        var centralEdges = 0
        var centralInterior = 0
        var centralValues: [Double] = []
        var laplacians: [Double] = []
        centralValues.reserveCapacity((maxX - minX + 1) * (maxY - minY + 1))
        laplacians.reserveCapacity(centralValues.capacity)

        for y in 1..<(height - 1) {
            for x in 1..<(width - 1) {
                let index = y * width + x
                let gx = abs(
                    (luma[index - width + 1] + 2 * luma[index + 1] + luma[index + width + 1])
                        - (luma[index - width - 1] + 2 * luma[index - 1] + luma[index + width - 1])
                )
                let gy = abs(
                    (luma[index + width - 1] + 2 * luma[index + width] + luma[index + width + 1])
                        - (luma[index - width - 1] + 2 * luma[index - width] + luma[index - width + 1])
                )
                let isEdge = (gx + gy) / 8 >= configuration.edgeMagnitudeThreshold
                fullInterior += 1
                if isEdge { fullEdges += 1 }

                if x >= minX, x <= maxX, y >= minY, y <= maxY {
                    centralInterior += 1
                    if isEdge { centralEdges += 1 }
                    centralValues.append(luma[index])
                    let laplacian = (4 * luma[index]
                        - luma[index - 1] - luma[index + 1]
                        - luma[index - width] - luma[index + width]) * 255
                    laplacians.append(laplacian)
                }
            }
        }

        return CaptureImageStatistics(
            centralLaplacianVariance: variance(laplacians),
            meanLuminance: mean,
            darkPixelFraction: darkFraction,
            clippedHighlightFraction: clippedFraction,
            centralEdgeDensity: centralInterior > 0 ? Double(centralEdges) / Double(centralInterior) : 0,
            fullFrameEdgeDensity: fullInterior > 0 ? Double(fullEdges) / Double(fullInterior) : 0,
            luminanceStandardDeviation: sqrt(variance(centralValues))
        )
    }

    private static func variance(_ values: [Double]) -> Double {
        guard !values.isEmpty else { return 0 }
        let mean = values.reduce(0, +) / Double(values.count)
        return values.reduce(0) { $0 + ($1 - mean) * ($1 - mean) } / Double(values.count)
    }
}
