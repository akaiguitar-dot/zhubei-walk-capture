# 竹北步行採集 App

這是給 iPhone 15 Pro 單人先導測試使用的原生 LiDAR 採集 App。手機只負責可靠地同步保存資料，3D 重建與網站展示由 Windows 電腦負責。

## 手機畫面

1. 選擇「GIS 路段」或「自由動線」。
2. GIS 路段輸入路段編號、長度與是否原路返回；自由動線只需命名，不限長度與形狀。
3. 點「開始採集」，再點紅色圓鍵。
4. 手機維持目視高度，依畫面圓圈調整水平與左右傾斜。
5. 定位與方向合格時，App 每 1 公尺自動拍攝、編號、震動並閃白提示。
6. GIS 往返模式在端點會震動並顯示「請轉身」；自由動線可沿任意轉彎持續行走。
7. 顯示完成或走完自由動線時，再點一次紅鍵歸檔。
8. 在「最近完成」點選該路段，再點「匯出到電腦」。

## 每次採集保存的內容

- `mission.json`：路段編號、目標長度、實際行走距離與採集時間
- `stations.json`：每 1 公尺節點的編號、方向、影像索引、相機位置與姿態
- `stations/*.jpg`：每 1 公尺自動保存的彩色照片
- `rgb.mp4`：彩色影像
- `depth/*.png`：LiDAR 公制深度圖
- `confidence/*.png`：深度可信度
- `odometry.csv`：每幀相機位置、方向與相機參數
- `imu.csv`：加速度與旋轉
- `locations.csv`：GPS 軌跡與誤差
- `camera_matrix.csv`：相機內部參數

匯出檔副檔名為 `.walkscan`，內容是可由 Windows 解開的 ZIP 封裝。

## 電腦先檢查資料

在專案根目錄執行：

```powershell
python scripts/validate_walkscan.py "你的檔案.walkscan"
```

程式會檢查節點是否連續、照片／深度圖是否齊全、每個節點能否對到相機軌跡，並以中文列出問題。

資料通過後，可先建立沿實際走路軌跡彎曲的點線面骨架：

```powershell
python scripts/build_walkscan_route.py "你的檔案.walkscan" -o "corridor-skeleton.json"
```

這個骨架的中心線來自手機實際軌跡；左右寬度與上方高度在 LiDAR 邊界分析完成前只是顯示導引值，不會冒充實際人行道量測。

## 零費用、無 Mac 的安裝方式

專案內的 `.github/workflows/build-ios-capture.yml` 可使用 GitHub 的 macOS runner 產出未簽署 IPA。Windows 上仍需用個人的免費 Apple 帳號替 IPA 簽署並側載到自己的 iPhone。免費簽章有短效期，因此這是個人實測方案，不是大量民眾正式發布方案。

這條路適合目前「一支手機、先驗證效果」的階段。若未來要讓大量民眾安裝，必須再改用 App Store/TestFlight 或其他正式發佈方式。

目前這台 Windows 電腦無法直接執行 Xcode，因此本機能完成資料契約與 Windows 驗證測試；iOS 編譯是否通過，必須由上述 macOS runner 實際執行後才算確認。

詳細資料格式見 `docs/walkscan-v2.md`。

## 開源來源

LiDAR RGB-D 採集核心衍生自 Stray Scanner，依 MIT License 使用與修改。原始專案：

https://github.com/strayrobots/scanner
