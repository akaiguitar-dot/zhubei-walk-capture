//
//  ShareUtility.swift
//  StrayScanner
//
//  Created by Claude on 6/24/25.
//

import Foundation
import CryptoKit
import UIKit
import Vision
import CoreLocation
import Security

enum WalkScanSecretStore {
    private static let service =
        Bundle.main.bundleIdentifier ?? "tw.zhubei.walkcapture"
    private static let receiverAccount = "walkscan.private.receiver.token"

    static var receiverToken: String {
        get {
            let query: [String: Any] = [
                kSecClass as String: kSecClassGenericPassword,
                kSecAttrService as String: service,
                kSecAttrAccount as String: receiverAccount,
                kSecReturnData as String: true,
                kSecMatchLimit as String: kSecMatchLimitOne
            ]
            var item: CFTypeRef?
            guard SecItemCopyMatching(
                query as CFDictionary,
                &item
            ) == errSecSuccess,
                  let data = item as? Data,
                  let value = String(data: data, encoding: .utf8) else {
                return ""
            }
            return value
        }
        set {
            let base: [String: Any] = [
                kSecClass as String: kSecClassGenericPassword,
                kSecAttrService as String: service,
                kSecAttrAccount as String: receiverAccount
            ]
            SecItemDelete(base as CFDictionary)
            let trimmed = newValue.trimmingCharacters(
                in: .whitespacesAndNewlines
            )
            guard !trimmed.isEmpty,
                  let data = trimmed.data(using: .utf8) else {
                return
            }
            var item = base
            item[kSecValueData as String] = data
            item[kSecAttrAccessible as String] =
                kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
            SecItemAdd(item as CFDictionary, nil)
        }
    }
}

/// Utility class for creating shareable archives from recording datasets
class ShareUtility {
    
    /// Creates a shareable ZIP archive from a recording's dataset
    /// - Parameter recording: The recording to create a ZIP archive for
    /// - Returns: URL of the created ZIP file
    static func createShareableArchive(for recording: Recording) async throws -> URL {
        guard let sourceDirectory = recording.directoryPath() else {
            throw NSError(domain: "ShareError", code: 1, userInfo: [NSLocalizedDescriptionKey: "Unable to get recording directory path"])
        }
        
        let exportDirectory = try shareExportDirectory()
        let rawName = recording.name ?? sourceDirectory.lastPathComponent
        let safeName = rawName.replacingOccurrences(
            of: "[^A-Za-z0-9_-]",
            with: "-",
            options: .regularExpression
        )
        let archiveURL = exportDirectory.appendingPathComponent(safeName + ".walkscan")
        
        // Remove existing archive if it exists
        try? FileManager.default.removeItem(at: archiveURL)
        
        return try await withCheckedThrowingContinuation { continuation in
            DispatchQueue.global(qos: .userInitiated).async {
                do {
                    try createZipArchive(sourceDirectory: sourceDirectory, destinationURL: archiveURL)
                    let values = try archiveURL.resourceValues(forKeys: [
                        .isRegularFileKey,
                        .fileSizeKey
                    ])
                    guard values.isRegularFile == true,
                          (values.fileSize ?? 0) > 0 else {
                        throw NSError(
                            domain: "ShareError",
                            code: 3,
                            userInfo: [
                                NSLocalizedDescriptionKey:
                                    "WalkScan package was not created correctly."
                            ]
                        )
                    }
                    continuation.resume(returning: archiveURL)
                } catch {
                    continuation.resume(throwing: error)
                }
            }
        }
    }

    static func shareExportDirectory() throws -> URL {
        let documents = FileManager.default.urls(
            for: .documentDirectory,
            in: .userDomainMask
        ).first!
        let directory = documents.appendingPathComponent(
            "WalkScan Exports",
            isDirectory: true
        )
        try FileManager.default.createDirectory(
            at: directory,
            withIntermediateDirectories: true
        )
        return directory
    }

    static func createPersistentPrivateArchive(for recording: Recording) async throws -> URL {
        guard let sourceDirectory = recording.directoryPath() else {
            throw NSError(
                domain: "ShareError",
                code: 2,
                userInfo: [NSLocalizedDescriptionKey: "找不到採集資料"]
            )
        }
        return try await createPersistentPrivateArchive(
            sourceDirectory: sourceDirectory,
            identifier: recording.id?.uuidString ?? UUID().uuidString
        )
    }

    static func createPersistentPrivateArchive(
        sourceDirectory: URL,
        identifier: String
    ) async throws -> URL {
        let queueDirectory = try privateTransferDirectory()
        let destination = queueDirectory
            .appendingPathComponent(identifier)
            .appendingPathExtension("walkscan")
        // A completed capture is immutable.  Recreating this archive could
        // replace a file while URLSession is uploading it after a restart.
        if FileManager.default.fileExists(atPath: destination.path) {
            return destination
        }
        let partialDestination = queueDirectory
            .appendingPathComponent("\(identifier).\(UUID().uuidString)")
            .appendingPathExtension("partial")
        return try await withCheckedThrowingContinuation { continuation in
            DispatchQueue.global(qos: .utility).async {
                do {
                    try createZipArchive(
                        sourceDirectory: sourceDirectory,
                        destinationURL: partialDestination
                    )
                    guard let attributes = try? FileManager.default.attributesOfItem(
                        atPath: partialDestination.path
                    ),
                    (attributes[.size] as? NSNumber)?.intValue ?? 0 > 0 else {
                        throw NSError(
                            domain: "WalkScanTransfer",
                            code: 1,
                            userInfo: [NSLocalizedDescriptionKey: "採集檔案建立不完整"]
                        )
                    }
                    try FileManager.default.moveItem(
                        at: partialDestination,
                        to: destination
                    )
                    continuation.resume(returning: destination)
                } catch {
                    try? FileManager.default.removeItem(at: partialDestination)
                    continuation.resume(throwing: error)
                }
            }
        }
    }

    static func privateTransferDirectory() throws -> URL {
        let base = FileManager.default.urls(
            for: .applicationSupportDirectory,
            in: .userDomainMask
        ).first!
        let directory = base.appendingPathComponent("PrivateTransferQueue", isDirectory: true)
        try FileManager.default.createDirectory(
            at: directory,
            withIntermediateDirectories: true
        )
        return directory
    }
    
    private static func createZipArchive(sourceDirectory: URL, destinationURL: URL) throws {
        let coordinator = NSFileCoordinator()
        var coordinatorError: NSError?
        var copyError: Error?

        coordinator.coordinate(readingItemAt: sourceDirectory, options: [.forUploading], error: &coordinatorError) { zipURL in
            do {
                try FileManager.default.copyItem(at: zipURL, to: destinationURL)
            } catch {
                copyError = error
            }
        }

        if let error = coordinatorError ?? copyError {
            throw error
        }
    }
}

/// Transfers raw WalkScan packages only to a receiver controlled by the user
/// on a private network. Community uploads use a separate redacted-media path.
final class PrivateWalkScanTransferQueue: NSObject, URLSessionTaskDelegate {
    static let shared = PrivateWalkScanTransferQueue()
    static let statusChanged = Notification.Name("privateWalkScanTransferStatusChanged")
    static let cloudBaseURL = URL(
        string: "https://zhubei-walkscan-ingest.akaiguitar.workers.dev"
    )!

    private lazy var session: URLSession = {
        let configuration = URLSessionConfiguration.background(
            withIdentifier: "tw.zhubei.walkcapture.private-transfer"
        )
        configuration.sessionSendsLaunchEvents = true
        configuration.isDiscretionary = false
        configuration.waitsForConnectivity = true
        configuration.allowsCellularAccess = true
        return URLSession(
            configuration: configuration,
            delegate: self,
            delegateQueue: nil
        )
    }()

    private override init() {
        super.init()
    }

    func registerDevice(
        pairingCode: String,
        completion: @escaping (Result<Void, Error>) -> Void
    ) {
        var request = URLRequest(
            url: Self.cloudBaseURL.appendingPathComponent("api/devices/register")
        )
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try? JSONSerialization.data(withJSONObject: [
            "pairingCode": pairingCode.trimmingCharacters(in: .whitespacesAndNewlines)
        ])
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error {
                DispatchQueue.main.async { completion(.failure(error)) }
                return
            }
            let status = (response as? HTTPURLResponse)?.statusCode ?? 0
            guard (200...299).contains(status),
                  let data,
                  let payload = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let token = payload["deviceToken"] as? String,
                  !token.isEmpty else {
                let failure = NSError(
                    domain: "WalkScanCloud",
                    code: status,
                    userInfo: [NSLocalizedDescriptionKey: "配對碼無效、已使用或雲端暫時無法連線。"]
                )
                DispatchQueue.main.async { completion(.failure(failure)) }
                return
            }
            WalkScanSecretStore.receiverToken = token
            DispatchQueue.main.async {
                self.postStatus()
                completion(.success(()))
                self.resumePending()
            }
        }.resume()
    }

    func enqueue(recording: Recording) {
        guard let sourceDirectory = recording.directoryPath() else { return }
        let identifier = recording.id?.uuidString ?? UUID().uuidString
        Task {
            do {
                _ = try await ShareUtility.createPersistentPrivateArchive(
                    sourceDirectory: sourceDirectory,
                    identifier: identifier
                )
                postStatus()
                resumePending()
            } catch {
                postStatus()
            }
        }
    }

    func resumePending() {
        guard let receiverURL = validatedPrivateReceiverURL(),
              let files = try? FileManager.default.contentsOfDirectory(
                at: try ShareUtility.privateTransferDirectory(),
                includingPropertiesForKeys: nil,
                options: [.skipsHiddenFiles]
              ) else {
            return
        }
        session.getAllTasks { tasks in
            let activePaths = Set(tasks.compactMap(\.taskDescription))
            for file in files where file.pathExtension.lowercased() == "walkscan" {
                guard !activePaths.contains(file.path) else { continue }
                var request = URLRequest(
                    url: receiverURL.appendingPathComponent("api/walkscans")
                )
                request.httpMethod = "POST"
                request.setValue(
                    file.lastPathComponent.addingPercentEncoding(
                        withAllowedCharacters: .urlPathAllowed
                    ),
                    forHTTPHeaderField: "X-Walkscan-Filename"
                )
                request.setValue(
                    self.sha256(file),
                    forHTTPHeaderField: "X-Walkscan-Sha256"
                )
                request.setValue(
                    "raw-private",
                    forHTTPHeaderField: "X-Walkscan-Privacy-Class"
                )
                let token = WalkScanSecretStore.receiverToken
                if !token.isEmpty {
                    request.setValue(
                        "Bearer \(token)",
                        forHTTPHeaderField: "Authorization"
                    )
                }
                let task = self.session.uploadTask(with: request, fromFile: file)
                task.taskDescription = file.path
                task.resume()
            }
            self.postStatus()
        }
    }

    func pendingCount() -> Int {
        guard let directory = try? ShareUtility.privateTransferDirectory(),
              let files = try? FileManager.default.contentsOfDirectory(
                at: directory,
                includingPropertiesForKeys: nil,
                options: [.skipsHiddenFiles]
              ) else {
            return 0
        }
        return files.filter { $0.pathExtension.lowercased() == "walkscan" }.count
    }

    func validatedPrivateReceiverURL() -> URL? {
        if !WalkScanSecretStore.receiverToken.isEmpty {
            return Self.cloudBaseURL
        }
        let raw = UserDefaults.standard.string(forKey: "walkscan.receiverURL")?
            .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        guard let url = URL(string: raw),
              let host = url.host?.lowercased(),
              ["http", "https"].contains(url.scheme?.lowercased() ?? "") else {
            return nil
        }
        let scheme = url.scheme?.lowercased()
        if isPrivateHost(host) {
            return url
        }
        let token = WalkScanSecretStore.receiverToken
        guard scheme == "https", !token.isEmpty else { return nil }
        return url
    }

    private func isPrivateHost(_ host: String) -> Bool {
        if host == "localhost" || host.hasSuffix(".local") || host == "::1" {
            return true
        }
        if host.hasPrefix("10.") || host.hasPrefix("192.168.") {
            return true
        }
        if host.hasPrefix("172.") {
            let parts = host.split(separator: ".")
            if parts.count == 4,
               let second = Int(parts[1]),
               (16...31).contains(second) {
                return true
            }
        }
        return false
    }

    private func sha256(_ file: URL) -> String {
        guard let handle = try? FileHandle(forReadingFrom: file) else { return "" }
        defer { try? handle.close() }
        var hasher = SHA256()
        while let data = try? handle.read(upToCount: 1_048_576), !data.isEmpty {
            hasher.update(data: data)
        }
        return hasher.finalize().map { String(format: "%02x", $0) }.joined()
    }

    private func postStatus() {
        DispatchQueue.main.async {
            NotificationCenter.default.post(
                name: Self.statusChanged,
                object: nil
            )
        }
    }

    func urlSession(
        _ session: URLSession,
        task: URLSessionTask,
        didCompleteWithError error: Error?
    ) {
        let statusCode = (task.response as? HTTPURLResponse)?.statusCode ?? 0
        if error == nil,
           (200...299).contains(statusCode),
           let path = task.taskDescription {
            try? FileManager.default.removeItem(atPath: path)
        }
        postStatus()
    }

    func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        DispatchQueue.main.async {
            guard let delegate = UIApplication.shared.delegate as? AppDelegate else { return }
            delegate.backgroundTransferCompletion?()
            delegate.backgroundTransferCompletion = nil
        }
    }
}

enum CommunityReportCategory: String, Codable, CaseIterable, Identifiable {
    case blockedSidewalk = "blocked_sidewalk"
    case cornerObstruction = "corner_obstruction"
    case constructionDetour = "construction_detour"
    case accessibilityBlocked = "accessibility_blocked"
    case sidewalkGap = "sidewalk_gap"
    case unsafeCrossing = "unsafe_crossing"
    case other

    var id: String { rawValue }

    var title: String {
        switch self {
        case .blockedSidewalk:
            return "人行空間遭阻擋"
        case .cornerObstruction:
            return "轉角視線或動線受阻"
        case .constructionDetour:
            return "施工繞行"
        case .accessibilityBlocked:
            return "無障礙動線受阻"
        case .sidewalkGap:
            return "人行道中斷"
        case .unsafeCrossing:
            return "穿越不安全"
        case .other:
            return "其他人行空間問題"
        }
    }
}

enum CommunityDraftStatus: String, Codable {
    case localDraft = "local_draft"
    case redactionRequired = "redaction_required"
    case readyToUpload = "ready_to_upload"
    case uploading
    case uploaded
    case pendingModeration = "pending_moderation"
    case needsChanges = "needs_changes"
    case accepted
    case rejected
}

enum RedactionRegionKind: String, Codable {
    case face
    case plateCandidate = "plate_candidate"
    case manual
}

struct NormalizedRect: Codable, Equatable {
    var x: Double
    var y: Double
    var width: Double
    var height: Double

    var cgRect: CGRect {
        CGRect(x: x, y: y, width: width, height: height)
    }
}

struct RedactionRegion: Codable, Identifiable, Equatable {
    let id: UUID
    var kind: RedactionRegionKind
    var rect: NormalizedRect

    init(kind: RedactionRegionKind, rect: CGRect) {
        id = UUID()
        self.kind = kind
        self.rect = NormalizedRect(
            x: rect.origin.x,
            y: rect.origin.y,
            width: rect.size.width,
            height: rect.size.height
        )
    }
}

struct CommunityReportLocation: Codable {
    let latitude: Double
    let longitude: Double
    let horizontalAccuracyMeters: Double
}

struct CommunityRedactionDeclaration: Codable {
    let processedOnDevice: Bool
    let faceRegionCount: Int
    let plateRegionCount: Int
    let manualRegionCount: Int
    let userConfirmed: Bool
    let originalUploaded: Bool
}

struct CommunityReportMetadata: Codable {
    let schemaVersion: Int
    let clientReportID: UUID
    let category: CommunityReportCategory
    let description: String
    let capturedAt: Date
    let location: CommunityReportLocation
    let redaction: CommunityRedactionDeclaration
}

struct CommunityReportDraft: Codable, Identifiable {
    let id: UUID
    var status: CommunityDraftStatus
    let metadata: CommunityReportMetadata
    let redactedFilename: String
    let originalFilename: String
    let regions: [RedactionRegion]
    var reportID: UUID?
    var receivedAt: Date?
    var lastErrorCode: String?
}

enum OnDeviceRedaction {
    static func detectRegions(in image: UIImage) async throws -> [RedactionRegion] {
        guard let cgImage = image.cgImage else {
            throw NSError(
                domain: "Redaction",
                code: 1,
                userInfo: [NSLocalizedDescriptionKey: "照片格式無法辨識"]
            )
        }
        return try await withCheckedThrowingContinuation { continuation in
            DispatchQueue.global(qos: .userInitiated).async {
                let faceRequest = VNDetectFaceRectanglesRequest()
                let rectangleRequest = VNDetectRectanglesRequest()
                rectangleRequest.minimumAspectRatio = 0.28
                rectangleRequest.maximumAspectRatio = 0.75
                rectangleRequest.minimumSize = 0.025
                rectangleRequest.minimumConfidence = 0.65
                rectangleRequest.maximumObservations = 12
                do {
                    try VNImageRequestHandler(
                        cgImage: cgImage,
                        orientation: .up
                    ).perform([faceRequest, rectangleRequest])
                    let faces = (faceRequest.results ?? []).map {
                        RedactionRegion(
                            kind: .face,
                            rect: expanded($0.boundingBox, by: 0.08)
                        )
                    }
                    let plateCandidates = (rectangleRequest.results ?? [])
                        .filter { observation in
                            let rect = observation.boundingBox
                            let wideAspect = rect.width / max(rect.height, 0.001)
                            return wideAspect >= 1.7
                                && wideAspect <= 6.5
                                && rect.maxY <= 0.78
                        }
                        .map {
                            RedactionRegion(
                                kind: .plateCandidate,
                                rect: expanded($0.boundingBox, by: 0.10)
                            )
                        }
                    continuation.resume(returning: faces + plateCandidates)
                } catch {
                    continuation.resume(throwing: error)
                }
            }
        }
    }

    static func renderRedacted(
        image: UIImage,
        regions: [RedactionRegion]
    ) -> UIImage {
        let format = UIGraphicsImageRendererFormat()
        format.scale = image.scale
        format.opaque = true
        return UIGraphicsImageRenderer(size: image.size, format: format).image { context in
            image.draw(in: CGRect(origin: .zero, size: image.size))
            context.cgContext.setFillColor(
                UIColor(red: 0.05, green: 0.08, blue: 0.07, alpha: 1).cgColor
            )
            for region in regions {
                let normalized = region.rect.cgRect
                let rect = CGRect(
                    x: normalized.minX * image.size.width,
                    y: (1 - normalized.maxY) * image.size.height,
                    width: normalized.width * image.size.width,
                    height: normalized.height * image.size.height
                )
                let path = UIBezierPath(
                    roundedRect: rect,
                    cornerRadius: max(4, min(rect.width, rect.height) * 0.12)
                )
                path.fill()
            }
        }
    }

    private static func expanded(_ rect: CGRect, by ratio: CGFloat) -> CGRect {
        let dx = rect.width * ratio
        let dy = rect.height * ratio
        return CGRect(
            x: max(0, rect.minX - dx),
            y: max(0, rect.minY - dy),
            width: min(1, rect.maxX + dx) - max(0, rect.minX - dx),
            height: min(1, rect.maxY + dy) - max(0, rect.minY - dy)
        )
    }
}

enum CommunityDraftStore {
    static func save(
        original: UIImage,
        redacted: UIImage,
        category: CommunityReportCategory,
        description: String,
        location: CLLocation,
        regions: [RedactionRegion]
    ) throws -> CommunityReportDraft {
        let id = UUID()
        let directory = try draftsDirectory()
            .appendingPathComponent(id.uuidString, isDirectory: true)
        try FileManager.default.createDirectory(
            at: directory,
            withIntermediateDirectories: true
        )
        guard let originalData = original.jpegData(compressionQuality: 0.94),
              let redactedData = redacted.jpegData(compressionQuality: 0.88) else {
            throw NSError(
                domain: "CommunityDraft",
                code: 1,
                userInfo: [NSLocalizedDescriptionKey: "照片無法儲存"]
            )
        }
        let originalFilename = "original-private.jpg"
        let redactedFilename = "redacted.jpg"
        try originalData.write(
            to: directory.appendingPathComponent(originalFilename),
            options: [.atomic, .completeFileProtection]
        )
        try redactedData.write(
            to: directory.appendingPathComponent(redactedFilename),
            options: [.atomic, .completeFileProtection]
        )

        let declaration = CommunityRedactionDeclaration(
            processedOnDevice: true,
            faceRegionCount: regions.filter { $0.kind == .face }.count,
            plateRegionCount: regions.filter { $0.kind == .plateCandidate }.count,
            manualRegionCount: regions.filter { $0.kind == .manual }.count,
            userConfirmed: true,
            originalUploaded: false
        )
        let metadata = CommunityReportMetadata(
            schemaVersion: 1,
            clientReportID: id,
            category: category,
            description: description,
            capturedAt: Date(),
            location: CommunityReportLocation(
                latitude: location.coordinate.latitude,
                longitude: location.coordinate.longitude,
                horizontalAccuracyMeters: location.horizontalAccuracy
            ),
            redaction: declaration
        )
        let draft = CommunityReportDraft(
            id: id,
            status: .readyToUpload,
            metadata: metadata,
            redactedFilename: redactedFilename,
            originalFilename: originalFilename,
            regions: regions,
            reportID: nil,
            receivedAt: nil,
            lastErrorCode: nil
        )
        try write(draft)
        return draft
    }

    static func all() -> [CommunityReportDraft] {
        guard let directory = try? draftsDirectory(),
              let children = try? FileManager.default.contentsOfDirectory(
                at: directory,
                includingPropertiesForKeys: nil,
                options: [.skipsHiddenFiles]
              ) else {
            return []
        }
        return children.compactMap { child in
            let metadataURL = child.appendingPathComponent("draft.json")
            guard let data = try? Data(contentsOf: metadataURL) else { return nil }
            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601
            return try? decoder.decode(CommunityReportDraft.self, from: data)
        }
        .sorted { $0.metadata.capturedAt > $1.metadata.capturedAt }
    }

    static func redactedURL(for draft: CommunityReportDraft) throws -> URL {
        try draftsDirectory()
            .appendingPathComponent(draft.id.uuidString, isDirectory: true)
            .appendingPathComponent(draft.redactedFilename)
    }

    static func write(_ draft: CommunityReportDraft) throws {
        let directory = try draftsDirectory()
            .appendingPathComponent(draft.id.uuidString, isDirectory: true)
        try FileManager.default.createDirectory(
            at: directory,
            withIntermediateDirectories: true
        )
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        try encoder.encode(draft).write(
            to: directory.appendingPathComponent("draft.json"),
            options: [.atomic, .completeFileProtection]
        )
    }

    private static func draftsDirectory() throws -> URL {
        let base = FileManager.default.urls(
            for: .applicationSupportDirectory,
            in: .userDomainMask
        ).first!
        let directory = base.appendingPathComponent(
            "CommunityReportDrafts",
            isDirectory: true
        )
        try FileManager.default.createDirectory(
            at: directory,
            withIntermediateDirectories: true
        )
        return directory
    }
}

struct CommunityReportReceipt: Codable {
    let reportID: UUID
    let status: CommunityDraftStatus
    let receivedAt: Date
}

struct CommunityRemoteCategory: Codable, Identifiable {
    let id: String
    let title: String
    let enabled: Bool
}

struct CommunityRemoteConfig: Codable {
    let schemaVersion: Int
    let supportedReportSchemaVersions: [Int]
    let supportedEvidenceSchemaVersions: [Int]
    let minimumAppVersion: String
    let featureFlags: [String: Bool]
    let categories: [CommunityRemoteCategory]
    let maximumMediaBytes: Int
    let maximumMediaCount: Int
    let faceConfidenceThreshold: Double
    let plateConfidenceThreshold: Double
    let privacyTermsVersion: String
}

struct CommunityAPIErrorEnvelope: Codable {
    struct APIError: Codable {
        let code: String
        let message: String
        let retryable: Bool
    }

    let error: APIError
}

enum CommunityAPIConfiguration {
    static var baseURL: URL? {
        guard let raw = Bundle.main.object(
            forInfoDictionaryKey: "CommunityAPIBaseURL"
        ) as? String else {
            return nil
        }
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty,
              !trimmed.contains("$("),
              let url = URL(string: trimmed),
              url.scheme?.lowercased() == "https" else {
            return nil
        }
        return url
    }
}

final class CommunityAPIClient {
    enum ClientError: LocalizedError {
        case notConfigured
        case invalidDraft
        case server(code: String, message: String, retryable: Bool)
        case invalidResponse

        var errorDescription: String? {
            switch self {
            case .notConfigured:
                return "社群後端尚未設定"
            case .invalidDraft:
                return "草稿尚未完成裝置端遮蔽"
            case .server(_, let message, _):
                return message
            case .invalidResponse:
                return "伺服器回應格式不正確"
            }
        }
    }

    private let session: URLSession
    private let baseURL: URL

    init(
        baseURL: URL? = CommunityAPIConfiguration.baseURL,
        session: URLSession = .shared
    ) throws {
        guard let baseURL else { throw ClientError.notConfigured }
        self.baseURL = baseURL
        self.session = session
    }

    func fetchRemoteConfig() async throws -> CommunityRemoteConfig {
        let url = baseURL.appendingPathComponent("api/community/config")
        let (data, response) = try await session.data(from: url)
        try validate(response: response, data: data)
        return try decoder().decode(CommunityRemoteConfig.self, from: data)
    }

    func submit(
        draft: CommunityReportDraft,
        accessToken: String
    ) async throws -> CommunityReportReceipt {
        guard draft.status == .readyToUpload,
              draft.metadata.redaction.processedOnDevice,
              draft.metadata.redaction.userConfirmed,
              !draft.metadata.redaction.originalUploaded else {
            throw ClientError.invalidDraft
        }
        let boundary = "WalkReport-\(UUID().uuidString)"
        let bodyURL = try buildMultipartFile(draft: draft, boundary: boundary)
        defer { try? FileManager.default.removeItem(at: bodyURL) }

        var request = URLRequest(
            url: baseURL.appendingPathComponent("api/community/reports")
        )
        request.httpMethod = "POST"
        request.setValue(
            "Bearer \(accessToken)",
            forHTTPHeaderField: "Authorization"
        )
        request.setValue(
            draft.id.uuidString,
            forHTTPHeaderField: "Idempotency-Key"
        )
        request.setValue(
            "multipart/form-data; boundary=\(boundary)",
            forHTTPHeaderField: "Content-Type"
        )
        let (data, response) = try await session.upload(
            for: request,
            fromFile: bodyURL
        )
        try validate(response: response, data: data)
        return try decoder().decode(CommunityReportReceipt.self, from: data)
    }

    func recover(
        clientReportID: UUID,
        accessToken: String
    ) async throws -> CommunityReportReceipt {
        let url = baseURL
            .appendingPathComponent("api/community/reports/by-client-id")
            .appendingPathComponent(clientReportID.uuidString)
        var request = URLRequest(url: url)
        request.setValue(
            "Bearer \(accessToken)",
            forHTTPHeaderField: "Authorization"
        )
        let (data, response) = try await session.data(for: request)
        try validate(response: response, data: data)
        return try decoder().decode(CommunityReportReceipt.self, from: data)
    }

    private func buildMultipartFile(
        draft: CommunityReportDraft,
        boundary: String
    ) throws -> URL {
        let metadataEncoder = JSONEncoder()
        metadataEncoder.dateEncodingStrategy = .iso8601
        let metadata = try metadataEncoder.encode(draft.metadata)
        let media = try Data(contentsOf: CommunityDraftStore.redactedURL(for: draft))
        var body = Data()
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append(
            "Content-Disposition: form-data; name=\"metadata\"\r\n"
                .data(using: .utf8)!
        )
        body.append("Content-Type: application/json\r\n\r\n".data(using: .utf8)!)
        body.append(metadata)
        body.append("\r\n--\(boundary)\r\n".data(using: .utf8)!)
        body.append(
            "Content-Disposition: form-data; name=\"media\"; filename=\"redacted.jpg\"\r\n"
                .data(using: .utf8)!
        )
        body.append("Content-Type: image/jpeg\r\n\r\n".data(using: .utf8)!)
        body.append(media)
        body.append("\r\n--\(boundary)--\r\n".data(using: .utf8)!)

        let target = FileManager.default.temporaryDirectory
            .appendingPathComponent(draft.id.uuidString)
            .appendingPathExtension("multipart")
        try body.write(to: target, options: [.atomic, .completeFileProtection])
        return target
    }

    private func validate(response: URLResponse, data: Data) throws {
        guard let response = response as? HTTPURLResponse else {
            throw ClientError.invalidResponse
        }
        guard (200...299).contains(response.statusCode) else {
            if let envelope = try? decoder().decode(
                CommunityAPIErrorEnvelope.self,
                from: data
            ) {
                throw ClientError.server(
                    code: envelope.error.code,
                    message: envelope.error.message,
                    retryable: envelope.error.retryable
                )
            }
            throw ClientError.invalidResponse
        }
    }

    private func decoder() -> JSONDecoder {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }
}
