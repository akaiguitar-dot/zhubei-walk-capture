//
//  StrayScannerTests.swift
//  StrayScannerTests
//
//  Created by Kenneth Blomqvist on 2/27/21.
//  Copyright © 2021 Stray Robots. All rights reserved.
//

import XCTest
@testable import StrayScanner

class StrayScannerTests: XCTestCase {

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testNpyArrayCreate() throws {
        var frame: CVPixelBuffer? = nil
        let options = [ kCVPixelBufferCGImageCompatibilityKey as String: true, kCVPixelBufferCGBitmapContextCompatibilityKey as String: true ]
        let height: Int32 = 25
        let width: Int32 = 50
        CVPixelBufferCreate(kCFAllocatorDefault, Int(width), Int(height), kCVPixelFormatType_24RGB, options as CFDictionary, &frame)
        CVPixelBufferLockBaseAddress(frame!, CVPixelBufferLockFlags(rawValue: 1))
        let baseAddress = CVPixelBufferGetBaseAddress(frame!)!
        let frameData: UnsafeMutablePointer<UInt16> = baseAddress.assumingMemoryBound(to: UInt16.self)
        
        for i in 0..<height {
            for j in 0..<width {
                let index: Int = Int(i * width + j)
                frameData[index] = UInt16(index)
            }
        }
        let npyArray: NPYArrayWrapper = NPYArrayWrapper(array: frameData, width: width, height: height)!
        let shape = npyArray.shape()!
        
        XCTAssert(shape[0] as! Int == 25)
        XCTAssert(shape[1] as! Int == 50)
        
        let data = npyArray.contents()!
        XCTAssert(data[0] == 0)
        XCTAssert(data[1] == 1)
        XCTAssert(data[Int(width * height - 1)] == width * height - 1)

        CVPixelBufferUnlockBaseAddress(frame!, CVPixelBufferLockFlags(rawValue: 0))
    }

    func testCaptureMissionStateRequiresEndpointConfirmationBeforeReturn() throws {
        var state: CaptureMissionState = .mapSelection
        try state.apply(.selectFeature)
        try state.apply(.confirmStartAnchor)
        try state.apply(.arriveAtEnd)
        XCTAssertEqual(state, .arrivedPendingEndConfirmation)

        XCTAssertThrowsError(try state.apply(.startReturn))
        try state.apply(.confirmEndAnchor)
        XCTAssertEqual(state, .returnReady)
        try state.apply(.startReturn)
        XCTAssertEqual(state, .returnCapture)
    }

    func testCaptureMissionStateRejectsSkippingAnchor() {
        var state: CaptureMissionState = .mapSelection
        XCTAssertThrowsError(try state.apply(.confirmStartAnchor))
        XCTAssertEqual(state, .mapSelection)
    }

    func testImageQualityWarningsDoNotBlockCompletion() {
        let issues = CaptureQualityGate.imageIssues(
            CaptureImageStatistics(
                centralLaplacianVariance: 12,
                meanLuminance: 0.05,
                darkPixelFraction: 0.90,
                clippedHighlightFraction: 0.30,
                centralEdgeDensity: 0.001,
                fullFrameEdgeDensity: 0.10,
                luminanceStandardDeviation: 0.02
            )
        )
        XCTAssertEqual(issues, [.blurred, .tooDark, .overexposed, .lensOccluded])
        XCTAssertFalse(issues.contains(where: \.blocksCompletion))
    }

    func testLumaAnalyzerDarkFrame() throws {
        let statistics = try XCTUnwrap(
            CaptureLumaAnalyzer.analyzeLumaBytes([UInt8](repeating: 0, count: 32 * 32), width: 32, height: 32)
        )
        let issues = CaptureQualityGate.imageIssues(statistics)
        XCTAssertTrue(issues.contains(.tooDark))
        XCTAssertTrue(issues.contains(.blurred))
        XCTAssertFalse(issues.contains(where: \.blocksCompletion))
    }

    func testLumaAnalyzerOverexposedFrame() throws {
        let statistics = try XCTUnwrap(
            CaptureLumaAnalyzer.analyzeLumaBytes([UInt8](repeating: 255, count: 32 * 32), width: 32, height: 32)
        )
        XCTAssertTrue(CaptureQualityGate.imageIssues(statistics).contains(.overexposed))
    }

    func testLumaAnalyzerBlurredGradient() throws {
        let pixels = (0..<(32 * 32)).map { index -> UInt8 in
            let x = index % 32
            return UInt8(80 + (100 * x / 31))
        }
        let statistics = try XCTUnwrap(
            CaptureLumaAnalyzer.analyzeLumaBytes(pixels, width: 32, height: 32)
        )
        let issues = CaptureQualityGate.imageIssues(statistics)
        XCTAssertTrue(issues.contains(.blurred))
        XCTAssertFalse(issues.contains(.tooDark))
        XCTAssertFalse(issues.contains(.overexposed))
    }

    func testLumaAnalyzerDetectsCentralOcclusion() throws {
        var pixels = [UInt8](repeating: 0, count: 40 * 40)
        for y in 0..<40 {
            for x in 0..<40 {
                let outsideValue: UInt8 = ((x / 3 + y / 3) % 2 == 0) ? 60 : 196
                pixels[y * 40 + x] = (x >= 6 && x <= 33 && y >= 6 && y <= 33) ? 128 : outsideValue
            }
        }
        let statistics = try XCTUnwrap(
            CaptureLumaAnalyzer.analyzeLumaBytes(pixels, width: 40, height: 40)
        )
        XCTAssertTrue(CaptureQualityGate.imageIssues(statistics).contains(.lensOccluded))
    }

    func testLumaAnalyzerNormalTexturedFrame() throws {
        let pixels = (0..<(48 * 48)).map { index -> UInt8 in
            let x = index % 48
            let y = index / 48
            return ((x / 4 + y / 5) % 2 == 0) ? 72 : 184
        }
        let statistics = try XCTUnwrap(
            CaptureLumaAnalyzer.analyzeLumaBytes(pixels, width: 48, height: 48)
        )
        XCTAssertTrue(CaptureQualityGate.imageIssues(statistics).isEmpty)
        XCTAssertEqual(CaptureLumaAnalyzer.configuration.analyzerVersion, "walkscan-luma-qc-v1")
    }

    func testMissingAnchorsLegsOrReferencesAreHardBlocks() {
        let issues = CaptureQualityGate.completionIssues(
            hasStartAnchor: false,
            hasEndAnchor: true,
            hasOutboundLeg: true,
            hasReturnLeg: false,
            hasRequiredReferences: false
        )
        XCTAssertEqual(issues, [.missingAnchor, .incompleteLeg, .missingRequiredReference])
        XCTAssertTrue(issues.allSatisfy(\.blocksCompletion))
    }

    func testStartAnchorRequiresEvidenceNearEndpoint() {
        XCTAssertTrue(WalkCaptureEvidenceRules.isStartAnchor(legDistanceMeters: 0))
        XCTAssertTrue(WalkCaptureEvidenceRules.isStartAnchor(legDistanceMeters: 1.25))
        XCTAssertFalse(WalkCaptureEvidenceRules.isStartAnchor(legDistanceMeters: 1.251))
        XCTAssertFalse(WalkCaptureEvidenceRules.isStartAnchor(legDistanceMeters: 4))
    }

    func testP0UsesOneFixedFourMetrePolicy() {
        XCTAssertEqual(WalkCapturePolicy.photoFirstV1.policyID, "photo-first-fixed-4m-v1")
        XCTAssertEqual(WalkCapturePolicy.photoFirstV1.nominalSpacingMeters, 4.0)
    }

    func testViewAdapterMapsGroundAndFloorBothWays() {
        XCTAssertEqual(WalkScanViewAdapter.eventSemanticView(for: .ground), "floor")
        XCTAssertEqual(WalkScanViewAdapter.rawFace(forEventSemantic: "floor"), .ground)
        XCTAssertNil(WalkScanViewAdapter.rawFace(forEventSemantic: "ceiling"))
        XCTAssertNil(WalkScanViewAdapter.eventSemanticView(for: .canopy))
        XCTAssertNil(WalkScanViewAdapter.eventSemanticView(for: .forward))
        XCTAssertNil(WalkScanViewAdapter.eventSemanticView(for: .rear))
    }

    func testSharedAdapterFixtureFailsClosed() throws {
        let fixtureURL = try XCTUnwrap(
            Bundle(for: type(of: self)).url(
                forResource: "event-qc-compatibility",
                withExtension: "json",
                subdirectory: "Fixtures"
            )
        )
        let root = try XCTUnwrap(
            JSONSerialization.jsonObject(with: Data(contentsOf: fixtureURL)) as? [String: Any]
        )
        let vectors = try XCTUnwrap(root["adapterTestVectors"] as? [[String: Any]])
        for vector in vectors {
            let direction = try XCTUnwrap(vector["direction"] as? String)
            let input = try XCTUnwrap(vector["input"] as? String)
            let expected = vector["expected"] as? String
            if direction == "feedback_to_raw" {
                XCTAssertEqual(WalkScanViewAdapter.rawFace(forEventSemantic: input)?.rawValue, expected)
            } else {
                let raw = WalkStationFace(rawValue: input)
                XCTAssertEqual(raw.flatMap(WalkScanViewAdapter.eventSemanticView), expected)
            }
        }
    }

    func testRealPilotPackAndCanonicalGeometryHashes() throws {
        let directory = try XCTUnwrap(
            Bundle.main.url(
                forResource: "real-pilot-candidate-r1",
                withExtension: nil,
                subdirectory: "CapturePacks"
            )
        )
        let pack = try CapturePackVerifier.load(directory: directory)
        XCTAssertEqual(pack.manifest.datasetRevisionID, "CAPTURE-R1-GATE1")
        XCTAssertEqual(pack.manifest.capturePolicy.policyID, "photo-first-fixed-4m-v1")
        XCTAssertEqual(pack.features.count, 1)
        XCTAssertTrue(pack.features[0].isDemo)
    }

    func testSharedProjectionFixtures() throws {
        let fixtureBundle = Bundle(for: type(of: self))
        let directory = try XCTUnwrap(
            fixtureBundle.url(forResource: "synthetic-golden", withExtension: nil, subdirectory: "Fixtures")
        )
        let pack = try CapturePackVerifier.load(directory: directory)
        let fixtureURL = directory.appendingPathComponent("projection-v1.json")
        let root = try XCTUnwrap(
            JSONSerialization.jsonObject(with: Data(contentsOf: fixtureURL)) as? [String: Any]
        )
        let fixtures = try XCTUnwrap(root["fixtures"] as? [[String: Any]])

        for fixture in fixtures {
            let fixtureID = try XCTUnwrap(fixture["fixtureID"] as? String)
            let input = try XCTUnwrap(fixture["input"] as? [String: Any])
            let rawCoordinate = try XCTUnwrap(input["coordinateWGS84"] as? [NSNumber])
            let accuracy = try XCTUnwrap(input["horizontalAccuracyM"] as? NSNumber).doubleValue
            let expected = try XCTUnwrap(fixture["expected"] as? [String: Any])
            let revision: String?
            if fixtureID.hasPrefix("straight-") { revision = "GR-S1" }
            else if fixtureID.hasPrefix("bent-") { revision = "GR-B1" }
            else if fixtureID == "hole-rejected" { revision = "GR-H1" }
            else if fixtureID == "axis-reversal-r1" { revision = "GR-R1" }
            else if fixtureID == "axis-reversal-r2" { revision = "GR-R2" }
            else { revision = nil }

            let result = CaptureAxisProjector.project(
                CLLocationCoordinate2D(latitude: rawCoordinate[1].doubleValue, longitude: rawCoordinate[0].doubleValue),
                accuracyMeters: accuracy,
                features: pack.features,
                selectedGeometryRevisionID: revision
            )
            XCTAssertEqual(result.status.rawValue, expected["status"] as? String, fixtureID)
            if let chainage = expected["chainageMeters"] as? NSNumber {
                let tolerance = (expected["chainageToleranceM"] as? NSNumber)?.doubleValue ?? 0.25
                XCTAssertEqual(try XCTUnwrap(result.chainageMeters), chainage.doubleValue, accuracy: tolerance, fixtureID)
            } else {
                XCTAssertNil(result.chainageMeters, fixtureID)
            }
            if let segment = expected["segmentIndex"] as? NSNumber {
                XCTAssertEqual(result.segmentIndex, segment.intValue, fixtureID)
            }
        }
    }
    
}
