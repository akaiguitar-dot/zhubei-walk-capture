# WalkScan v3：自動照片採集資料契約

WalkScan v3 不錄影。App 在行走過程中自動保存少量、可獨立處理的
RGB-D 照片節點，降低手機儲存、網路傳送與後端處理負擔。

## 自動拍攝規則

- 使用者先站在人行道起點，將手機頂端朝向預定行進方向。
- App 顯示 GPS 精度與方位角；使用者按下「鎖定起點與行進方向」。
- 起點與方向鎖定成功後，App 才開放紅色開始鍵。
- 開始採集後，ARKit 定位正常且手機方向穩定時保存起點照片。
- 沿實際行走路徑每 2 公尺自動保存一個照片節點。
- 使用者停止採集時，若尾端與上一張照片相距至少 0.25 公尺，
  自動補拍尾端照片。
- 使用者不需要按快門。自動拍攝時 App 會震動並閃動準星。
- App 仍可使用 `mapped_segment` 與 `free_route` 兩種採集模式。

## 每張自動照片包含

- 彩色 JPEG 照片
- 同一時間的 LiDAR 深度圖
- LiDAR 深度可信度圖
- 相機三維位置與方向
- 相機內部參數與鏡頭校正資料
- GPS 時間序列
- ARKit 追蹤品質
- 鎖定的起點座標、GPS 精度、行進方位角與方位精度

照片用於網站證據呈現；LiDAR、相機位置及方向用於電腦端建立
兩公尺空間單元、六面幾何與問題辨識。

## 資料夾

```text
mission.json
stations.json
stations/
  station-000000.jpg
  station-000001.jpg
depth/
  000000.png
  000001.png
confidence/
  000000.png
  000001.png
distortion/
  000000.bin
  000001.bin
odometry.csv
locations.csv
camera_matrix.csv
```

WalkScan v3 不包含 `rgb.mp4` 或連續 `imu.csv`。

## 十公尺範例

0、2、4、6、8、10 公尺形成六個照片節點及五個兩公尺空間單元。
如果使用者在 9.3 公尺停止，則會保存 0、2、4、6、8、9.3 公尺，
最後一張作為尾端證據。
