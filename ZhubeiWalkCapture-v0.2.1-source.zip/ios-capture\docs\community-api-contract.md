# Zhubei Walk Community API v1

This contract is shared by the iOS capture app and the responsive web app.
The product records pedestrian-space problems. It does not rank, identify, or
shame people.

## Product rules

- A public item is a `case`, not an accusation against a person.
- Only redacted media may leave the phone.
- Exact coordinates are private moderation data. Public clients receive a
  coarsened coordinate chosen by the backend.
- New reports are never public before moderation.
- Voting ranks verified pedestrian-space cases by improvement priority.
- Every public case owns one discussion thread.
- WalkScan v4 and Community Report v1 are separate payloads and state
  machines. A raw `.walkscan` is never a report media attachment.

## Authentication

Authenticated requests use:

```http
Authorization: Bearer <token>
```

The first release may allow unauthenticated reads. Creating reports, comments,
votes, reports-of-abuse, and blocks requires an authenticated account.

`reporterUserID` is derived exclusively from the validated access token. A
client-supplied reporter identifier is ignored or rejected and is never an
authority for ownership.

## Endpoints

### Create a report

`POST /api/community/reports`

Required request header:

```http
Idempotency-Key: <clientReportID>
```

Retries with the same key and logically identical payload must return the same
receipt rather than create a duplicate report.

Idempotency is scoped by authenticated user and operation. Reusing a key with
a different logical payload returns `IDEMPOTENCY_CONFLICT`. The idempotency
record, report, receipt, and initial media attachment are committed within one
consistency boundary.

`multipart/form-data`:

- `metadata`: UTF-8 JSON matching `ReportMetadata`
- `media`: redacted JPEG, filename `redacted.jpg`

The backend must reject media without a completed redaction declaration and
must queue every submission for moderation.

```json
{
  "schemaVersion": 1,
  "clientReportID": "UUID",
  "category": "blocked_sidewalk",
  "description": "行人必須繞進車道",
  "capturedAt": "2026-07-30T08:15:00Z",
  "location": {
    "latitude": 24.833,
    "longitude": 121.012,
    "horizontalAccuracyMeters": 8.0
  },
  "redaction": {
    "processedOnDevice": true,
    "faceRegionCount": 2,
    "plateRegionCount": 1,
    "manualRegionCount": 0,
    "userConfirmed": true,
    "originalUploaded": false
  }
}
```

Response:

```json
{
  "reportID": "UUID",
  "status": "pending_moderation",
  "receivedAt": "2026-07-30T08:15:03Z"
}
```

### Recover report status

- `GET /api/community/reports/by-client-id/{clientReportID}`
- `GET /api/community/reports/{reportID}`

These endpoints return the current receipt and moderation state so the App can
recover after background transfer, process termination, or an ambiguous
network response.

### List public cases

`GET /api/community/cases?bbox=<west,south,east,north>&status=published`

Response:

```json
{
  "cases": [
    {
      "caseID": "UUID",
      "title": "人行道遭車輛占用",
      "category": "blocked_sidewalk",
      "summary": "行人需繞行車道",
      "publicLatitude": 24.8331,
      "publicLongitude": 121.0121,
      "thumbnailURL": "https://example.invalid/redacted.jpg",
      "status": "published",
      "createdAt": "2026-07-30T08:15:03Z",
      "commentCount": 4,
      "weeklyVoteCount": 21,
      "hasCurrentUserVote": false
    }
  ]
}
```

### Case discussion

- `GET /api/community/cases/{caseID}/comments`
- `POST /api/community/cases/{caseID}/comments`

Comment body:

```json
{
  "body": "下午放學時段特別嚴重"
}
```

The backend must support objectionable-content filtering, content reporting,
user blocking, moderation status, and deletion/appeal workflows.

### Current weekly ballot

- `GET /api/community/votes/current`
- `POST /api/community/votes/current`

Vote body:

```json
{
  "caseID": "UUID"
}
```

One verified account may vote for up to three distinct cases in a ballot.
The backend is the authority for eligibility, rate limits, duplicate-account
signals, opening time, closing time, and final ranking.

### Sanitized WalkScan evidence

A raw WalkScan v4 archive is private professional capture data and is not
accepted by the Community Report endpoint.

Community cases may reference an explicitly sanitized derivative:

- `POST /api/community/reports/{reportID}/evidence`
- `POST /api/community/cases/{caseID}/evidence`

Minimum evidence metadata:

```json
{
  "schemaVersion": 1,
  "evidenceID": "UUID",
  "walkScanID": "UUID",
  "segmentID": "optional-string",
  "stationID": "optional-string",
  "viewID": "optional-string",
  "face": "optional-building-side-or-road-side",
  "mediaRedacted": true,
  "originalUploaded": false,
  "containsPrivateExactLocation": true,
  "publicReferenceAllowed": false
}
```

`containsPrivateExactLocation` is an upload declaration for restricted
ingestion only. It is never present in a public Case or public Evidence DTO.
The backend stores private measured locations separately from public
coarsened locations.

Identifier and view rules:

- `walkScanID` and `evidenceID` are UUID strings.
- `segmentID`, `stationID`, and `viewID` are stable non-empty strings within
  their parent WalkScan.
- `face` is one of `building_side`, `road_side`, `forward`, `backward`, or
  `unspecified`.

Evidence media may include a redacted station JPEG and bounded derived
geometry/depth summaries. It must not include raw RGB images or a complete raw
RGB-D package.

### Resumable media upload

Large evidence media uses a separate upload protocol:

- `POST /api/community/uploads/init`
- upload to the returned signed/resumable URL
- `GET /api/community/uploads/{uploadID}/parts`
- `POST /api/community/uploads/{uploadID}/complete`
- `POST /api/community/uploads/{uploadID}/abort`

The backend contract must define chunk size, checksum, expiry, retry, abort,
and final attachment rules. Small quick-report JPEGs may continue to use the
single multipart report endpoint.

Completion verifies the declared total size, content type, checksum, uploaded
parts, evidence metadata, and redaction declaration before attachment.
Expired or aborted sessions cannot be completed and their orphaned parts are
removed by a scheduled cleanup job.

### Case actions

An Action records a concrete follow-up for a verified public Case:

- `GET /api/community/cases/{caseID}/actions`
- `POST /api/community/cases/{caseID}/actions` (moderator or authorized role)
- `PATCH /api/community/actions/{actionID}` (moderator or authorized role)

Minimum Action DTO:

```json
{
  "schemaVersion": 1,
  "actionID": "UUID",
  "caseID": "UUID",
  "type": "site_verification",
  "status": "planned",
  "summary": "現場複查並確認可通行寬度",
  "createdAt": "2026-07-30T08:15:03Z",
  "updatedAt": "2026-07-30T08:15:03Z"
}
```

`type` is one of `site_verification`, `authority_referral`,
`improvement_proposal`, `follow_up_capture`, or `other`. `status` is one of
`planned`, `in_progress`, `completed`, or `cancelled`.

### Remote configuration

`GET /api/community/config`

The response must include:

- config schema version
- supported Report and Evidence schema versions
- minimum supported App version
- feature flags
- category definitions
- upload size/count limits
- redaction confidence thresholds
- privacy terms version
- voting title, dates, and selection limits

The API base URL is not remotely replaceable by an unsigned config response.
It is supplied by the App build configuration or another trusted signed
mechanism.

### Moderation and safety

- `POST /api/community/cases/{caseID}/report`
- `POST /api/community/comments/{commentID}/report`
- `POST /api/community/users/{userID}/block`
- `DELETE /api/community/account`

## Case categories

- `blocked_sidewalk`
- `corner_obstruction`
- `construction_detour`
- `accessibility_blocked`
- `sidewalk_gap`
- `unsafe_crossing`
- `other`

## Status lifecycles

Report:

```text
local_draft
  -> redaction_required
  -> ready_to_upload
  -> uploading
  -> uploaded
  -> pending_moderation
  -> accepted | needs_changes | rejected
```

An accepted Report may create or merge into a public Case. Report status never
becomes `published`; publication belongs to the Case lifecycle.

The moderation approval that accepts a Report and creates or merges its Case
is one atomic backend operation. A public Case cannot reference unapproved
media, and public media cannot be mapped before that approval succeeds.

Case:

```text
published
  -> under_review
  -> verified
  -> action_planned
  -> improved | closed
```

## Public-location rule

The client submits the measured coordinate privately. The backend stores it in
restricted moderation data and publishes a coarsened point or street segment.
The public response must never echo the private coordinate by default.

Private measured locations and public locations use separate persistence
models and separate response DTOs. The generated public location records the
coarsening policy version. Sensitive contexts such as homes and schools may
apply a stricter policy. The App never generates the public coordinate.

## Media publication rule

Incoming media is stored under a private quarantine object key. After server
privacy checks and moderator approval, the backend creates a newly encoded
public object and then maps it to the public Case. Public APIs and CDN URLs
never reference quarantine keys. Private object access and download are
audited. Takedown first revokes the public mapping and cache, then applies the
retention policy to private material.

## Required error response

Every non-2xx response returns a stable machine code and a user-safe message:

```json
{
  "error": {
    "code": "MEDIA_TOO_LARGE",
    "message": "照片超過目前允許的大小",
    "retryable": false
  }
}
```

The backend must document authentication expiry, token refresh, rate limiting,
schema incompatibility, duplicate/idempotency conflict, media rejection,
moderation rejection, and temporary service errors.
