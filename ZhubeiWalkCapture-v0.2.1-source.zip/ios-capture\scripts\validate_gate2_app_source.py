from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "StrayScanner"
PROJECT = ROOT / "StrayScanner.xcodeproj" / "project.pbxproj"
WEBSITE_PACK = ROOT.parent / "experiments" / "pilot-v69-lab" / "public" / "data" / "capture-packs" / "real-pilot-candidate-r1"
BUNDLED_PACK = APP / "Resources" / "CapturePacks" / "real-pilot-candidate-r1"


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    expected_files = {
        "pack-manifest.json",
        "sidewalk-features.geojson",
        "capture-axes.geojson",
        "canonical-geometries.json",
        "projection-v1.json",
        "lineage.json",
        "pack.sha256",
    }
    for name in expected_files:
        require((BUNDLED_PACK / name).is_file(), f"missing bundled pack file: {name}")
        require(sha256(BUNDLED_PACK / name) == sha256(WEBSITE_PACK / name), f"stale bundled pack file: {name}")

    manifest = json.loads((BUNDLED_PACK / "pack-manifest.json").read_text(encoding="utf-8"))
    require(manifest["immutable"] is True, "pack must be immutable")
    require(manifest["capturePolicy"]["policyID"] == "photo-first-fixed-4m-v1", "policy mismatch")
    require(manifest["status"] == "demo_pending_field_confirmation", "pilot must remain demo")

    project = PROJECT.read_text(encoding="utf-8")
    for filename in (
        "CapturePackKit.swift",
        "CaptureLumaAnalyzer.swift",
        "CaptureMissionMap.swift",
        "MissionEndpointConfirmationViewController.swift",
    ):
        require(project.count(f"{filename} in Sources") >= 4, f"{filename} missing from both app target sections")
    require("CapturePacks in Resources" in project, "capture pack is not in app resources")
    require("Fixtures in Resources" in project, "shared fixtures are not in test resources")

    session_list = (APP / "Views" / "SessionList.swift").read_text(encoding="utf-8")
    require("CaptureMissionMapHome(" in session_list, "functional map is not the normal entry")
    normal_body = session_list.split("var body: some View", 1)[1].split("private var legacyBody", 1)[0]
    require("onLocateMe: { }" not in normal_body, "normal locate action is a no-op")
    require("onOpenReport: { }" not in normal_body, "normal report action is a no-op")
    require("onOpenHistory: { }" not in normal_body, "normal history action is a no-op")

    map_source = (APP / "Views" / "CaptureMissionMap.swift").read_text(encoding="utf-8")
    require("MKMapView" in map_source and "showsUserLocation = true" in map_source, "MapKit positioning missing")
    require("起點必須在路段端點附近" in map_source, "endpoint-only start gate missing")
    require("buildingSide!" not in map_source and "let buildingSide else" in map_source, "building side must fail closed")
    require("DEMO 圖資" in map_source, "demo disclosure missing")

    encoder = (APP / "Helpers" / "DatasetEncoder.swift").read_text(encoding="utf-8")
    require("eventSemanticView" in encoder, "event adapter missing")
    require("case .forward, .rear, .canopy: return nil" in encoder, "event adapter is not fail closed")
    require("prepareReturnEndpointEvidence" in encoder, "return endpoint evidence gate missing")
    require("endpointToleranceMeters = 1.25" in encoder, "start anchor tolerance missing")
    require("CaptureLumaAnalyzer.analyze(pixelBuffer: frame.capturedImage)" in encoder, "luma QC is not on the capture path")
    require("imageQuality: imageQualitySummary()" in encoder, "private mission-context image QC missing")
    require("imageQualityAffectedStationIDs" in encoder, "affected station references missing")

    analyzer = (APP / "Helpers" / "CaptureLumaAnalyzer.swift").read_text(encoding="utf-8")
    require("walkscan-luma-qc-v1" in analyzer, "luma analyzer is not versioned")
    require("CVPixelBufferGetBaseAddressOfPlane(pixelBuffer, 0)" in analyzer, "analyzer does not read luma plane")
    require("targetLongEdgeSamples: 160" in analyzer, "bounded downsample configuration missing")

    controller = (APP / "Controllers" / "RecordSessionViewController.swift").read_text(encoding="utf-8")
    require("MissionEndpointConfirmationViewController" in controller, "real endpoint map is not wired")
    require("presentFieldQC" in controller and "WalkCaptureEvidenceSnapshot" in controller, "field QC evidence gate missing")
    require("imageQualityObservationCount" in controller, "field QC does not show actual observation count")
    require("imageQualityIssueCounts" in controller, "field QC does not show actual issue count")
    require("尚未自動判讀清晰度與曝光" not in controller, "obsolete image-QC limitation remains")
    require("仍要保存不完整資料" not in controller, "hard-block bypass remains")

    tests = (ROOT / "StrayScannerTests" / "StrayScannerTests.swift").read_text(encoding="utf-8")
    for test_name in (
        "testLumaAnalyzerDarkFrame",
        "testLumaAnalyzerOverexposedFrame",
        "testLumaAnalyzerBlurredGradient",
        "testLumaAnalyzerDetectsCentralOcclusion",
        "testLumaAnalyzerNormalTexturedFrame",
    ):
        require(test_name in tests, f"missing pure-luma XCTest: {test_name}")

    print("Gate 2/3 static source/resource checks passed")


if __name__ == "__main__":
    main()
