# Windows 安裝與更新：竹北人行道採集 App

你不需要購買 Mac，但 Apple 的免費個人簽章仍有 7 天期限。更新 App 不會把 7 天再疊加；每次成功簽署後，期限會從當次重新計算。

## 平常使用：只做兩件事

1. Windows 保持 AltServer 開啟。
2. iPhone 與 Windows 在同一個 Wi-Fi；AltStore 會嘗試背景重新簽署。

如果背景更新失敗，再以 USB 連線重試。

## 安裝新版本

1. 下載新的 `.ipa` 檔。
2. Windows 開啟 AltServer。
3. iPhone 用 USB 接上電腦，並按「信任」。
4. 手機開啟 AltStore。
5. 在「My Apps」右上角按 `+`。
6. 選取新的 `.ipa`。
7. 等待安裝完成後，直接開啟「竹北人行道採集」。

只要 App 的識別碼與簽章帳號相同，新版會覆蓋舊版；既有採集資料原則上會保留。重要資料仍應先傳回 Windows。

## 第一次啟用

若 iPhone 阻擋 App：

1. 開啟「設定」。
2. 進入「一般」→「VPN 與裝置管理」。
3. 信任你自己的 Apple 帳號開發者憑證。
4. 若系統要求，啟用「開發者模式」並重新啟動。

## 開始私密接收器

在 Windows 的專案資料夾開啟 PowerShell，執行：

```powershell
powershell -ExecutionPolicy Bypass -File scripts\start_walkscan_receiver.ps1
```

記下畫面顯示的網址，例如：

```text
http://192.168.1.25:8787
```

在 App 首頁「私密接收器」輸入這個網址。網址只接受區域網路位址，原始 `.walkscan` 不會送到公共網站。

外出時若要直接傳到自己的私人雲端處理器，必須使用 HTTPS，並在
App 填入該處理器的私人金鑰。區域網路模式不必填金鑰。

## 現場測試順序

1. 選「自由動線」。
2. 輸入路段名稱，例如 `FREE-TEST-001`。
3. 第一次先用「快速路線」走 6～10 公尺。
4. App 顯示定位與 LiDAR 可用後，再開始採集。
5. 保持手機大致在目視高度，平穩向前。
6. 結束後等待 App 顯示已排入傳送。
7. Windows 接收器會自動驗證與產生結果。
8. 再以相同短路段測試「六面採集」。

## 常見問題

### AltServer could not be found

- 確認 Windows 的 AltServer 正在執行。
- 手機與電腦使用同一個 Wi-Fi。
- 先用 USB 連接並保持解鎖。
- Windows 防火牆需允許 AltServer。

### App 沒有傳到電腦

- 確認接收器視窗仍開著。
- 確認 App 內網址與 Windows 顯示的網址完全相同。
- 確認手機已允許「本機網路」權限。
- 資料會留在手機的待傳佇列，重新開啟 App 後會再試。

### 可以直接把原始資料傳到公共雲端嗎

目前不會。原始 WalkScan 包含精確位置、姿態與未遮蔽照片，只能進入私密接收流程。公共通報必須使用裝置端已遮蔽的獨立證據檔。
