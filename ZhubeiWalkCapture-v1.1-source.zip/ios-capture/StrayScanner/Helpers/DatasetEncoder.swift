//
//  DatasetEncoder.swift
//  StrayScanner
//
//  Created by Kenneth Blomqvist on 1/2/21.
//  Copyright © 2021 Stray Robots. All rights reserved.
//

import Foundation
import ARKit
import CryptoKit
import CoreLocation
import CoreImage
import UIKit

private struct LocationSample: Codable {
    let timestamp: Double
    let latitude: Double
    let longitude: Double
    let altitude: Double
    let horizontalAccuracy: Double
    let verticalAccuracy: Double
    let speed: Double
    let course: Double

    init(location: CLLocation) {
        timestamp = location.timestamp.timeIntervalSince1970
        latitude = location.coordinate.latitude
        longitude = location.coordinate.longitude
        altitude = location.altitude
        horizontalAccuracy = location.horizontalAccuracy
        verticalAccuracy = location.verticalAccuracy
        speed = location.speed
        course = location.course
    }
}

struct WalkCaptureOrigin: Codable {
    let latitude: Double
    let longitude: Double
    let altitude: Double
    let horizontalAccuracyMeters: Double
    let verticalAccuracyMeters: Double
    let headingDegrees: Double
    let headingAccuracyDegrees: Double
    let lockedAt: Date
}

private struct WalkScanManifest: Codable {
    let schemaVersion: Int
    let source: String
    let captureMethod: String
    let guidanceMode: String
    let guidanceSpacingMeters: Double
    let guidancePlanningWindowMeters: Double
    let origin: WalkCaptureOrigin
    let captureMode: String
    let captureProfile: String
    let buildingSide: String
    let segmentID: String
    let targetLengthMeters: Double
    let expectedTravelMeters: Double
    let measuredTravelMeters: Double
    let requiresReturnTrip: Bool
    let stationSpacingMeters: Double
    let capturedStationCount: Int
    let systemBootEpochSeconds: Double
    let odometryTimestampTimebase: String
    let captureStartedAt: Date
    let captureCompletedAt: Date
    let deviceModel: String
    let operatingSystem: String
    let contents: [String]
}

enum WalkStationFace: String, Codable, CaseIterable {
    case forward
    case buildingSide = "building_side"
    case roadSide = "road_side"
    case ground
    case canopy

    var prompt: String {
        switch self {
        case .forward:
            return "看向前方"
        case .buildingSide:
            return "稍微轉向建築側"
        case .roadSide:
            return "稍微轉向道路側"
        case .ground:
            return "鏡頭稍微朝下，看鋪面"
        case .canopy:
            return "鏡頭稍微朝上，看遮陰"
        }
    }
}

struct WalkCaptureUpdate {
    let stationSequence: Int
    let face: WalkStationFace
    let isStationComplete: Bool
    let nextPrompt: String?
}

private struct WalkStationView: Codable {
    let face: WalkStationFace
    let frame: String
    let frameTimestamp: Double
    let capturedAtEpochSeconds: Double
    let rgbImage: String
    let depthImage: String
    let confidenceImage: String
    let trackingQuality: String
    let imageWidthPixels: Int
    let imageHeightPixels: Int
    let cameraPositionMeters: [Float]
    let cameraQuaternion: [Float]
    let cameraEulerRadians: [Float]
    let cameraIntrinsics: [Float]
}

private struct WalkStation: Codable {
    let stationID: String
    let sequence: Int
    let direction: String
    let legIndex: Int
    let legDistanceMeters: Double
    let nominalRouteDistanceMeters: Double
    let measuredRouteDistanceMeters: Double
    let frame: String
    let frameTimestamp: Double
    let capturedAtEpochSeconds: Double
    let rgbImage: String
    let depthImage: String
    let confidenceImage: String
    let trackingQuality: String
    let imageWidthPixels: Int
    let imageHeightPixels: Int
    let cameraPositionMeters: [Float]
    let cameraQuaternion: [Float]
    let cameraEulerRadians: [Float]
    let cameraIntrinsics: [Float]
    let requiredFaces: [WalkStationFace]
    let capturedFaces: [WalkStationFace]
    let missingFaces: [WalkStationFace]
    let captureComplete: Bool
    let views: [WalkStationView]
}

private struct WalkStationIndex: Codable {
    let schemaVersion: Int
    let spacingMeters: Double
    let coordinateSystem: String
    let imageOrientation: String
    let stations: [WalkStation]
}

private struct StationReservation {
    let sequence: Int
    let nominalRouteDistanceMeters: Double
    let measuredRouteDistanceMeters: Double
}

private struct DetailedStationState {
    let reservation: StationReservation
    let referenceYaw: Float
    var nextFaceIndex: Int
    var lastCaptureTimestamp: TimeInterval
}

private struct StationAccumulator {
    let reservation: StationReservation
    var views: [WalkStationView]
}

private final class RouteTraceEncoder {
    let path: URL
    private let fileHandle: FileHandle
    private var lastTimestamp: TimeInterval = -1

    init(url: URL) {
        path = url
        do {
            try "".write(to: path, atomically: true, encoding: .utf8)
            fileHandle = try FileHandle(forWritingTo: path)
            fileHandle.write(
                "timestamp,x,y,z,qx,qy,qz,qw,tracking_quality\n"
                    .data(using: .utf8)!
            )
        } catch {
            preconditionFailure("Can't create route trace: \(error.localizedDescription)")
        }
    }

    func add(frame: ARFrame, quality: String) {
        guard frame.timestamp - lastTimestamp >= 0.20 else { return }
        lastTimestamp = frame.timestamp
        let transform = frame.camera.transform
        let position = transform.columns.3
        let quaternion = simd_quatf(transform).vector
        let line = [
            "\(frame.timestamp)",
            "\(position.x)",
            "\(position.y)",
            "\(position.z)",
            "\(quaternion.x)",
            "\(quaternion.y)",
            "\(quaternion.z)",
            "\(quaternion.w)",
            quality
        ].joined(separator: ",") + "\n"
        fileHandle.write(line.data(using: .utf8)!)
    }

    func done() {
        try? fileHandle.close()
    }
}

class DatasetEncoder {
    enum Status {
        case allGood
        case encodingError
        case directoryCreationError
    }
    private let depthEncoder: DepthEncoder
    private let confidenceEncoder: ConfidenceEncoder
    private let datasetDirectory: URL
    private let odometryEncoder: OdometryEncoder
    private let routeTraceEncoder: RouteTraceEncoder
    private let distortionEncoder: DistortionEncoder
    private let mission: WalkMission
    private let origin: WalkCaptureOrigin
    private let stationDirectory: URL
    private let stationImageContext = CIContext(options: [.cacheIntermediates: false])
    private let stationSpacingMeters: Double = 2.0
    private let systemBootEpochSeconds =
        Date().timeIntervalSince1970 - ProcessInfo.processInfo.systemUptime
    private let captureStartedAt = Date()
    private let locationLock = NSLock()
    private var locationSamples: [LocationSample] = []
    private var lastCameraIntrinsics: simd_float3x3?
    private var dispatchGroup = DispatchGroup()
    private var savedFrames: Int = 0
    private var nextStationDistanceMeters: Double = 0.0
    private var lastReservedDistanceMeters: Double?
    private var reservedStationCount: Int = 0
    private var stationAccumulators: [Int: StationAccumulator] = [:]
    private var activeDetailedStation: DetailedStationState?
    private let encodingSemaphore = DispatchSemaphore(value: 3) // Limit queued frames to avoid ARFrame retention
    public let id: UUID
    // Kept under the historical Core Data property name. It now points to the
    // manifest and acts only as the stable anchor for the dataset directory.
    public let rgbFilePath: URL
    public let depthFilePath: URL // Relative to app document directory.
    public let cameraMatrixPath: URL
    public let odometryPath: URL
    public var status = Status.allGood
    private let queue: DispatchQueue
    
    init(mission: WalkMission, origin: WalkCaptureOrigin) {
        self.mission = mission
        self.origin = origin
        self.queue = DispatchQueue(label: "encoderQueue")

        var theId: UUID = UUID()
        datasetDirectory = DatasetEncoder.createDirectory(id: &theId)
        self.id = theId
        self.rgbFilePath = datasetDirectory.appendingPathComponent("mission.json")
        self.depthFilePath = datasetDirectory.appendingPathComponent("depth", isDirectory: true)
        self.depthEncoder = DepthEncoder(outDirectory: self.depthFilePath)
        let confidenceFilePath = datasetDirectory.appendingPathComponent("confidence", isDirectory: true)
        self.confidenceEncoder = ConfidenceEncoder(outDirectory: confidenceFilePath)
        self.cameraMatrixPath = datasetDirectory.appendingPathComponent("camera_matrix.csv", isDirectory: false)
        self.odometryPath = datasetDirectory.appendingPathComponent("odometry.csv", isDirectory: false)
        self.odometryEncoder = OdometryEncoder(url: self.odometryPath)
        self.routeTraceEncoder = RouteTraceEncoder(
            url: datasetDirectory.appendingPathComponent("route.csv")
        )
        self.distortionEncoder = DistortionEncoder(datasetDirectory: datasetDirectory)
        self.stationDirectory = datasetDirectory.appendingPathComponent("stations", isDirectory: true)
        do {
            try FileManager.default.createDirectory(
                at: stationDirectory,
                withIntermediateDirectories: true,
                attributes: nil
            )
        } catch {
            print("Could not create station directory. \(error.localizedDescription)")
        }
    }

    func addRouteFrame(_ frame: ARFrame) {
        routeTraceEncoder.add(
            frame: frame,
            quality: trackingQuality(frame.camera.trackingState)
        )
    }

    @discardableResult
    func add(frame: ARFrame, travelDistance: Double) -> WalkCaptureUpdate? {
        guard case .normal = frame.camera.trackingState,
              frame.sceneDepth != nil else {
            return nil
        }

        if mission.captureProfile == .quickRoute {
            guard isLevelForwardFrame(frame),
                  travelDistance + 0.05 >= nextStationDistanceMeters else {
                return nil
            }
            let reservation = reserveStation(
                nominalDistance: nextStationDistanceMeters,
                measuredDistance: travelDistance
            )
            nextStationDistanceMeters += stationSpacingMeters
            guard capture(
                frame: frame,
                reservation: reservation,
                face: .forward
            ) else {
                return nil
            }
            return WalkCaptureUpdate(
                stationSequence: reservation.sequence,
                face: .forward,
                isStationComplete: true,
                nextPrompt: nil
            )
        }

        if activeDetailedStation == nil {
            guard travelDistance + 0.05 >= nextStationDistanceMeters,
                  isLevelForwardFrame(frame) else {
                return nil
            }
            let reservation = reserveStation(
                nominalDistance: nextStationDistanceMeters,
                measuredDistance: travelDistance
            )
            activeDetailedStation = DetailedStationState(
                reservation: reservation,
                referenceYaw: cameraYaw(frame),
                nextFaceIndex: 0,
                lastCaptureTimestamp: -1
            )
        }

        guard var state = activeDetailedStation else { return nil }
        let requiredFaces = requiredFacesForMission()
        guard state.nextFaceIndex < requiredFaces.count else { return nil }
        let face = requiredFaces[state.nextFaceIndex]
        guard frame.timestamp - state.lastCaptureTimestamp >= 0.35,
              frameMatches(face: face, frame: frame, referenceYaw: state.referenceYaw),
              capture(frame: frame, reservation: state.reservation, face: face) else {
            return nil
        }

        state.nextFaceIndex += 1
        state.lastCaptureTimestamp = frame.timestamp
        let complete = state.nextFaceIndex >= requiredFaces.count
        let nextPrompt = complete ? nil : requiredFaces[state.nextFaceIndex].prompt
        if complete {
            nextStationDistanceMeters += stationSpacingMeters
            activeDetailedStation = nil
        } else {
            activeDetailedStation = state
        }
        return WalkCaptureUpdate(
            stationSequence: state.reservation.sequence,
            face: face,
            isStationComplete: complete,
            nextPrompt: nextPrompt
        )
    }

    /// Captures a route endpoint when the user stops between regular two-metre
    /// stations. If the last automatic photo is already close enough, it is
    /// reused as the endpoint instead of creating a duplicate.
    @discardableResult
    func addFinal(frame: ARFrame?, travelDistance: Double) -> WalkCaptureUpdate? {
        guard let frame else { return nil }
        guard case .normal = frame.camera.trackingState else { return nil }
        if let active = activeDetailedStation {
            activeDetailedStation = nil
            nextStationDistanceMeters += stationSpacingMeters
            return WalkCaptureUpdate(
                stationSequence: active.reservation.sequence,
                face: .forward,
                isStationComplete: false,
                nextPrompt: nil
            )
        }
        if let lastDistance = lastReservedDistanceMeters,
           abs(travelDistance - lastDistance) < 0.25 {
            return nil
        }
        let reservation = reserveStation(
            nominalDistance: travelDistance,
            measuredDistance: travelDistance
        )
        guard capture(frame: frame, reservation: reservation, face: .forward) else {
            return nil
        }
        return WalkCaptureUpdate(
            stationSequence: reservation.sequence,
            face: .forward,
            isStationComplete: mission.captureProfile == .quickRoute,
            nextPrompt: nil
        )
    }

    private func capture(
        frame: ARFrame,
        reservation: StationReservation,
        face: WalkStationFace
    ) -> Bool {
        guard encodingSemaphore.wait(timeout: .now()) == .success else { return false }
        let frameNumber = savedFrames
        savedFrames += 1
        dispatchGroup.enter()
        queue.async {
            defer {
                self.encodingSemaphore.signal()
                self.dispatchGroup.leave()
            }
            if let sceneDepth = frame.sceneDepth {
                self.depthEncoder.encodeFrame(
                    frame: sceneDepth.depthMap,
                    frameNumber: frameNumber
                )
                if let confidence = sceneDepth.confidenceMap {
                    self.confidenceEncoder.encodeFrame(
                        frame: confidence,
                        frameNumber: frameNumber
                    )
                } else {
                    print("warning: confidence map missing.")
                }
            } else {
                print("warning: scene depth missing.")
            }
            self.odometryEncoder.add(frame: frame, currentFrame: frameNumber)
            self.distortionEncoder.add(frame: frame, currentFrame: frameNumber)
            self.encodeStationView(
                frame: frame,
                frameNumber: frameNumber,
                reservation: reservation,
                face: face
            )
            self.lastCameraIntrinsics = frame.camera.intrinsics
        }
        return true
    }

    private func isLevelForwardFrame(_ frame: ARFrame) -> Bool {
        let euler = frame.camera.eulerAngles
        return abs(euler.x) <= 0.55 && abs(euler.z) <= 0.35
    }

    private func requiredFacesForMission() -> [WalkStationFace] {
        mission.captureProfile == .sixFace
            ? [.forward, .buildingSide, .roadSide, .ground, .canopy]
            : [.forward]
    }

    private func cameraYaw(_ frame: ARFrame) -> Float {
        let forward = -SIMD3<Float>(
            frame.camera.transform.columns.2.x,
            frame.camera.transform.columns.2.y,
            frame.camera.transform.columns.2.z
        )
        return atan2(forward.x, -forward.z)
    }

    private func angleDifference(_ lhs: Float, _ rhs: Float) -> Float {
        var value = lhs - rhs
        while value > .pi { value -= 2 * .pi }
        while value < -.pi { value += 2 * .pi }
        return value
    }

    private func frameMatches(
        face: WalkStationFace,
        frame: ARFrame,
        referenceYaw: Float
    ) -> Bool {
        let transform = frame.camera.transform
        let forward = -SIMD3<Float>(
            transform.columns.2.x,
            transform.columns.2.y,
            transform.columns.2.z
        )
        guard abs(frame.camera.eulerAngles.z) <= 0.38 else { return false }
        let yawDelta = angleDifference(cameraYaw(frame), referenceYaw)
        let buildingTarget: Float = mission.buildingSide == .left ? -0.61 : 0.61

        switch face {
        case .forward:
            return abs(yawDelta) <= 0.24 && abs(forward.y) <= 0.30
        case .buildingSide:
            return abs(angleDifference(yawDelta, buildingTarget)) <= 0.22
                && abs(forward.y) <= 0.34
        case .roadSide:
            return abs(angleDifference(yawDelta, -buildingTarget)) <= 0.22
                && abs(forward.y) <= 0.34
        case .ground:
            return forward.y <= -0.28
        case .canopy:
            return forward.y >= 0.22
        }
    }

    private func reserveStation(
        nominalDistance: Double,
        measuredDistance: Double
    ) -> StationReservation {
        let reservation = StationReservation(
            sequence: reservedStationCount,
            nominalRouteDistanceMeters: nominalDistance,
            measuredRouteDistanceMeters: measuredDistance
        )
        reservedStationCount += 1
        lastReservedDistanceMeters = measuredDistance
        return reservation
    }

    private func encodeStationView(
        frame: ARFrame,
        frameNumber: Int,
        reservation: StationReservation,
        face: WalkStationFace
    ) {
        let frameName = String(format: "%06d", frameNumber)
        let imageFilename =
            "station-\(String(format: "%06d", reservation.sequence))-\(face.rawValue).jpg"
        let relativeImagePath = "stations/\(imageFilename)"
        let imageURL = stationDirectory.appendingPathComponent(imageFilename)
        let sourceImage = CIImage(cvPixelBuffer: frame.capturedImage)

        do {
            if let jpegData = stationImageContext.jpegRepresentation(
                of: sourceImage,
                colorSpace: CGColorSpaceCreateDeviceRGB(),
                options: [:]
            ) {
                try jpegData.write(to: imageURL, options: .atomic)
            } else {
                print("Could not create JPEG for station \(reservation.sequence).")
            }
        } catch {
            print("Could not save station \(reservation.sequence). \(error.localizedDescription)")
        }

        let transform = frame.camera.transform
        let position = transform.columns.3
        let quaternion = simd_quatf(transform).vector
        let euler = frame.camera.eulerAngles
        let intrinsics = frame.camera.intrinsics

        let view = WalkStationView(
            face: face,
            frame: frameName,
            frameTimestamp: frame.timestamp,
            capturedAtEpochSeconds: systemBootEpochSeconds + frame.timestamp,
            rgbImage: relativeImagePath,
            depthImage: "depth/\(frameName).png",
            confidenceImage: "confidence/\(frameName).png",
            trackingQuality: trackingQuality(frame.camera.trackingState),
            imageWidthPixels: CVPixelBufferGetWidth(frame.capturedImage),
            imageHeightPixels: CVPixelBufferGetHeight(frame.capturedImage),
            cameraPositionMeters: [position.x, position.y, position.z],
            cameraQuaternion: [quaternion.x, quaternion.y, quaternion.z, quaternion.w],
            cameraEulerRadians: [euler.x, euler.y, euler.z],
            cameraIntrinsics: [
                intrinsics.columns.0.x, intrinsics.columns.0.y, intrinsics.columns.0.z,
                intrinsics.columns.1.x, intrinsics.columns.1.y, intrinsics.columns.1.z,
                intrinsics.columns.2.x, intrinsics.columns.2.y, intrinsics.columns.2.z
            ]
        )
        var accumulator = stationAccumulators[reservation.sequence]
            ?? StationAccumulator(reservation: reservation, views: [])
        accumulator.views.append(view)
        stationAccumulators[reservation.sequence] = accumulator
    }

    private func trackingQuality(_ state: ARCamera.TrackingState) -> String {
        switch state {
        case .normal:
            return "normal"
        case .notAvailable:
            return "not_available"
        case .limited(let reason):
            switch reason {
            case .excessiveMotion:
                return "limited_excessive_motion"
            case .insufficientFeatures:
                return "limited_insufficient_features"
            case .initializing:
                return "limited_initializing"
            case .relocalizing:
                return "limited_relocalizing"
            @unknown default:
                return "limited_unknown"
            }
        }
    }
    
    func add(location: CLLocation) {
        guard location.horizontalAccuracy >= 0 else { return }
        locationLock.lock()
        locationSamples.append(LocationSample(location: location))
        locationLock.unlock()
    }

    func wrapUp(travelDistance: Double) {
        dispatchGroup.wait()
        self.odometryEncoder.done()
        self.routeTraceEncoder.done()
        self.distortionEncoder.done()
        writeIntrinsics()
        writeStationIndex()
        writeMissionManifest(travelDistance: travelDistance)
        writeLocations()
        status = .allGood
        switch self.depthEncoder.status {
            case .allGood:
                break
            case .frameEncodingError:
                status = .encodingError
                print("Something went wrong encoding depth.")
        }
        switch self.confidenceEncoder.status {
            case .allGood:
                break
            case .encodingError:
                status = .encodingError
                print("Something went wrong encoding confidence values.")
        }
    }

    private func writeMissionManifest(travelDistance: Double) {
        let manifest = WalkScanManifest(
            schemaVersion: 4,
            source: "ZhubeiWalkCapture",
            captureMethod: "guided_rgbd_stills",
            guidanceMode: "rolling_lidar_ar_gates",
            guidanceSpacingMeters: stationSpacingMeters,
            guidancePlanningWindowMeters: 5.0,
            origin: origin,
            captureMode: mission.captureMode.rawValue,
            captureProfile: mission.captureProfile.rawValue,
            buildingSide: mission.buildingSide.rawValue,
            segmentID: mission.segmentID,
            targetLengthMeters: mission.targetLengthMeters,
            expectedTravelMeters: mission.expectedTravelMeters,
            measuredTravelMeters: travelDistance,
            requiresReturnTrip: mission.requiresReturnTrip,
            stationSpacingMeters: stationSpacingMeters,
            capturedStationCount: stationAccumulators.count,
            systemBootEpochSeconds: systemBootEpochSeconds,
            odometryTimestampTimebase: "seconds_since_system_boot",
            captureStartedAt: captureStartedAt,
            captureCompletedAt: Date(),
            deviceModel: UIDevice.current.model,
            operatingSystem: "\(UIDevice.current.systemName) \(UIDevice.current.systemVersion)",
            contents: [
                "depth/*.png",
                "confidence/*.png",
                "odometry.csv",
                "route.csv",
                "locations.csv",
                "camera_matrix.csv",
                "stations.json",
                "stations/*.jpg"
            ]
        )
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        do {
            let data = try encoder.encode(manifest)
            try data.write(to: datasetDirectory.appendingPathComponent("mission.json"), options: .atomic)
        } catch {
            print("Could not write mission manifest. \(error.localizedDescription)")
        }
    }

    private func buildStations() -> [WalkStation] {
        let requiredFaces = requiredFacesForMission()
        return stationAccumulators.values
            .sorted { $0.reservation.sequence < $1.reservation.sequence }
            .compactMap { accumulator in
                guard let primary = accumulator.views.first(where: { $0.face == .forward })
                    ?? accumulator.views.first else {
                    return nil
                }
                let reservation = accumulator.reservation
                let direction: String
                let legIndex: Int
                let legDistance: Double
                let legCode: String

                if mission.captureMode == .freeRoute {
                    direction = "free"
                    legIndex = 0
                    legDistance = reservation.nominalRouteDistanceMeters
                    legCode = "P"
                } else if mission.requiresReturnTrip
                            && reservation.nominalRouteDistanceMeters > mission.targetLengthMeters {
                    direction = "return"
                    legIndex = 1
                    legDistance =
                        reservation.nominalRouteDistanceMeters - mission.targetLengthMeters
                    legCode = "R"
                } else {
                    direction = "outbound"
                    legIndex = 0
                    legDistance = reservation.nominalRouteDistanceMeters
                    legCode = "F"
                }

                let safeSegmentID = mission.segmentID.replacingOccurrences(
                    of: "[^A-Za-z0-9_-]",
                    with: "-",
                    options: .regularExpression
                )
                let stationID =
                    "\(safeSegmentID)-\(legCode)-\(String(format: "%03d", reservation.sequence))"
                let capturedFaces = accumulator.views.map(\.face)
                let missingFaces = requiredFaces.filter { !capturedFaces.contains($0) }

                return WalkStation(
                    stationID: stationID,
                    sequence: reservation.sequence,
                    direction: direction,
                    legIndex: legIndex,
                    legDistanceMeters: legDistance,
                    nominalRouteDistanceMeters: reservation.nominalRouteDistanceMeters,
                    measuredRouteDistanceMeters: reservation.measuredRouteDistanceMeters,
                    frame: primary.frame,
                    frameTimestamp: primary.frameTimestamp,
                    capturedAtEpochSeconds: primary.capturedAtEpochSeconds,
                    rgbImage: primary.rgbImage,
                    depthImage: primary.depthImage,
                    confidenceImage: primary.confidenceImage,
                    trackingQuality: primary.trackingQuality,
                    imageWidthPixels: primary.imageWidthPixels,
                    imageHeightPixels: primary.imageHeightPixels,
                    cameraPositionMeters: primary.cameraPositionMeters,
                    cameraQuaternion: primary.cameraQuaternion,
                    cameraEulerRadians: primary.cameraEulerRadians,
                    cameraIntrinsics: primary.cameraIntrinsics,
                    requiredFaces: requiredFaces,
                    capturedFaces: capturedFaces,
                    missingFaces: missingFaces,
                    captureComplete: missingFaces.isEmpty,
                    views: accumulator.views
                )
            }
    }

    private func writeStationIndex() {
        let index = WalkStationIndex(
            schemaVersion: 2,
            spacingMeters: stationSpacingMeters,
            coordinateSystem: "ARKit gravityAndHeading: +x east, +y up, +z south, metres",
            imageOrientation: "native camera sensor orientation; use intrinsics without rotating pixels",
            stations: buildStations()
        )
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        do {
            let data = try encoder.encode(index)
            try data.write(
                to: datasetDirectory.appendingPathComponent("stations.json"),
                options: .atomic
            )
        } catch {
            print("Could not write station index. \(error.localizedDescription)")
        }
    }

    private func writeLocations() {
        locationLock.lock()
        let samples = locationSamples
        locationLock.unlock()

        var lines = [
            "timestamp,latitude,longitude,altitude,horizontal_accuracy,vertical_accuracy,speed,course"
        ]
        lines.append(contentsOf: samples.map {
            "\($0.timestamp),\($0.latitude),\($0.longitude),\($0.altitude),\($0.horizontalAccuracy),\($0.verticalAccuracy),\($0.speed),\($0.course)"
        })
        do {
            try lines.joined(separator: "\n").write(
                to: datasetDirectory.appendingPathComponent("locations.csv"),
                atomically: true,
                encoding: .utf8
            )
        } catch {
            print("Could not write locations. \(error.localizedDescription)")
        }
    }

    private func writeIntrinsics() {
        if let cameraMatrix = lastCameraIntrinsics {
            let rows = cameraMatrix.transpose.columns
            var csv: [String] = []
            for row in [rows.0, rows.1, rows.2] {
                let csvLine = "\(row.x), \(row.y), \(row.z)"
                csv.append(csvLine)
            }
            let contents = csv.joined(separator: "\n")
            do {
                try contents.write(to: self.cameraMatrixPath, atomically: true, encoding: String.Encoding.utf8)
            } catch let error {
                print("Could not write camera matrix. \(error.localizedDescription)")
            }
        }
    }

    static private func createDirectory(id: inout UUID) -> URL {
        let directoryId = hashUUID(id: id)
        let url = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        var directory = URL(fileURLWithPath: directoryId, relativeTo: url)
        if FileManager.default.fileExists(atPath: directory.absoluteString) {
            // Just in case the first 5 characters clash, try again.
            id = UUID()
            directory = DatasetEncoder.createDirectory(id: &id)
        }
        do {
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true, attributes: nil)
        } catch let error as NSError {
            print("Error creating directory. \(error), \(error.userInfo)")
        }
        return directory
    }

    static private func hashUUID(id: UUID) -> String {
        var hasher: SHA256 = SHA256()
        hasher.update(data: id.uuidString.data(using: .ascii)!)
        let digest = hasher.finalize()
        var string = ""
        digest.makeIterator().prefix(5).forEach { (byte: UInt8) in
            string += String(format: "%02x", byte)
        }
        print("Hash: \(string)")
        return string
    }
}
