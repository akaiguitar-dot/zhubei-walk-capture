import SwiftUI
import MapKit
import CoreLocation

final class CaptureLocationModel: NSObject, ObservableObject, CLLocationManagerDelegate {
    @Published private(set) var location: CLLocation?
    @Published private(set) var heading: CLHeading?
    @Published private(set) var authorization: CLAuthorizationStatus = .notDetermined
    @Published private(set) var errorMessage: String?

    private let manager = CLLocationManager()

    override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.distanceFilter = 0.5
        manager.headingFilter = 2
    }

    func start() {
        authorization = manager.authorizationStatus
        if authorization == .notDetermined { manager.requestWhenInUseAuthorization() }
        manager.startUpdatingLocation()
        if CLLocationManager.headingAvailable() { manager.startUpdatingHeading() }
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        authorization = manager.authorizationStatus
        if authorization == .authorizedAlways || authorization == .authorizedWhenInUse {
            manager.startUpdatingLocation()
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let newest = locations.last, newest.horizontalAccuracy >= 0 else { return }
        location = newest
    }

    func locationManager(_ manager: CLLocationManager, didUpdateHeading newHeading: CLHeading) {
        guard newHeading.headingAccuracy >= 0 else { return }
        heading = newHeading
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        errorMessage = error.localizedDescription
    }
}

final class CaptureMissionMapModel: ObservableObject {
    @Published private(set) var pack: VerifiedCapturePack?
    @Published private(set) var packError: String?
    @Published var selectedGeometryRevisionID: String?
    @Published var mapCenter: CLLocationCoordinate2D?
    @Published var projection: CaptureProjection?
    @Published var buildingSide: WalkBuildingSide?
    @Published var notice: String?
    @Published var locateGeneration = 0

    let location = CaptureLocationModel()

    init() {
        loadPack()
    }

    func loadPack() {
        guard let directory = CapturePackVerifier.defaultPackDirectory() else {
            packError = "尚未安裝已驗證的離線人行道圖資"
            return
        }
        do {
            pack = try CapturePackVerifier.load(directory: directory)
            packError = nil
        } catch {
            pack = nil
            packError = error.localizedDescription
        }
    }

    func locateMe() {
        location.start()
        locateGeneration += 1
    }

    func select(_ revisionID: String) {
        selectedGeometryRevisionID = revisionID
        projection = nil
        // Building side only has meaning from this feature's start direction.
        // Never carry a previous segment's answer into a newly selected side.
        buildingSide = nil
        notice = nil
    }

    func confirmCrosshair() -> Bool {
        guard let pack, let center = mapCenter else {
            notice = "請先等待地圖完成定位"
            return false
        }
        guard let selectedGeometryRevisionID else {
            notice = "請先點選你所在的這一側人行道"
            return false
        }
        let result = CaptureAxisProjector.project(
            center,
            accuracyMeters: max(location.location?.horizontalAccuracy ?? 5, 1),
            features: pack.features,
            selectedGeometryRevisionID: selectedGeometryRevisionID
        )
        projection = result
        guard result.status == .confirmed || result.status == .clampedEndpoint else {
            notice = result.status == .ambiguousCandidates
                ? "兩側太接近，請放大地圖後用準星確認"
                : "準星不在這段人行道內，請移動地圖重新確認"
            return false
        }
        let length = pack.features.first(where: { $0.geometryRevisionID == selectedGeometryRevisionID })
            .map { Double($0.axisLengthMm) / 1000 } ?? 0
        guard let chainage = result.chainageMeters,
              min(chainage, abs(length - chainage)) <= 1.25 else {
            projection = nil
            notice = "起點必須在路段端點附近；請把準星移到其中一端"
            return false
        }
        notice = String(format: "已確認起點｜距路段中心線 %.1f 公尺", result.snapDistanceMeters ?? 0)
        return true
    }

    func makeMission() -> WalkMission? {
        guard let pack,
              let revision = selectedGeometryRevisionID,
              let feature = pack.features.first(where: { $0.geometryRevisionID == revision }),
              let projection,
              let segmentIndex = projection.segmentIndex,
              let fraction = projection.segmentFraction,
              let chainage = projection.chainageMeters,
              let normalized = projection.normalizedMeasure,
              let latitude = projection.snappedLatitude,
              let longitude = projection.snappedLongitude,
              let distance = projection.snapDistanceMeters,
              let original = mapCenter,
              let buildingSide else { return nil }

        let axisLength = Double(feature.axisLengthMm) / 1000
        let direction = chainage <= axisLength / 2 ? "axis_forward" : "axis_reverse"
        let endChainage = direction == "axis_forward" ? axisLength : 0

        let binding = WalkMission.MapBinding(
            datasetID: feature.datasetID,
            datasetRevisionID: feature.datasetRevisionID,
            featureID: feature.featureID,
            subsegmentID: feature.subsegmentID,
            geometryRevisionID: feature.geometryRevisionID,
            geometryHash: feature.geometryHash,
            axisStartNodeID: feature.axisStartNodeID,
            axisEndNodeID: feature.axisEndNodeID,
            axisLengthMm: feature.axisLengthMm,
            vertexChainageMm: feature.vertexChainageMm,
            selectedSegmentIndex: segmentIndex,
            selectedSegmentFraction: fraction,
            selectedChainageMeters: chainage,
            selectedNormalizedMeasure: normalized,
            originalLatitude: original.latitude,
            originalLongitude: original.longitude,
            horizontalAccuracyMeters: max(location.location?.horizontalAccuracy ?? 5, 1),
            captureDirection: direction,
            captureStartChainageMeters: chainage,
            captureEndChainageMeters: endChainage,
            snappedLatitude: latitude,
            snappedLongitude: longitude,
            snapDistanceMeters: distance,
            selectionMethod: "confirmed_crosshair",
            packStatus: feature.status,
            axisCoordinates: feature.axis.map { [$0.longitude, $0.latitude] },
            polygonRings: feature.polygonRings.map { ring in ring.map { [$0.longitude, $0.latitude] } }
        )
        return WalkMission(
            segmentID: feature.subsegmentID,
            targetLengthMeters: abs(endChainage - chainage),
            requiresReturnTrip: true,
            captureMode: .mappedSegment,
            captureProfile: .quickRoute,
            buildingSide: buildingSide,
            capturePolicy: .photoFirstV1,
            mapBinding: binding
        )
    }
}

struct CaptureMissionMapView: UIViewRepresentable {
    let features: [CaptureAxisFeature]
    let selectedGeometryRevisionID: String?
    let location: CLLocation?
    let heading: CLHeading?
    let locateGeneration: Int
    let onCenterChanged: (CLLocationCoordinate2D) -> Void
    let onSelect: (String) -> Void

    func makeCoordinator() -> Coordinator { Coordinator(parent: self) }

    func makeUIView(context: Context) -> MKMapView {
        let map = MKMapView()
        map.delegate = context.coordinator
        map.showsUserLocation = true
        map.showsCompass = true
        map.pointOfInterestFilter = .excludingAll
        map.isRotateEnabled = true
        map.register(MKMarkerAnnotationView.self, forAnnotationViewWithReuseIdentifier: "capture")
        context.coordinator.install(features, on: map)
        if let first = features.first?.axis.first {
            map.setRegion(MKCoordinateRegion(center: first, latitudinalMeters: 80, longitudinalMeters: 80), animated: false)
        }
        let tap = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.tap(_:)))
        map.addGestureRecognizer(tap)
        return map
    }

    func updateUIView(_ map: MKMapView, context: Context) {
        context.coordinator.parent = self
        context.coordinator.updateSelection(on: map)
        context.coordinator.updateAccuracy(location, on: map)
        if context.coordinator.lastLocateGeneration != locateGeneration, let location {
            context.coordinator.lastLocateGeneration = locateGeneration
            let headingDegrees = heading.map { $0.trueHeading >= 0 ? $0.trueHeading : $0.magneticHeading } ?? 0
            map.setCamera(MKMapCamera(lookingAtCenter: location.coordinate, fromDistance: 45, pitch: 0, heading: headingDegrees), animated: true)
        }
    }

    final class Coordinator: NSObject, MKMapViewDelegate {
        var parent: CaptureMissionMapView
        var overlaysByRevision: [String: [MKOverlay]] = [:]
        var lastLocateGeneration = -1
        private var accuracyCircle: MKCircle?

        init(parent: CaptureMissionMapView) { self.parent = parent }

        func install(_ features: [CaptureAxisFeature], on map: MKMapView) {
            for feature in features {
                var overlays: [MKOverlay] = []
                if let outer = feature.polygonRings.first {
                    let polygon = MKPolygon(coordinates: outer, count: outer.count)
                    polygon.title = feature.geometryRevisionID
                    overlays.append(polygon)
                }
                let line = MKPolyline(coordinates: feature.axis, count: feature.axis.count)
                line.title = feature.geometryRevisionID
                overlays.append(line)
                overlaysByRevision[feature.geometryRevisionID] = overlays
                map.addOverlays(overlays)
            }
        }

        func updateSelection(on map: MKMapView) {
            for overlay in map.overlays where !(overlay is MKCircle) {
                map.renderer(for: overlay)?.setNeedsDisplay()
            }
        }

        func updateAccuracy(_ location: CLLocation?, on map: MKMapView) {
            if let old = accuracyCircle { map.removeOverlay(old) }
            guard let location, location.horizontalAccuracy >= 0 else { return }
            let circle = MKCircle(center: location.coordinate, radius: location.horizontalAccuracy)
            accuracyCircle = circle
            map.addOverlay(circle, level: .aboveRoads)
        }

        @objc func tap(_ gesture: UITapGestureRecognizer) {
            guard let map = gesture.view as? MKMapView else { return }
            let point = gesture.location(in: map)
            let coordinate = map.convert(point, toCoordinateFrom: map)
            let selectable = parent.features.filter(\.captureEligible)

            // A person should be able to touch any part of the visible orange
            // sidewalk band.  The old behaviour only accepted a narrow centre
            // line, which made a clearly visible sidewalk appear untappable.
            if let feature = selectable.first(where: { contains(coordinate, in: $0.polygonRings.first) }) {
                parent.onSelect(feature.geometryRevisionID)
                return
            }
            // Narrow / simplified polygons can miss a tap by a few screen
            // points, so retain a generous visual fallback around the axis.
            if let feature = selectable.min(by: {
                distanceToAxis($0.axis, from: point, on: map) < distanceToAxis($1.axis, from: point, on: map)
            }), distanceToAxis(feature.axis, from: point, on: map) <= 28 {
                parent.onSelect(feature.geometryRevisionID)
            }
        }

        private func contains(_ coordinate: CLLocationCoordinate2D, in ring: [CLLocationCoordinate2D]?) -> Bool {
            guard let ring, ring.count >= 3 else { return false }
            let point = MKMapPoint(coordinate)
            var inside = false
            for index in ring.indices {
                let a = MKMapPoint(ring[index])
                let b = MKMapPoint(ring[(index + 1) % ring.count])
                let crosses = (a.y > point.y) != (b.y > point.y)
                guard crosses else { continue }
                let xAtY = (b.x - a.x) * (point.y - a.y) / (b.y - a.y) + a.x
                if point.x < xAtY { inside.toggle() }
            }
            return inside
        }

        private func distanceToAxis(
            _ coordinates: [CLLocationCoordinate2D],
            from point: CGPoint,
            on map: MKMapView
        ) -> CGFloat {
            guard coordinates.count >= 2 else { return .greatestFiniteMagnitude }
            return zip(coordinates, coordinates.dropFirst()).map { start, end in
                distance(
                    point,
                    toSegmentFrom: map.convert(start, toPointTo: map),
                    to: map.convert(end, toPointTo: map)
                )
            }.min() ?? .greatestFiniteMagnitude
        }

        private func distance(
            _ point: CGPoint,
            toSegmentFrom start: CGPoint,
            to end: CGPoint
        ) -> CGFloat {
            let dx = end.x - start.x
            let dy = end.y - start.y
            let squaredLength = dx * dx + dy * dy
            guard squaredLength > 0 else {
                return hypot(point.x - start.x, point.y - start.y)
            }
            let t = max(0, min(1, ((point.x - start.x) * dx + (point.y - start.y) * dy) / squaredLength))
            return hypot(point.x - (start.x + t * dx), point.y - (start.y + t * dy))
        }

        func mapView(_ mapView: MKMapView, regionDidChangeAnimated animated: Bool) {
            parent.onCenterChanged(mapView.centerCoordinate)
        }

        func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
            if let circle = overlay as? MKCircle {
                let renderer = MKCircleRenderer(circle: circle)
                renderer.fillColor = UIColor.systemBlue.withAlphaComponent(0.10)
                renderer.strokeColor = UIColor.systemBlue.withAlphaComponent(0.45)
                renderer.lineWidth = 1
                return renderer
            }
            let selected = parent.selectedGeometryRevisionID.flatMap { revision in
                overlaysByRevision[revision]?.contains { ($0 as AnyObject) === (overlay as AnyObject) }
            } ?? false
            if let polygon = overlay as? MKPolygon {
                let renderer = MKPolygonRenderer(polygon: polygon)
                // Before selection there is one visual language: a single
                // orange sidewalk band. The invisible centre axis remains for
                // hit testing, but cannot look like another sidewalk.
                renderer.fillColor = (selected ? UIColor.systemGreen : UIColor.systemOrange).withAlphaComponent(selected ? 0.32 : 0.82)
                renderer.strokeColor = selected ? UIColor.systemGreen : .clear
                renderer.lineWidth = selected ? 3 : 0
                return renderer
            }
            if let line = overlay as? MKPolyline {
                let renderer = MKPolylineRenderer(polyline: line)
                // Show the centre line only after selection, where it explains
                // the capture direction instead of competing with the map.
                renderer.strokeColor = selected ? UIColor.systemGreen : .clear
                renderer.lineWidth = selected ? 7 : 0
                renderer.lineCap = .round
                return renderer
            }
            return MKOverlayRenderer(overlay: overlay)
        }
    }
}

struct CaptureMissionMapHome: View {
    @StateObject private var model = CaptureMissionMapModel()
    let pendingPrivateTransfers: Int
    let recentCount: Int
    let onStartMission: (WalkMission) -> Void
    let onOpenHistory: () -> Void

    var body: some View {
        NavigationView {
            VStack(spacing: 12) {
                header
                mapPanel
                nextAction
                statusRow
                HStack {
                    Spacer()
                    Button("最近採集 \(recentCount)", action: onOpenHistory)
                }
                .font(.footnote)
            }
            .padding(16)
            .navigationBarHidden(true)
            .onAppear { model.locateMe() }
        }
    }

    private var header: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 4) {
                Text("竹北人行道採集").font(.title.bold())
                Text("先確認你所在的這一側，再照畫面指示往返拍攝")
                    .font(.subheadline).foregroundColor(.secondary)
            }
            Spacer()
        }
    }

    private var mapPanel: some View {
        ZStack {
            if let pack = model.pack {
                CaptureMissionMapView(
                    features: pack.features,
                    selectedGeometryRevisionID: model.selectedGeometryRevisionID,
                    location: model.location.location,
                    heading: model.location.heading,
                    locateGeneration: model.locateGeneration,
                    onCenterChanged: { model.mapCenter = $0 },
                    onSelect: model.select
                )
            } else {
                Color(.secondarySystemBackground)
                VStack(spacing: 8) {
                    Image(systemName: "exclamationmark.triangle.fill").foregroundColor(.orange)
                    Text(model.packError ?? "正在核對離線圖資").multilineTextAlignment(.center)
                }.padding()
            }

            Image(systemName: "plus")
                .font(.system(size: 30, weight: .medium))
                .foregroundColor(.primary)
                .shadow(color: .white, radius: 2)

            VStack {
                HStack {
                    locationBadge
                    Spacer()
                    Button(action: model.locateMe) {
                        Image(systemName: "location.fill").padding(12).background(.ultraThinMaterial).clipShape(Circle())
                    }
                    .accessibilityLabel("定位到我")
                    .accessibilityHint("將地圖移到目前位置，並顯示定位精度與朝向")
                }
                Spacer()
            }.padding(12)
        }
        .frame(minHeight: 330)
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .overlay(alignment: .bottomLeading) {
            if model.pack?.manifest.status == "demo_pending_field_confirmation" {
                Text("DEMO 圖資｜待現場確認，不是官方或法規量測")
                    .font(.caption.bold()).padding(8)
                    .background(Color.orange.opacity(0.94)).foregroundColor(.black)
                    .clipShape(RoundedRectangle(cornerRadius: 8)).padding(10)
            }
        }
    }

    private var locationBadge: some View {
        let accuracy = model.location.location?.horizontalAccuracy
        let headingText: String
        if let heading = model.location.heading {
            let degrees = heading.trueHeading >= 0
                ? heading.trueHeading
                : heading.magneticHeading
            headingText = "｜面向 \(cardinalDirection(degrees)) \(Int(degrees.rounded()))°"
        } else {
            headingText = "｜面向等待中"
        }
        return Label(
            (accuracy.map { String(format: "定位 ±%.0f m", $0) } ?? "等待定位") + headingText,
            systemImage: "location.circle"
        )
        .font(.caption.bold()).padding(8).background(.ultraThinMaterial).clipShape(Capsule())
        .accessibilityLabel(
            (accuracy.map { String(format: "定位精度正負 %.0f 公尺", $0) } ?? "等待定位") + headingText
        )
    }

    private func cardinalDirection(_ degrees: CLLocationDirection) -> String {
        switch Int((degrees + 22.5).truncatingRemainder(dividingBy: 360) / 45) {
        case 0: return "北"
        case 1: return "東北"
        case 2: return "東"
        case 3: return "東南"
        case 4: return "南"
        case 5: return "西南"
        case 6: return "西"
        default: return "西北"
        }
    }

    private var nextAction: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(stepTitle)
                .font(.headline)
            if model.projection == nil && model.selectedGeometryRevisionID == nil {
                Text("請直接點地圖上的橘色帶；它就是目前可採集的人行道。")
                    .font(.footnote)
                    .foregroundColor(.orange)
            } else if model.projection == nil {
                Text("已選到人行道。拖曳地圖，讓十字準星對準其中一端。")
                    .font(.footnote)
                    .foregroundColor(.green)
            }
            if let notice = model.notice {
                Text(notice).font(.footnote).foregroundColor(.secondary)
            }
            if model.projection != nil {
                Text("站在起點、面向要拍攝的路段，建築物在哪一邊？")
                    .font(.subheadline.bold())
                HStack(spacing: 10) {
                    sideButton(.left, title: "左手邊")
                    sideButton(.right, title: "右手邊")
                }
            }
            Button(action: primaryAction) {
                Label(primaryLabel, systemImage: model.projection == nil ? "mappin.and.ellipse" : "camera.viewfinder")
                    .font(.headline).frame(maxWidth: .infinity).padding(.vertical, 14)
            }
            .buttonStyle(.borderedProminent).tint(.green)
            .disabled(
                model.pack == nil
                    || model.selectedGeometryRevisionID == nil
                    || (model.projection != nil && model.buildingSide == nil)
            )
        }
    }

    private var stepTitle: String {
        if model.projection != nil { return "3. 起點已確認" }
        if model.selectedGeometryRevisionID != nil { return "2. 把準星移到人行道端點" }
        return "1. 點選橘色人行道帶"
    }

    private var primaryLabel: String {
        if model.projection != nil { return "開始順拍去程" }
        if model.selectedGeometryRevisionID != nil { return "確認這一側與起點" }
        return "先在地圖點選橘色人行道帶"
    }

    private var statusRow: some View {
        Label(
            pendingPrivateTransfers > 0 ? "\(pendingPrivateTransfers) 筆資料正在安全上傳" : "原始資料只進私密佇列，完成後自動上傳",
            systemImage: pendingPrivateTransfers > 0 ? "icloud.and.arrow.up.fill" : "lock.icloud.fill"
        )
        .font(.footnote).foregroundColor(pendingPrivateTransfers > 0 ? .blue : .secondary)
    }

    private func primaryAction() {
        if model.projection == nil {
            _ = model.confirmCrosshair()
        } else if let mission = model.makeMission() {
            onStartMission(mission)
        }
    }

    private func sideButton(_ side: WalkBuildingSide, title: String) -> some View {
        Button(title) { model.buildingSide = side }
            .buttonStyle(.borderedProminent)
            .tint(model.buildingSide == side ? .blue : .gray)
            .frame(maxWidth: .infinity)
            .accessibilityLabel("建築在\(title)")
            .accessibilityHint("依你面向採集方向時，選擇建築所在的一側")
    }
}

struct SessionHistorySheet: View {
    let sessions: [Recording]

    var body: some View {
        NavigationView {
            List(sessions, id: \.objectID) { recording in
                VStack(alignment: .leading, spacing: 4) {
                    Text(recording.name ?? "未命名採集").font(.headline)
                    Text(Self.dateFormatter.string(from: recording.createdAt ?? Date()))
                        .font(.caption).foregroundColor(.secondary)
                }
            }
            .navigationTitle("最近採集")
        }
    }

    private static let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter
    }()
}
