//
//  DatasetEncoder.swift
//  StrayScanner
//
//  Created by Kenneth Blomqvist on 1/2/21.
//  Copyright © 2021 Stray Robots. All rights reserved.
//

import Foundation
import ARKit
import CryptoKit
import CoreLocation
import CoreImage
import UIKit

private struct LocationSample: Codable {
    let timestamp: Double
    let latitude: Double
    let longitude: Double
    let altitude: Double
    let horizontalAccuracy: Double
    let verticalAccuracy: Double
    let speed: Double
    let course: Double

    init(location: CLLocation) {
        timestamp = location.timestamp.timeIntervalSince1970
        latitude = location.coordinate.latitude
        longitude = location.coordinate.longitude
        altitude = location.altitude
        horizontalAccuracy = location.horizontalAccuracy
        verticalAccuracy = location.verticalAccuracy
        speed = location.speed
        course = location.course
    }
}

struct WalkCaptureOrigin: Codable {
    let latitude: Double
    let longitude: Double
    let altitude: Double
    let horizontalAccuracyMeters: Double
    let verticalAccuracyMeters: Double
    let headingDegrees: Double
    let headingAccuracyDegrees: Double
    let lockedAt: Date
}

private struct WalkScanManifest: Codable {
    let schemaVersion: Int
    let source: String
    let captureMethod: String
    let guidanceMode: String
    let guidanceSpacingMeters: Double
    let guidancePlanningWindowMeters: Double
    let origin: WalkCaptureOrigin
    let captureMode: String
    let captureProfile: String
    let buildingSide: String
    let segmentID: String
    let targetLengthMeters: Double
    let expectedTravelMeters: Double
    let measuredTravelMeters: Double
    let requiresReturnTrip: Bool
    let stationSpacingMeters: Double
    let capturedStationCount: Int
    let systemBootEpochSeconds: Double
    let odometryTimestampTimebase: String
    let captureStartedAt: Date
    let captureCompletedAt: Date
    let deviceModel: String
    let operatingSystem: String
    let contents: [String]
}

/// Private sidecar.  It intentionally does not change the WalkScan v4 raw
/// manifest: a future map picker can fill feature/subsegment/measure fields
/// without making raw photos or precise locations public.
private struct WalkMissionContext: Codable {
    struct Leg: Codable {
        let legIndex: Int
        let role: String
        let startedAtRouteDistance: Double
        let endpointConfirmed: Bool
        let startAnchorRawStationID: String?
        let endAnchorRawStationID: String?
    }

    /// Reference only: all image/depth/pose/intrinsics/tracking metadata stays
    /// in the existing WalkScan v4 station/view files.
    struct EventReference: Codable {
        let eventID: UUID
        let eventClass: String
        let trigger: String
        let requestedView: String?
        let legIndex: Int
        let rawStationID: String
        let rawViewFace: String
        let observationGroupID: String?
    }

    struct MapAnchor: Codable {
        let chainageMeters: Double
        let normalizedMeasure: Double
        let segmentIndex: Int
        let segmentT: Double
        let rawStationID: String?
    }

    struct MapReference: Codable {
        let datasetID: String
        let datasetRevisionID: String
        let featureID: String
        let subsegmentID: String
        let geometryRevisionID: String
        let geometryHash: String
        let axisStartNodeID: String
        let axisEndNodeID: String
        let axisLengthMm: Int
        let vertexChainageMm: [Int]
        let selectedSegmentIndex: Int
        let selectedSegmentFraction: Double
        let selectedChainageMeters: Double
        let selectedNormalizedMeasure: Double
        let originalLatitude: Double
        let originalLongitude: Double
        let horizontalAccuracyMeters: Double
        let captureDirection: String
        let captureStartChainageMeters: Double
        let captureEndChainageMeters: Double
        let snappedLatitude: Double
        let snappedLongitude: Double
        let snapDistanceMeters: Double
        let selectionMethod: String
        let packStatus: String
        let startAnchor: MapAnchor
        let endAnchor: MapAnchor
    }

    struct ImageQualityObservation: Codable {
        let analyzerVersion: String
        let rawStationID: String
        let rawViewFace: String
        let statistics: CaptureImageStatistics
        let issueCodes: [String]
    }

    struct ImageQuality: Codable {
        let configuration: CaptureLumaAnalyzerConfiguration
        let observationCount: Int
        let affectedStationCount: Int
        let issueCounts: [String: Int]
        let observations: [ImageQualityObservation]
    }

    let schema: String
    let missionID: UUID
    let segmentID: String
    let capturePolicyID: String
    let geometryAuthority: String
    let mapReferenceStatus: String
    let mapReference: MapReference?
    let outboundEndpointConfirmedAtRouteDistance: Double?
    let legs: [Leg]
    let eventReferences: [EventReference]
    let imageQuality: ImageQuality
}

enum WalkStationFace: String, Codable, CaseIterable, Equatable {
    case forward
    case rear
    case buildingSide = "building_side"
    case roadSide = "road_side"
    case ground
    case canopy

    var prompt: String {
        switch self {
        case .forward:
            return "看向前方"
        case .rear:
            return "轉身看向後方"
        case .buildingSide:
            return "稍微轉向建築側"
        case .roadSide:
            return "稍微轉向道路側"
        case .ground:
            return "鏡頭稍微朝下，看鋪面"
        case .canopy:
            return "鏡頭稍微朝上，看遮陰"
        }
    }
}

/// The only bridge between WalkScan v4 raw view names and the semantic names
/// used by processed manifests/QC feedback. Unknown values intentionally do
/// not guess a camera direction and must be reviewed by a person.
enum WalkScanViewAdapter {
    static let version = "zhubei.capture-view-adapter.v1"

    /// Event/QC has a deliberately smaller vocabulary than WalkScan v4.
    /// Forward/rear/canopy remain valid raw evidence, but must never be
    /// guessed into a recapture direction.
    static func eventSemanticView(for raw: WalkStationFace) -> String? {
        switch raw {
        case .ground: return "floor"
        case .buildingSide: return "building_side"
        case .roadSide: return "road_side"
        case .forward, .rear, .canopy: return nil
        }
    }

    static func rawFace(forEventSemantic semantic: String) -> WalkStationFace? {
        switch semantic {
        case "floor": return .ground
        case "building_side": return .buildingSide
        case "road_side": return .roadSide
        default: return nil
        }
    }
}

struct WalkCaptureUpdate {
    let stationSequence: Int
    let face: WalkStationFace
    let isStationComplete: Bool
    let nextPrompt: String?
    let capturedFaceCount: Int
    let requiredFaceCount: Int
}

struct WalkCaptureHealth {
    let expectedStationCount: Int
    let completedStationCount: Int
    let capturedViewCount: Int
    let hasIncompleteStation: Bool

    var isSufficient: Bool {
        completedStationCount >= expectedStationCount && !hasIncompleteStation
    }
}

struct WalkCaptureEvidenceSnapshot {
    let startAnchorStationID: String?
    let outboundEndpointStationID: String?
    let outboundEndpointGroundStationID: String?
    let returnStartAnchorStationID: String?
    let returnEndpointStationID: String?
    let outboundStationCount: Int
    let returnStationCount: Int
    let outboundCoveredMeters: Double
    let returnCoveredMeters: Double
    let imageQualityAnalyzerVersion: String
    let imageQualityObservationCount: Int
    let imageQualityIssueCounts: [String: Int]
    let imageQualityAffectedStationIDs: [String]

    var hasRequiredAnchors: Bool {
        startAnchorStationID != nil
            && outboundEndpointStationID != nil
            && returnEndpointStationID != nil
    }
}

enum WalkCaptureEvidenceRules {
    static let endpointToleranceMeters = 1.25

    static func isStartAnchor(legDistanceMeters: Double) -> Bool {
        legDistanceMeters >= 0 && legDistanceMeters <= endpointToleranceMeters
    }
}

private struct WalkStationView: Codable {
    let face: WalkStationFace
    let frame: String
    let frameTimestamp: Double
    let capturedAtEpochSeconds: Double
    let rgbImage: String
    let depthImage: String
    let confidenceImage: String
    let trackingQuality: String
    let imageWidthPixels: Int
    let imageHeightPixels: Int
    let cameraPositionMeters: [Float]
    let cameraQuaternion: [Float]
    let cameraEulerRadians: [Float]
    let cameraIntrinsics: [Float]
}

private struct WalkStation: Codable {
    let stationID: String
    let sequence: Int
    let direction: String
    let legIndex: Int
    let legDistanceMeters: Double
    let nominalRouteDistanceMeters: Double
    let measuredRouteDistanceMeters: Double
    let frame: String
    let frameTimestamp: Double
    let capturedAtEpochSeconds: Double
    let rgbImage: String
    let depthImage: String
    let confidenceImage: String
    let trackingQuality: String
    let imageWidthPixels: Int
    let imageHeightPixels: Int
    let cameraPositionMeters: [Float]
    let cameraQuaternion: [Float]
    let cameraEulerRadians: [Float]
    let cameraIntrinsics: [Float]
    let requiredFaces: [WalkStationFace]
    let capturedFaces: [WalkStationFace]
    let missingFaces: [WalkStationFace]
    let captureComplete: Bool
    let views: [WalkStationView]
}

private struct WalkStationIndex: Codable {
    let schemaVersion: Int
    let spacingMeters: Double
    let coordinateSystem: String
    let imageOrientation: String
    let depthImageOrientation: String
    let stations: [WalkStation]
}

private struct StationReservation {
    let sequence: Int
    let nominalRouteDistanceMeters: Double
    let measuredRouteDistanceMeters: Double
    let direction: String
    let legIndex: Int
    let legDistanceMeters: Double
}

private struct DetailedStationState {
    let reservation: StationReservation
    let referenceYaw: Float
    var nextFaceIndex: Int
    var lastCaptureTimestamp: TimeInterval
}

private struct StationAccumulator {
    let reservation: StationReservation
    var views: [WalkStationView]
}

private struct PendingEventReference {
    let eventID: UUID
    let eventClass: String
    let trigger: String
    let requestedView: String?
    let legIndex: Int
    let sequence: Int
    let rawViewFace: String
    let observationGroupID: String?
}

private final class RouteTraceEncoder {
    let path: URL
    private let fileHandle: FileHandle
    private var lastTimestamp: TimeInterval = -1

    init(url: URL) {
        path = url
        do {
            try "".write(to: path, atomically: true, encoding: .utf8)
            fileHandle = try FileHandle(forWritingTo: path)
            fileHandle.write(
                "timestamp,x,y,z,qx,qy,qz,qw,tracking_quality\n"
                    .data(using: .utf8)!
            )
        } catch {
            preconditionFailure("Can't create route trace: \(error.localizedDescription)")
        }
    }

    func add(frame: ARFrame, quality: String) {
        guard frame.timestamp - lastTimestamp >= 0.20 else { return }
        lastTimestamp = frame.timestamp
        let transform = frame.camera.transform
        let position = transform.columns.3
        let quaternion = simd_quatf(transform).vector
        let line = [
            "\(frame.timestamp)",
            "\(position.x)",
            "\(position.y)",
            "\(position.z)",
            "\(quaternion.x)",
            "\(quaternion.y)",
            "\(quaternion.z)",
            "\(quaternion.w)",
            quality
        ].joined(separator: ",") + "\n"
        fileHandle.write(line.data(using: .utf8)!)
    }

    func done() {
        try? fileHandle.close()
    }
}

class DatasetEncoder {
    enum Status {
        case allGood
        case encodingError
        case directoryCreationError
    }
    private let depthEncoder: DepthEncoder
    private let confidenceEncoder: ConfidenceEncoder
    private let datasetDirectory: URL
    private let odometryEncoder: OdometryEncoder
    private let routeTraceEncoder: RouteTraceEncoder
    private let distortionEncoder: DistortionEncoder
    private let mission: WalkMission
    private let origin: WalkCaptureOrigin
    private let stationDirectory: URL
    private let stationImageContext = CIContext(options: [.cacheIntermediates: false])
    private let stationSpacingMeters: Double
    private let systemBootEpochSeconds =
        Date().timeIntervalSince1970 - ProcessInfo.processInfo.systemUptime
    private let captureStartedAt = Date()
    private let locationLock = NSLock()
    private var locationSamples: [LocationSample] = []
    private var lastCameraIntrinsics: simd_float3x3?
    private var dispatchGroup = DispatchGroup()
    private var savedFrames: Int = 0
    private var nextStationDistanceMeters: Double = 0.0
    private var lastReservedDistanceMeters: Double?
    private var lastCapturedReservation: StationReservation?
    private var lastCapturedFace: WalkStationFace?
    private var reservedStationCount: Int = 0
    private var completedStationCount: Int = 0
    private var currentLegIndex: Int = 0
    private var returnTripStartedAtMeters: Double?
    private var outboundEndpointConfirmedAtMeters: Double?
    private var outboundEndpointEvidenceSequence: Int?
    private var outboundEndpointGroundEvidenceSequence: Int?
    private var returnStartAnchorEvidenceSequence: Int?
    private var returnEndpointEvidenceSequence: Int?
    private var stationAccumulators: [Int: StationAccumulator] = [:]
    private var pendingEventReferences: [PendingEventReference] = []
    private var lastForwardCaptureYaw: Float?
    private var lastTurnEventDistanceMeters: Double?
    private var coverageOnlyStationSequences: Set<Int> = []
    private var imageQualityObservations: [WalkMissionContext.ImageQualityObservation] = []
    private var activeDetailedStation: DetailedStationState?
    private let encodingSemaphore = DispatchSemaphore(value: 3) // Limit queued frames to avoid ARFrame retention
    public let id: UUID
    // Kept under the historical Core Data property name. It now points to the
    // manifest and acts only as the stable anchor for the dataset directory.
    public let rgbFilePath: URL
    public let depthFilePath: URL // Relative to app document directory.
    public let cameraMatrixPath: URL
    public let odometryPath: URL
    public var status = Status.allGood
    private let queue: DispatchQueue
    
    init(mission: WalkMission, origin: WalkCaptureOrigin) {
        self.mission = mission
        self.origin = origin
        self.stationSpacingMeters = mission.capturePolicy.nominalSpacingMeters
        self.queue = DispatchQueue(label: "encoderQueue")

        var theId: UUID = UUID()
        datasetDirectory = DatasetEncoder.createDirectory(id: &theId)
        self.id = theId
        self.rgbFilePath = datasetDirectory.appendingPathComponent("mission.json")
        self.depthFilePath = datasetDirectory.appendingPathComponent("depth", isDirectory: true)
        self.depthEncoder = DepthEncoder(outDirectory: self.depthFilePath)
        let confidenceFilePath = datasetDirectory.appendingPathComponent("confidence", isDirectory: true)
        self.confidenceEncoder = ConfidenceEncoder(outDirectory: confidenceFilePath)
        self.cameraMatrixPath = datasetDirectory.appendingPathComponent("camera_matrix.csv", isDirectory: false)
        self.odometryPath = datasetDirectory.appendingPathComponent("odometry.csv", isDirectory: false)
        self.odometryEncoder = OdometryEncoder(url: self.odometryPath)
        self.routeTraceEncoder = RouteTraceEncoder(
            url: datasetDirectory.appendingPathComponent("route.csv")
        )
        self.distortionEncoder = DistortionEncoder(datasetDirectory: datasetDirectory)
        self.stationDirectory = datasetDirectory.appendingPathComponent("stations", isDirectory: true)
        do {
            try FileManager.default.createDirectory(
                at: stationDirectory,
                withIntermediateDirectories: true,
                attributes: nil
            )
        } catch {
            print("Could not create station directory. \(error.localizedDescription)")
        }
    }

    func addRouteFrame(_ frame: ARFrame) {
        routeTraceEncoder.add(
            frame: frame,
            quality: trackingQuality(frame.camera.trackingState)
        )
    }

    @discardableResult
    func markReturnTrip(frame: ARFrame?, at travelDistance: Double) -> WalkCaptureUpdate? {
        guard currentLegIndex == 0 else { return nil }
        currentLegIndex = 1
        returnTripStartedAtMeters = travelDistance
        nextStationDistanceMeters = travelDistance
        lastForwardCaptureYaw = nil
        lastTurnEventDistanceMeters = nil
        guard let frame,
              case .normal = frame.camera.trackingState,
              frame.sceneDepth != nil,
              isLevelForwardFrame(frame) else { return nil }
        let reservation = reserveStation(
            nominalDistance: travelDistance,
            measuredDistance: travelDistance
        )
        guard capture(frame: frame, reservation: reservation, face: .forward) else { return nil }
        returnStartAnchorEvidenceSequence = reservation.sequence
        nextStationDistanceMeters = travelDistance + stationSpacingMeters
        completedStationCount += 1
        pendingEventReferences.append(PendingEventReference(
            eventID: UUID(),
            eventClass: "coverage_trigger",
            trigger: "return_start_anchor",
            requestedView: nil,
            legIndex: 1,
            sequence: reservation.sequence,
            rawViewFace: WalkStationFace.forward.rawValue,
            observationGroupID: "\(id.uuidString):return_start"
        ))
        return WalkCaptureUpdate(
            stationSequence: reservation.sequence,
            face: .forward,
            isStationComplete: true,
            nextPrompt: nil,
            capturedFaceCount: 1,
            requiredFaceCount: 1
        )
    }

    /// Saves the endpoint evidence before the operator turns around.  This is
    /// a private capture-state event, not a claim that AR distance is a GIS
    /// chainage or a surveyed length.
    func confirmOutboundEndpoint(frame: ARFrame?, at travelDistance: Double) {
        guard currentLegIndex == 0 else { return }
        outboundEndpointConfirmedAtMeters = travelDistance
        let update = addFinal(frame: frame, travelDistance: travelDistance)
        if update?.isStationComplete == true {
            outboundEndpointEvidenceSequence = update?.stationSequence
            if let sequence = update?.stationSequence {
                pendingEventReferences.append(PendingEventReference(
                    eventID: UUID(),
                    eventClass: "coverage_trigger",
                    trigger: "endpoint_forward",
                    requestedView: nil,
                    legIndex: 0,
                    sequence: sequence,
                    rawViewFace: WalkStationFace.forward.rawValue,
                    observationGroupID: "\(id.uuidString):outbound_end"
                ))
            }
        }
    }

    /// The endpoint opening needs a floor/ramp view as well as the forward
    /// crossing view. It remains a normal raw v4 station; the sidecar only
    /// records why it was captured.
    @discardableResult
    func addOutboundEndpointGround(frame: ARFrame, at travelDistance: Double) -> WalkCaptureUpdate? {
        guard currentLegIndex == 0,
              outboundEndpointGroundEvidenceSequence == nil,
              let update = addManualEvent(
                frame: frame,
                requestedFace: .ground,
                travelDistance: travelDistance,
                trigger: "endpoint_ground"
              ) else { return nil }
        outboundEndpointGroundEvidenceSequence = update.stationSequence
        return update
    }

    func prepareReturnEndpointEvidence(
        frame: ARFrame?,
        at travelDistance: Double,
        completion: @escaping (WalkCaptureEvidenceSnapshot) -> Void
    ) {
        if currentLegIndex == 1, returnEndpointEvidenceSequence == nil {
            let update = addFinal(frame: frame, travelDistance: travelDistance)
            if update?.isStationComplete == true {
                returnEndpointEvidenceSequence = update?.stationSequence
                if let sequence = update?.stationSequence {
                    pendingEventReferences.append(PendingEventReference(
                        eventID: UUID(),
                        eventClass: "coverage_trigger",
                        trigger: "return_endpoint_forward",
                        requestedView: nil,
                        legIndex: 1,
                        sequence: sequence,
                        rawViewFace: WalkStationFace.forward.rawValue,
                        observationGroupID: "\(id.uuidString):return_end"
                    ))
                }
            }
        }
        dispatchGroup.notify(queue: .main) {
            completion(self.evidenceSnapshot())
        }
    }

    /// Event capture is intentionally manual in P0.  It writes one normal v4
    /// station/view, then the private sidecar stores only a reference to it.
    @discardableResult
    func addManualEvent(
        frame: ARFrame,
        requestedFace: WalkStationFace,
        travelDistance: Double,
        trigger: String = "manual"
    ) -> WalkCaptureUpdate? {
        guard case .normal = frame.camera.trackingState,
              frame.sceneDepth != nil,
              requestedFace == .ground || requestedFace == .buildingSide || requestedFace == .roadSide,
              let semanticView = WalkScanViewAdapter.eventSemanticView(for: requestedFace) else {
            return nil
        }
        let reservation = reserveStation(
            nominalDistance: travelDistance,
            measuredDistance: travelDistance
        )
        guard capture(frame: frame, reservation: reservation, face: requestedFace) else {
            return nil
        }
        pendingEventReferences.append(PendingEventReference(
            eventID: UUID(),
            eventClass: "semantic_view",
            trigger: trigger,
            requestedView: semanticView,
            legIndex: reservation.legIndex,
            sequence: reservation.sequence,
            rawViewFace: requestedFace.rawValue,
            observationGroupID: trigger == "endpoint_ground" ? "\(id.uuidString):outbound_end" : nil
        ))
        completedStationCount += 1
        return WalkCaptureUpdate(
            stationSequence: reservation.sequence,
            face: requestedFace,
            isStationComplete: true,
            nextPrompt: nil,
            capturedFaceCount: 1,
            requiredFaceCount: 1
        )
    }

    @discardableResult
    func add(frame: ARFrame, travelDistance: Double) -> WalkCaptureUpdate? {
        guard case .normal = frame.camera.trackingState,
              frame.sceneDepth != nil else {
            return nil
        }

        if mission.captureProfile == .quickRoute {
            if let turnEvent = addTurnEventIfNeeded(frame: frame, travelDistance: travelDistance) {
                return turnEvent
            }
            guard isLevelForwardFrame(frame),
                  travelDistance + 0.05 >= nextStationDistanceMeters else {
                return nil
            }
            let reservation = reserveStation(
                nominalDistance: nextStationDistanceMeters,
                measuredDistance: travelDistance
            )
            nextStationDistanceMeters = travelDistance + stationSpacingMeters
            guard capture(
                frame: frame,
                reservation: reservation,
                face: .forward
            ) else {
                return nil
            }
            completedStationCount += 1
            return WalkCaptureUpdate(
                stationSequence: reservation.sequence,
                face: .forward,
                isStationComplete: true,
                nextPrompt: nil,
                capturedFaceCount: 1,
                requiredFaceCount: 1
            )
        }

        if activeDetailedStation == nil {
            guard travelDistance + 0.05 >= nextStationDistanceMeters,
                  isLevelForwardFrame(frame) else {
                return nil
            }
            let reservation = reserveStation(
                nominalDistance: nextStationDistanceMeters,
                measuredDistance: travelDistance
            )
            activeDetailedStation = DetailedStationState(
                reservation: reservation,
                referenceYaw: cameraYaw(frame),
                nextFaceIndex: 0,
                lastCaptureTimestamp: -1
            )
        }

        guard var state = activeDetailedStation else { return nil }
        let requiredFaces = requiredFacesForMission()
        guard state.nextFaceIndex < requiredFaces.count else { return nil }
        let face = requiredFaces[state.nextFaceIndex]
        guard frame.timestamp - state.lastCaptureTimestamp >= 0.35,
              frameMatches(face: face, frame: frame, referenceYaw: state.referenceYaw),
              capture(frame: frame, reservation: state.reservation, face: face) else {
            return nil
        }

        state.nextFaceIndex += 1
        state.lastCaptureTimestamp = frame.timestamp
        let complete = state.nextFaceIndex >= requiredFaces.count
        let nextPrompt = complete ? nil : requiredFaces[state.nextFaceIndex].prompt
        if complete {
            completedStationCount += 1
            nextStationDistanceMeters = travelDistance + stationSpacingMeters
            activeDetailedStation = nil
        } else {
            activeDetailedStation = state
        }
        return WalkCaptureUpdate(
            stationSequence: state.reservation.sequence,
            face: face,
            isStationComplete: complete,
            nextPrompt: nextPrompt,
            capturedFaceCount: state.nextFaceIndex,
            requiredFaceCount: requiredFaces.count
        )
    }

    /// A natural corner is evidence, not another button for the walker. A
    /// sustained, level heading change after at least 1.25 m creates one extra
    /// forward station and resets ordinary 4 m spacing from that point.
    private func addTurnEventIfNeeded(
        frame: ARFrame,
        travelDistance: Double
    ) -> WalkCaptureUpdate? {
        guard isLevelForwardFrame(frame),
              let previousYaw = lastForwardCaptureYaw,
              travelDistance >= 1.25,
              travelDistance - (lastTurnEventDistanceMeters ?? -10) >= 1.25,
              abs(angleDifference(cameraYaw(frame), previousYaw)) >= 0.60 else {
            return nil
        }
        let reservation = reserveStation(
            nominalDistance: travelDistance,
            measuredDistance: travelDistance
        )
        guard capture(frame: frame, reservation: reservation, face: .forward) else {
            return nil
        }
        lastTurnEventDistanceMeters = travelDistance
        coverageOnlyStationSequences.insert(reservation.sequence)
        nextStationDistanceMeters = travelDistance + stationSpacingMeters
        completedStationCount += 1
        pendingEventReferences.append(PendingEventReference(
            eventID: UUID(),
            eventClass: "coverage_trigger",
            trigger: "automatic_turn",
            requestedView: nil,
            legIndex: reservation.legIndex,
            sequence: reservation.sequence,
            rawViewFace: WalkStationFace.forward.rawValue,
            observationGroupID: nil
        ))
        return WalkCaptureUpdate(
            stationSequence: reservation.sequence,
            face: .forward,
            isStationComplete: true,
            nextPrompt: nil,
            capturedFaceCount: 1,
            requiredFaceCount: 1
        )
    }

    /// Captures a route endpoint when the user stops between regular two-metre
    /// stations. If the last automatic photo is already close enough, it is
    /// reused as the endpoint instead of creating a duplicate.
    @discardableResult
    func addFinal(frame: ARFrame?, travelDistance: Double) -> WalkCaptureUpdate? {
        guard let frame else { return nil }
        guard case .normal = frame.camera.trackingState else { return nil }
        if let active = activeDetailedStation {
            activeDetailedStation = nil
            nextStationDistanceMeters = travelDistance + stationSpacingMeters
            return WalkCaptureUpdate(
                stationSequence: active.reservation.sequence,
                face: .forward,
                isStationComplete: false,
                nextPrompt: nil,
                capturedFaceCount: active.nextFaceIndex,
                requiredFaceCount: requiredFacesForMission().count
            )
        }
        if let lastDistance = lastReservedDistanceMeters,
            abs(travelDistance - lastDistance) < mission.capturePolicy.minimumEndpointSeparationMeters {
            if let last = lastCapturedReservation,
               last.legIndex == currentLegIndex,
               lastCapturedFace == .forward {
                return WalkCaptureUpdate(
                    stationSequence: last.sequence,
                    face: .forward,
                    isStationComplete: true,
                    nextPrompt: nil,
                    capturedFaceCount: 1,
                    requiredFaceCount: requiredFacesForMission().count
                )
            }
        }
        let reservation = reserveStation(
            nominalDistance: travelDistance,
            measuredDistance: travelDistance
        )
        guard capture(frame: frame, reservation: reservation, face: .forward) else {
            return nil
        }
        if mission.captureProfile == .quickRoute { completedStationCount += 1 }
        return WalkCaptureUpdate(
            stationSequence: reservation.sequence,
            face: .forward,
            isStationComplete: mission.captureProfile == .quickRoute,
            nextPrompt: nil,
            capturedFaceCount: 1,
            requiredFaceCount: requiredFacesForMission().count
        )
    }

    func captureHealth(travelDistance: Double) -> WalkCaptureHealth {
        let expected = max(
            1,
            Int(floor(max(0, travelDistance) / stationSpacingMeters)) + 1
        )
        return WalkCaptureHealth(
            expectedStationCount: expected,
            completedStationCount: completedStationCount,
            capturedViewCount: savedFrames,
            hasIncompleteStation: activeDetailedStation != nil
        )
    }

    private func evidenceSnapshot() -> WalkCaptureEvidenceSnapshot {
        let complete = stationAccumulators.values.filter { accumulator in
            accumulator.views.contains { $0.face == .forward }
        }
        // Automatic turn frames are retained as evidence but never inflate the
        // minimum ordinary-route coverage or station-count gate.
        let countable = complete.filter {
            !coverageOnlyStationSequences.contains($0.reservation.sequence)
        }
        let outbound = countable.filter { $0.reservation.legIndex == 0 }
        let returnLeg = countable.filter { $0.reservation.legIndex == 1 }
        let start = outbound.min(by: {
            $0.reservation.legDistanceMeters < $1.reservation.legDistanceMeters
        })
        let verifiedStart = start.flatMap { value in
            WalkCaptureEvidenceRules.isStartAnchor(
                legDistanceMeters: value.reservation.legDistanceMeters
            ) ? value : nil
        }
        let affected = imageQualityObservations.filter { !$0.issueCodes.isEmpty }
        var issueCounts: [String: Int] = [:]
        for observation in affected {
            for code in observation.issueCodes { issueCounts[code, default: 0] += 1 }
        }
        return WalkCaptureEvidenceSnapshot(
            startAnchorStationID: verifiedStart.map { rawStationID(for: $0.reservation.sequence, legIndex: 0) },
            outboundEndpointStationID: capturedRawStationID(
                sequence: outboundEndpointEvidenceSequence,
                legIndex: 0,
                face: .forward
            ),
            outboundEndpointGroundStationID: capturedRawStationID(
                sequence: outboundEndpointGroundEvidenceSequence,
                legIndex: 0,
                face: .ground
            ),
            returnStartAnchorStationID: capturedRawStationID(
                sequence: returnStartAnchorEvidenceSequence,
                legIndex: 1,
                face: .forward
            ),
            returnEndpointStationID: capturedRawStationID(
                sequence: returnEndpointEvidenceSequence,
                legIndex: 1,
                face: .forward
            ),
            outboundStationCount: outbound.count,
            returnStationCount: returnLeg.count,
            outboundCoveredMeters: outbound.map(\.reservation.legDistanceMeters).max() ?? 0,
            returnCoveredMeters: returnLeg.map(\.reservation.legDistanceMeters).max() ?? 0,
            imageQualityAnalyzerVersion: CaptureLumaAnalyzer.configuration.analyzerVersion,
            imageQualityObservationCount: imageQualityObservations.count,
            imageQualityIssueCounts: issueCounts,
            imageQualityAffectedStationIDs: Array(Set(affected.map(\.rawStationID))).sorted()
        )
    }

    private func capturedRawStationID(
        sequence: Int?,
        legIndex: Int,
        face: WalkStationFace
    ) -> String? {
        guard let sequence,
              let station = stationAccumulators[sequence],
              station.reservation.legIndex == legIndex,
              station.views.contains(where: { $0.face == face }) else { return nil }
        return rawStationID(for: sequence, legIndex: legIndex)
    }

    private func capture(
        frame: ARFrame,
        reservation: StationReservation,
        face: WalkStationFace
    ) -> Bool {
        guard encodingSemaphore.wait(timeout: .now()) == .success else { return false }
        if face == .forward { lastForwardCaptureYaw = cameraYaw(frame) }
        if let statistics = CaptureLumaAnalyzer.analyze(pixelBuffer: frame.capturedImage) {
            let issueCodes = CaptureQualityGate.imageIssues(statistics).map(\.code)
            imageQualityObservations.append(
                WalkMissionContext.ImageQualityObservation(
                    analyzerVersion: CaptureLumaAnalyzer.configuration.analyzerVersion,
                    rawStationID: rawStationID(for: reservation.sequence, legIndex: reservation.legIndex),
                    rawViewFace: face.rawValue,
                    statistics: statistics,
                    issueCodes: issueCodes
                )
            )
        }
        let frameNumber = savedFrames
        savedFrames += 1
        lastCapturedReservation = reservation
        lastCapturedFace = face
        dispatchGroup.enter()
        queue.async {
            defer {
                self.encodingSemaphore.signal()
                self.dispatchGroup.leave()
            }
            if let sceneDepth = frame.sceneDepth {
                self.depthEncoder.encodeFrame(
                    frame: sceneDepth.depthMap,
                    frameNumber: frameNumber
                )
                if let confidence = sceneDepth.confidenceMap {
                    self.confidenceEncoder.encodeFrame(
                        frame: confidence,
                        frameNumber: frameNumber
                    )
                } else {
                    print("warning: confidence map missing.")
                }
            } else {
                print("warning: scene depth missing.")
            }
            self.odometryEncoder.add(frame: frame, currentFrame: frameNumber)
            self.distortionEncoder.add(frame: frame, currentFrame: frameNumber)
            self.encodeStationView(
                frame: frame,
                frameNumber: frameNumber,
                reservation: reservation,
                face: face
            )
            self.lastCameraIntrinsics = frame.camera.intrinsics
        }
        return true
    }

    private func isLevelForwardFrame(_ frame: ARFrame) -> Bool {
        let forward = -SIMD3<Float>(
            frame.camera.transform.columns.2.x,
            frame.camera.transform.columns.2.y,
            frame.camera.transform.columns.2.z
        )
        return abs(forward.y) <= 0.32
    }

    private func requiredFacesForMission() -> [WalkStationFace] {
        mission.captureProfile == .sixFace
            ? [.forward, .buildingSide, .roadSide, .rear, .ground, .canopy]
            : [.forward]
    }

    private func cameraYaw(_ frame: ARFrame) -> Float {
        let forward = -SIMD3<Float>(
            frame.camera.transform.columns.2.x,
            frame.camera.transform.columns.2.y,
            frame.camera.transform.columns.2.z
        )
        return atan2(forward.x, -forward.z)
    }

    private func angleDifference(_ lhs: Float, _ rhs: Float) -> Float {
        var value = lhs - rhs
        while value > .pi { value -= 2 * .pi }
        while value < -.pi { value += 2 * .pi }
        return value
    }

    private func frameMatches(
        face: WalkStationFace,
        frame: ARFrame,
        referenceYaw: Float
    ) -> Bool {
        let transform = frame.camera.transform
        let forward = -SIMD3<Float>(
            transform.columns.2.x,
            transform.columns.2.y,
            transform.columns.2.z
        )
        let yawDelta = angleDifference(cameraYaw(frame), referenceYaw)
        let buildingTarget: Float = mission.buildingSide == .left ? -1.35 : 1.35

        switch face {
        case .forward:
            return abs(yawDelta) <= 0.24 && abs(forward.y) <= 0.30
        case .buildingSide:
            return abs(angleDifference(yawDelta, buildingTarget)) <= 0.34
                && abs(forward.y) <= 0.34
        case .roadSide:
            return abs(angleDifference(yawDelta, -buildingTarget)) <= 0.34
                && abs(forward.y) <= 0.34
        case .rear:
            return abs(abs(yawDelta) - .pi) <= 0.34
                && abs(forward.y) <= 0.34
        case .ground:
            return forward.y <= -0.28
        case .canopy:
            return forward.y >= 0.22
        }
    }

    private func reserveStation(
        nominalDistance: Double,
        measuredDistance: Double
    ) -> StationReservation {
        let legDistance = currentLegIndex == 0
            ? nominalDistance
            : max(0, nominalDistance - (returnTripStartedAtMeters ?? nominalDistance))
        let reservation = StationReservation(
            sequence: reservedStationCount,
            nominalRouteDistanceMeters: nominalDistance,
            measuredRouteDistanceMeters: measuredDistance,
            direction: currentLegIndex == 0 ? "outbound" : "return",
            legIndex: currentLegIndex,
            legDistanceMeters: legDistance
        )
        reservedStationCount += 1
        lastReservedDistanceMeters = measuredDistance
        return reservation
    }

    private func encodeStationView(
        frame: ARFrame,
        frameNumber: Int,
        reservation: StationReservation,
        face: WalkStationFace
    ) {
        let frameName = String(format: "%06d", frameNumber)
        let imageFilename =
            "station-\(String(format: "%06d", reservation.sequence))-\(face.rawValue).jpg"
        let relativeImagePath = "stations/\(imageFilename)"
        let imageURL = stationDirectory.appendingPathComponent(imageFilename)
        let sourceImage = CIImage(cvPixelBuffer: frame.capturedImage)
        // ARKit supplies camera pixels in the sensor's native landscape
        // orientation. Captures are made with the phone held in portrait, so
        // rotate the saved RGB pixels once on-device. This keeps Photos, Files,
        // Windows and the website from each having to guess the orientation.
        let portraitImage = sourceImage.oriented(.right)

        do {
            if let jpegData = stationImageContext.jpegRepresentation(
                of: portraitImage,
                colorSpace: CGColorSpaceCreateDeviceRGB(),
                options: [:]
            ) {
                try jpegData.write(to: imageURL, options: .atomic)
            } else {
                print("Could not create JPEG for station \(reservation.sequence).")
            }
        } catch {
            print("Could not save station \(reservation.sequence). \(error.localizedDescription)")
        }

        let transform = frame.camera.transform
        let position = transform.columns.3
        let quaternion = simd_quatf(transform).vector
        let euler = frame.camera.eulerAngles
        let intrinsics = frame.camera.intrinsics
        let sensorHeight = Float(CVPixelBufferGetHeight(frame.capturedImage))
        let portraitIntrinsics: [Float] = [
            intrinsics.columns.1.y, 0, 0,
            0, intrinsics.columns.0.x, 0,
            sensorHeight - 1 - intrinsics.columns.2.y,
            intrinsics.columns.2.x,
            1
        ]

        let view = WalkStationView(
            face: face,
            frame: frameName,
            frameTimestamp: frame.timestamp,
            capturedAtEpochSeconds: systemBootEpochSeconds + frame.timestamp,
            rgbImage: relativeImagePath,
            depthImage: "depth/\(frameName).png",
            confidenceImage: "confidence/\(frameName).png",
            trackingQuality: trackingQuality(frame.camera.trackingState),
            imageWidthPixels: Int(portraitImage.extent.width.rounded()),
            imageHeightPixels: Int(portraitImage.extent.height.rounded()),
            cameraPositionMeters: [position.x, position.y, position.z],
            cameraQuaternion: [quaternion.x, quaternion.y, quaternion.z, quaternion.w],
            cameraEulerRadians: [euler.x, euler.y, euler.z],
            cameraIntrinsics: portraitIntrinsics
        )
        var accumulator = stationAccumulators[reservation.sequence]
            ?? StationAccumulator(reservation: reservation, views: [])
        accumulator.views.append(view)
        stationAccumulators[reservation.sequence] = accumulator
    }

    private func trackingQuality(_ state: ARCamera.TrackingState) -> String {
        switch state {
        case .normal:
            return "normal"
        case .notAvailable:
            return "not_available"
        case .limited(let reason):
            switch reason {
            case .excessiveMotion:
                return "limited_excessive_motion"
            case .insufficientFeatures:
                return "limited_insufficient_features"
            case .initializing:
                return "limited_initializing"
            case .relocalizing:
                return "limited_relocalizing"
            @unknown default:
                return "limited_unknown"
            }
        }
    }

    func add(location: CLLocation) {
        guard location.horizontalAccuracy >= 0 else { return }
        locationLock.lock()
        locationSamples.append(LocationSample(location: location))
        locationLock.unlock()
    }

    func wrapUp(travelDistance: Double) {
        dispatchGroup.wait()
        self.odometryEncoder.done()
        self.routeTraceEncoder.done()
        self.distortionEncoder.done()
        writeIntrinsics()
        writeStationIndex()
        writeMissionManifest(travelDistance: travelDistance)
        writeMissionContext()
        writeLocations()
        status = .allGood
        switch self.depthEncoder.status {
            case .allGood:
                break
            case .frameEncodingError:
                status = .encodingError
                print("Something went wrong encoding depth.")
        }
        switch self.confidenceEncoder.status {
            case .allGood:
                break
            case .encodingError:
                status = .encodingError
                print("Something went wrong encoding confidence values.")
        }
    }

    private func writeMissionManifest(travelDistance: Double) {
        let manifest = WalkScanManifest(
            schemaVersion: 4,
            source: "ZhubeiWalkCapture",
            captureMethod: "guided_rgbd_stills",
            guidanceMode: "rolling_lidar_ar_gates",
            guidanceSpacingMeters: stationSpacingMeters,
            guidancePlanningWindowMeters: 5.0,
            origin: origin,
            captureMode: mission.captureMode.rawValue,
            captureProfile: mission.captureProfile.rawValue,
            buildingSide: mission.buildingSide.rawValue,
            segmentID: mission.segmentID,
            targetLengthMeters: mission.targetLengthMeters,
            expectedTravelMeters: mission.expectedTravelMeters,
            measuredTravelMeters: travelDistance,
            requiresReturnTrip: mission.requiresReturnTrip,
            stationSpacingMeters: stationSpacingMeters,
            capturedStationCount: stationAccumulators.count,
            systemBootEpochSeconds: systemBootEpochSeconds,
            odometryTimestampTimebase: "seconds_since_system_boot",
            captureStartedAt: captureStartedAt,
            captureCompletedAt: Date(),
            deviceModel: UIDevice.current.model,
            operatingSystem: "\(UIDevice.current.systemName) \(UIDevice.current.systemVersion)",
            contents: [
                "depth/*.png",
                "confidence/*.png",
                "odometry.csv",
                "route.csv",
                "locations.csv",
                "camera_matrix.csv",
                "stations.json",
                "stations/*.jpg"
            ]
        )
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        do {
            let data = try encoder.encode(manifest)
            try data.write(to: datasetDirectory.appendingPathComponent("mission.json"), options: .atomic)
        } catch {
            print("Could not write mission manifest. \(error.localizedDescription)")
        }
    }

    private func writeMissionContext() {
        let evidence = evidenceSnapshot()
        let legs = [
            WalkMissionContext.Leg(
                legIndex: 0,
                role: "outbound",
                startedAtRouteDistance: 0,
                endpointConfirmed: outboundEndpointConfirmedAtMeters != nil,
                startAnchorRawStationID: evidence.startAnchorStationID,
                endAnchorRawStationID: evidence.outboundEndpointStationID
            )
        ] + (returnTripStartedAtMeters.map {
            [WalkMissionContext.Leg(
                legIndex: 1,
                role: "return",
                startedAtRouteDistance: $0,
                endpointConfirmed: evidence.returnEndpointStationID != nil,
                startAnchorRawStationID: evidence.returnStartAnchorStationID,
                endAnchorRawStationID: evidence.returnEndpointStationID
            )]
        } ?? [])

        let context = WalkMissionContext(
            schema: "zhubei.walkscan.mission-context.v1",
            missionID: id,
            segmentID: mission.segmentID,
            capturePolicyID: mission.capturePolicy.policyID,
            geometryAuthority: mission.mapBinding == nil ? "unbound_discovery" : "gis_capture_axis",
            mapReferenceStatus: mission.mapBinding == nil ? "not_selected" : "confirmed_crosshair",
            mapReference: mission.mapBinding.map { binding in
                let axisLengthMeters = Double(binding.axisLengthMm) / 1000
                let endsAtAxisStart = binding.captureEndChainageMeters <= 0.001
                let endSegmentIndex = endsAtAxisStart
                    ? 0
                    : max(0, binding.vertexChainageMm.count - 2)
                let endSegmentT = endsAtAxisStart ? 0.0 : 1.0
                let endNormalized = axisLengthMeters > 0
                    ? binding.captureEndChainageMeters / axisLengthMeters
                    : 0.0
                return WalkMissionContext.MapReference(
                    datasetID: binding.datasetID,
                    datasetRevisionID: binding.datasetRevisionID,
                    featureID: binding.featureID,
                    subsegmentID: binding.subsegmentID,
                    geometryRevisionID: binding.geometryRevisionID,
                    geometryHash: binding.geometryHash,
                    axisStartNodeID: binding.axisStartNodeID,
                    axisEndNodeID: binding.axisEndNodeID,
                    axisLengthMm: binding.axisLengthMm,
                    vertexChainageMm: binding.vertexChainageMm,
                    selectedSegmentIndex: binding.selectedSegmentIndex,
                    selectedSegmentFraction: binding.selectedSegmentFraction,
                    selectedChainageMeters: binding.selectedChainageMeters,
                    selectedNormalizedMeasure: binding.selectedNormalizedMeasure,
                    originalLatitude: binding.originalLatitude,
                    originalLongitude: binding.originalLongitude,
                    horizontalAccuracyMeters: binding.horizontalAccuracyMeters,
                    captureDirection: binding.captureDirection,
                    captureStartChainageMeters: binding.captureStartChainageMeters,
                    captureEndChainageMeters: binding.captureEndChainageMeters,
                    snappedLatitude: binding.snappedLatitude,
                    snappedLongitude: binding.snappedLongitude,
                    snapDistanceMeters: binding.snapDistanceMeters,
                    selectionMethod: binding.selectionMethod,
                    packStatus: binding.packStatus,
                    startAnchor: WalkMissionContext.MapAnchor(
                        chainageMeters: binding.captureStartChainageMeters,
                        normalizedMeasure: binding.selectedNormalizedMeasure,
                        segmentIndex: binding.selectedSegmentIndex,
                        segmentT: binding.selectedSegmentFraction,
                        rawStationID: evidence.startAnchorStationID
                    ),
                    endAnchor: WalkMissionContext.MapAnchor(
                        chainageMeters: binding.captureEndChainageMeters,
                        normalizedMeasure: endNormalized,
                        segmentIndex: endSegmentIndex,
                        segmentT: endSegmentT,
                        rawStationID: evidence.outboundEndpointStationID
                    )
                )
            },
            outboundEndpointConfirmedAtRouteDistance: outboundEndpointConfirmedAtMeters,
            legs: legs,
            eventReferences: pendingEventReferences.map { event in
                WalkMissionContext.EventReference(
                    eventID: event.eventID,
                    eventClass: event.eventClass,
                    trigger: event.trigger,
                    requestedView: event.requestedView,
                    legIndex: event.legIndex,
                    rawStationID: rawStationID(
                        for: event.sequence,
                        legIndex: event.legIndex
                    ),
                    rawViewFace: event.rawViewFace,
                    observationGroupID: event.observationGroupID
                )
            },
            imageQuality: imageQualitySummary()
        )
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        do {
            let data = try encoder.encode(context)
            try data.write(
                to: datasetDirectory.appendingPathComponent("mission-context.json"),
                options: .atomic
            )
        } catch {
            print("Could not write private mission context. \(error.localizedDescription)")
        }
    }

    private func imageQualitySummary() -> WalkMissionContext.ImageQuality {
        let affected = imageQualityObservations.filter { !$0.issueCodes.isEmpty }
        var issueCounts: [String: Int] = [:]
        for observation in affected {
            for code in observation.issueCodes { issueCounts[code, default: 0] += 1 }
        }
        return WalkMissionContext.ImageQuality(
            configuration: CaptureLumaAnalyzer.configuration,
            observationCount: imageQualityObservations.count,
            affectedStationCount: Set(affected.map(\.rawStationID)).count,
            issueCounts: issueCounts,
            observations: imageQualityObservations
        )
    }

    private func buildStations() -> [WalkStation] {
        return stationAccumulators.values
            .sorted { $0.reservation.sequence < $1.reservation.sequence }
            .compactMap { accumulator in
                guard let primary = accumulator.views.first(where: { $0.face == .forward })
                    ?? accumulator.views.first else {
                    return nil
                }
                let reservation = accumulator.reservation
                let stationID = rawStationID(
                    for: reservation.sequence,
                    legIndex: reservation.legIndex
                )
                let capturedFaces = accumulator.views.map(\.face)
                let requiredFaces = eventRequiredFace(
                    for: reservation.sequence
                ).map { [$0] } ?? requiredFacesForMission()
                let missingFaces = requiredFaces.filter { !capturedFaces.contains($0) }

                return WalkStation(
                    stationID: stationID,
                    sequence: reservation.sequence,
                    direction: reservation.direction,
                    legIndex: reservation.legIndex,
                    legDistanceMeters: reservation.legDistanceMeters,
                    nominalRouteDistanceMeters: reservation.nominalRouteDistanceMeters,
                    measuredRouteDistanceMeters: reservation.measuredRouteDistanceMeters,
                    frame: primary.frame,
                    frameTimestamp: primary.frameTimestamp,
                    capturedAtEpochSeconds: primary.capturedAtEpochSeconds,
                    rgbImage: primary.rgbImage,
                    depthImage: primary.depthImage,
                    confidenceImage: primary.confidenceImage,
                    trackingQuality: primary.trackingQuality,
                    imageWidthPixels: primary.imageWidthPixels,
                    imageHeightPixels: primary.imageHeightPixels,
                    cameraPositionMeters: primary.cameraPositionMeters,
                    cameraQuaternion: primary.cameraQuaternion,
                    cameraEulerRadians: primary.cameraEulerRadians,
                    cameraIntrinsics: primary.cameraIntrinsics,
                    requiredFaces: requiredFaces,
                    capturedFaces: capturedFaces,
                    missingFaces: missingFaces,
                    captureComplete: missingFaces.isEmpty,
                    views: accumulator.views
                )
            }
    }

    private func rawStationID(for sequence: Int, legIndex: Int) -> String {
        let safeSegmentID = mission.segmentID.replacingOccurrences(
            of: "[^A-Za-z0-9_-]",
            with: "-",
            options: .regularExpression
        )
        let legCode = legIndex == 0 ? "F" : "R"
        return "\(safeSegmentID)-\(legCode)-\(String(format: "%03d", sequence))"
    }

    private func eventRequiredFace(for sequence: Int) -> WalkStationFace? {
        pendingEventReferences.first { $0.sequence == sequence }.flatMap {
            WalkStationFace(rawValue: $0.rawViewFace)
        }
    }

    private func writeStationIndex() {
        let index = WalkStationIndex(
            schemaVersion: 2,
            spacingMeters: stationSpacingMeters,
            coordinateSystem: "ARKit gravityAndHeading: +x east, +y up, +z south, metres",
            imageOrientation: "portrait pixels; RGB rotated 90 degrees clockwise on device; intrinsics transformed to match",
            depthImageOrientation: "native landscape sensor pixels; rotate 90 degrees clockwise to align with RGB",
            stations: buildStations()
        )
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        do {
            let data = try encoder.encode(index)
            try data.write(
                to: datasetDirectory.appendingPathComponent("stations.json"),
                options: .atomic
            )
        } catch {
            print("Could not write station index. \(error.localizedDescription)")
        }
    }

    private func writeLocations() {
        locationLock.lock()
        let samples = locationSamples
        locationLock.unlock()

        var lines = [
            "timestamp,latitude,longitude,altitude,horizontal_accuracy,vertical_accuracy,speed,course"
        ]
        lines.append(contentsOf: samples.map {
            "\($0.timestamp),\($0.latitude),\($0.longitude),\($0.altitude),\($0.horizontalAccuracy),\($0.verticalAccuracy),\($0.speed),\($0.course)"
        })
        do {
            try lines.joined(separator: "\n").write(
                to: datasetDirectory.appendingPathComponent("locations.csv"),
                atomically: true,
                encoding: .utf8
            )
        } catch {
            print("Could not write locations. \(error.localizedDescription)")
        }
    }

    private func writeIntrinsics() {
        if let cameraMatrix = lastCameraIntrinsics {
            let rows = cameraMatrix.transpose.columns
            var csv: [String] = []
            for row in [rows.0, rows.1, rows.2] {
                let csvLine = "\(row.x), \(row.y), \(row.z)"
                csv.append(csvLine)
            }
            let contents = csv.joined(separator: "\n")
            do {
                try contents.write(to: self.cameraMatrixPath, atomically: true, encoding: String.Encoding.utf8)
            } catch let error {
                print("Could not write camera matrix. \(error.localizedDescription)")
            }
        }
    }

    static private func createDirectory(id: inout UUID) -> URL {
        let directoryId = hashUUID(id: id)
        let url = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        var directory = URL(fileURLWithPath: directoryId, relativeTo: url)
        if FileManager.default.fileExists(atPath: directory.absoluteString) {
            // Just in case the first 5 characters clash, try again.
            id = UUID()
            directory = DatasetEncoder.createDirectory(id: &id)
        }
        do {
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true, attributes: nil)
        } catch let error as NSError {
            print("Error creating directory. \(error), \(error.userInfo)")
        }
        return directory
    }

    static private func hashUUID(id: UUID) -> String {
        var hasher: SHA256 = SHA256()
        hasher.update(data: id.uuidString.data(using: .ascii)!)
        let digest = hasher.finalize()
        var string = ""
        digest.makeIterator().prefix(5).forEach { (byte: UInt8) in
            string += String(format: "%02x", byte)
        }
        print("Hash: \(string)")
        return string
    }
}
