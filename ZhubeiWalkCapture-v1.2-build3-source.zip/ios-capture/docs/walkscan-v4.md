# WalkScan v4：多方向節點與連續路徑

WalkScan v4 是專業人行空間採集格式。它與社群快速通報的
`Report v1` 分離，不可直接作為公開案件媒體。

## 採集模式

- `quick_route`：起點、每 2 公尺與尾端保存一組前視 RGB-D 證據。
- `six_face`：每個節點依序保存 `forward`、`building_side`、
  `road_side`、`ground` 與 `canopy`。

`buildingSide` 記錄使用者面向行進方向時，建築位於左側或右側。
後面由前一節點或回程證據支撐，不要求使用者每 2 公尺轉身。

## 即時路徑引導

`mission.json` 包含：

```json
{
  "guidanceMode": "rolling_lidar_ar_gates",
  "guidanceSpacingMeters": 2.0,
  "guidancePlanningWindowMeters": 5.0
}
```

App 以手機朝向作為使用者意圖、LiDAR 深度地面點作為幾何校正，在
局部可見範圍內建立固定世界座標的 AR 光門。光門建立後不會跟著
手機漂移；使用者實際穿過門面後，才會觸發該節點並規劃下一門。

這是採集引導，不是安全導航承諾。地面資料不足時會降低 confidence
並退回手機朝向；使用者仍須自行注意車流、施工與臨時障礙。

## 路徑與節點分離

- `route.csv`：約每 0.2 秒保存一次 ARKit 相機位置，供自由轉彎中心線重建。
- `odometry.csv`：只保存實際寫入 RGB-D 證據的影格位姿。
- `stations.json`：以 2 公尺空間節點為單位；每個節點含一個或多個 `views`。

這能避免使用五方向照片數量代替空間節點數，也能在沒有密集照片時保留
連續行走軌跡。

## 資料夾

```text
mission.json
stations.json
route.csv
odometry.csv
locations.csv
camera_matrix.csv
stations/
  station-000000-forward.jpg
  station-000000-building_side.jpg
depth/
confidence/
distortion/
```

## 私有傳輸與社群傳輸

- `.walkscan` 原始 RGB-D 只供使用者自己的手機、電腦與私有處理流程。
- 未來社群功能必須另行產生 `SanitizedEvidence`，只包含裝置端去識別、
  移除 EXIF 並由使用者確認的媒體。
- WalkScan 完整性狀態與社群 Report 審核狀態不得共用。
