//
//  SessionList.swift
//  Stray Scanner
//
//  Created by Kenneth Blomqvist on 11/15/20.
//  Copyright © 2020 Stray Robots. All rights reserved.
//

import SwiftUI
import CoreData
import CoreLocation

enum WalkCaptureMode: String, Codable, Equatable {
    case mappedSegment = "mapped_segment"
    case freeRoute = "free_route"
}

enum WalkCaptureProfile: String, Codable, Equatable {
    case quickRoute = "quick_route"
    case sixFace = "six_face"

    var title: String {
        switch self {
        case .quickRoute:
            return "快速動線"
        case .sixFace:
            return "六面調查"
        }
    }
}

enum WalkBuildingSide: String, Codable, Equatable {
    case left
    case right

    var title: String {
        self == .left ? "左側" : "右側"
    }
}

struct WalkMission: Codable, Equatable {
    let segmentID: String
    let targetLengthMeters: Double
    let requiresReturnTrip: Bool
    let captureMode: WalkCaptureMode
    let captureProfile: WalkCaptureProfile
    let buildingSide: WalkBuildingSide

    init(
        segmentID: String,
        targetLengthMeters: Double,
        requiresReturnTrip: Bool,
        captureMode: WalkCaptureMode = .freeRoute,
        captureProfile: WalkCaptureProfile = .quickRoute,
        buildingSide: WalkBuildingSide = .left
    ) {
        self.segmentID = segmentID
        self.targetLengthMeters = targetLengthMeters
        self.requiresReturnTrip = requiresReturnTrip
        self.captureMode = captureMode
        self.captureProfile = captureProfile
        self.buildingSide = buildingSide
    }

    var expectedTravelMeters: Double {
        guard captureMode == .mappedSegment else { return 0 }
        return targetLengthMeters * (requiresReturnTrip ? 2.0 : 1.0)
    }
}

class SessionListViewModel: ObservableObject {
    private var dataContext: NSManagedObjectContext?
    @Published var sessions: [Recording] = []

    init() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        dataContext = appDelegate.persistentContainer.viewContext
        self.sessions = []
        NotificationCenter.default.addObserver(self, selector: #selector(sessionsChanged), name: NSNotification.Name("sessionsChanged"), object: nil)
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
    }

    func fetchSessions() {
        let request = NSFetchRequest<NSManagedObject>(entityName: "Recording")
        request.sortDescriptors = [NSSortDescriptor(key: "createdAt", ascending: false)]
        do {
            let fetched: [NSManagedObject] = try dataContext?.fetch(request) ?? []
            sessions = fetched.map { session in
                return session as! Recording
            }

        } catch let error as NSError {
            print("Something went wrong. Error: \(error), \(error.userInfo)")
        }
    }

    @objc func sessionsChanged() {
        fetchSessions()
    }

}

struct SessionList: View {
    @ObservedObject var viewModel = SessionListViewModel()
    @State private var segmentID = "ZB-WALK-0001"
    @State private var captureMode: WalkCaptureMode = .freeRoute
    @State private var captureProfile: WalkCaptureProfile = .quickRoute
    @State private var buildingSide: WalkBuildingSide = .left
    @State private var pairingCode = ""
    @State private var cloudNotice: String?
    @State private var pendingPrivateTransfers = 0
    @State private var localCommunityDrafts = 0
    @State private var activeMission: WalkMission?
    @State private var showingRecorder = false
    @State private var validationMessage: String?

    private var mission: WalkMission? {
        let trimmedID = segmentID.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        guard !trimmedID.isEmpty else { return nil }
        return WalkMission(
            segmentID: trimmedID,
            targetLengthMeters: 0,
            requiresReturnTrip: true,
            captureMode: .freeRoute,
            captureProfile: captureProfile,
            buildingSide: buildingSide
        )
    }

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("竹北人行道採集")
                            .font(.largeTitle.bold())
                        Text("站在起點鎖定方向，向前走、自然轉身後按一次按鈕，再沿原路走回。")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }

                    NavigationLink(destination: QuickCommunityReportView()) {
                        HStack(spacing: 14) {
                            Image(systemName: "camera.viewfinder")
                                .font(.title2)
                                .foregroundColor(.orange)
                            VStack(alignment: .leading, spacing: 3) {
                                Text("快速記錄人行空間問題")
                                    .font(.headline)
                                Text(
                                    localCommunityDrafts == 0
                                        ? "原圖留在手機，確認遮蔽後才建立可上傳草稿"
                                        : "手機內有 \(localCommunityDrafts) 份未公開草稿"
                                )
                                    .font(.footnote)
                                    .foregroundColor(.secondary)
                            }
                            Spacer()
                            Image(systemName: "chevron.right")
                                .foregroundColor(.secondary)
                        }
                        .padding(16)
                        .background(Color(.secondarySystemBackground))
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                    }
                    .buttonStyle(.plain)

                    VStack(alignment: .leading, spacing: 14) {
                        Text("這次要怎麼採集？")
                            .font(.headline)

                        Picker("資料深度", selection: $captureProfile) {
                            Text("一般往返").tag(WalkCaptureProfile.quickRoute)
                            Text("重點六面").tag(WalkCaptureProfile.sixFace)
                        }
                        .pickerStyle(.segmented)

                        if captureProfile == .sixFace {
                            Picker("面向行進方向時，建築位於", selection: $buildingSide) {
                                Text("建築在左").tag(WalkBuildingSide.left)
                                Text("建築在右").tag(WalkBuildingSide.right)
                            }
                            .pickerStyle(.segmented)

                            Text("每 2 公尺依準星引導，自動保存前方、建築側、道路側、鋪面與遮陰證據。")
                                .font(.footnote)
                                .foregroundColor(.secondary)
                        }

                        TextField("路段編號，例如 ZB-WALK-00428", text: $segmentID)
                            .textInputAutocapitalization(.characters)
                            .autocorrectionDisabled()
                            .padding(14)
                            .background(Color(.secondarySystemBackground))
                            .clipShape(RoundedRectangle(cornerRadius: 14))

                        Text("不用填長度。去程與回程都會每 2 公尺自動拍照；轉身後只需按一次「我已轉身」。")
                            .font(.footnote)
                            .foregroundColor(.secondary)
                            .padding(14)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(Color(.secondarySystemBackground))
                            .clipShape(RoundedRectangle(cornerRadius: 14))

                        if let mission {
                            Label("自由動線｜去程後手動標記回程", systemImage: "point.topleft.down.to.point.bottomright.curvepath")
                                .font(.footnote)
                                .foregroundColor(.secondary)
                            Label(
                                mission.captureProfile == .sixFace
                                    ? "六面調查｜建築在\(mission.buildingSide.title)"
                                    : "快速動線｜每 2 公尺一張",
                                systemImage: mission.captureProfile == .sixFace
                                    ? "cube.transparent"
                                    : "figure.walk.motion"
                            )
                            .font(.footnote)
                            .foregroundColor(.secondary)
                        }

                        Button(action: beginMission) {
                            Label("開始採集", systemImage: "viewfinder")
                                .font(.title3.bold())
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 16)
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(.green)
                        .clipShape(RoundedRectangle(cornerRadius: 16))

                        NavigationLink(
                            destination: Group {
                                if let activeMission {
                                    NewSessionView(mission: activeMission)
                                }
                            },
                            isActive: $showingRecorder
                        ) {
                            EmptyView()
                        }
                    }

                    VStack(alignment: .leading, spacing: 10) {
                        Text("私人雲端自動上傳")
                            .font(.headline)
                        if WalkScanSecretStore.receiverToken.isEmpty {
                            SecureField(
                                "第一次啟用：輸入 8 位配對碼",
                                text: $pairingCode
                            )
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                                .keyboardType(.numberPad)
                                .padding(14)
                                .background(Color(.secondarySystemBackground))
                                .clipShape(RoundedRectangle(cornerRadius: 14))

                            Button("啟用這台 iPhone") {
                                cloudNotice = "正在安全配對…"
                                PrivateWalkScanTransferQueue.shared.registerDevice(
                                    pairingCode: pairingCode
                                ) { result in
                                    switch result {
                                    case .success:
                                        pairingCode = ""
                                        cloudNotice = "雲端已啟用；之後拍完會自動上傳。"
                                    case .failure(let error):
                                        cloudNotice = error.localizedDescription
                                    }
                                }
                            }
                            .buttonStyle(.borderedProminent)
                            .disabled(pairingCode.count != 8)
                        } else {
                            Label(
                                "雲端已啟用｜等待 \(pendingPrivateTransfers) 份",
                                systemImage: "checkmark.icloud.fill"
                            )
                            .foregroundColor(.green)

                            Button("上傳最近一筆／重試") {
                                if let latest = viewModel.sessions.first {
                                    PrivateWalkScanTransferQueue.shared.enqueue(
                                        recording: latest
                                    )
                                } else {
                                    PrivateWalkScanTransferQueue.shared.resumePending()
                                }
                                pendingPrivateTransfers =
                                    PrivateWalkScanTransferQueue.shared.pendingCount()
                            }
                            .buttonStyle(.bordered)
                        }

                        if let cloudNotice {
                            Text(cloudNotice)
                                .font(.footnote)
                                .foregroundColor(
                                    cloudNotice.contains("已啟用") ? .green : .secondary
                                )
                        }
                        Text("外出可用 5G；失敗會留在手機並自動續傳。")
                            .font(.footnote)
                            .foregroundColor(.secondary)
                    }

                    if !viewModel.sessions.isEmpty {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("最近完成")
                                .font(.headline)

                            ForEach(viewModel.sessions, id: \.objectID) { recording in
                                NavigationLink(destination: SessionDetailView(recording: recording)) {
                                    HStack {
                                        Image(systemName: "checkmark.circle.fill")
                                            .foregroundColor(.green)
                                        VStack(alignment: .leading, spacing: 3) {
                                            Text(recording.name ?? "未命名路段")
                                                .font(.body.bold())
                                            Text(recording.createdAt ?? Date(), style: .date)
                                                .font(.caption)
                                                .foregroundColor(.secondary)
                                        }
                                        Spacer()
                                        Image(systemName: "chevron.right")
                                            .foregroundColor(.secondary)
                                    }
                                    .padding(14)
                                    .background(Color(.secondarySystemBackground))
                                    .clipShape(RoundedRectangle(cornerRadius: 14))
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                }
                .padding(20)
            }
            .background(Color(.systemBackground).ignoresSafeArea())
            .navigationBarHidden(true)
            .onAppear(perform: refreshSessions)
            .onReceive(
                NotificationCenter.default.publisher(
                    for: PrivateWalkScanTransferQueue.statusChanged
                )
            ) { _ in
                pendingPrivateTransfers =
                    PrivateWalkScanTransferQueue.shared.pendingCount()
            }
            .alert("還不能開始", isPresented: Binding(
                get: { validationMessage != nil },
                set: { if !$0 { validationMessage = nil } }
            )) {
                Button("知道了", role: .cancel) {}
            } message: {
                Text(validationMessage ?? "")
            }
        }
    }

    private func beginMission() {
        guard let mission else {
            validationMessage = "請先輸入這次自由動線的名稱或編號。"
            return
        }
        activeMission = mission
        showingRecorder = true
    }

    private func refreshSessions() {
        DispatchQueue.main.async {
            viewModel.fetchSessions()
        }
        let delegate = UIApplication.shared.delegate as? AppDelegate
        delegate?.appDaemon?.removeDeletedEntries()
        pendingPrivateTransfers = PrivateWalkScanTransferQueue.shared.pendingCount()
        localCommunityDrafts = CommunityDraftStore.all().count
        PrivateWalkScanTransferQueue.shared.resumePending()
    }
}

struct SessionList_Previews: PreviewProvider {
    static var previews: some View {
        SessionList()
    }
}

final class QuickReportLocationProvider: NSObject, ObservableObject, CLLocationManagerDelegate {
    @Published var location: CLLocation?
    @Published var statusText = "正在取得位置…"
    private let manager = CLLocationManager()

    override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.requestWhenInUseAuthorization()
        manager.startUpdatingLocation()
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let newest = locations.last, newest.horizontalAccuracy >= 0 else { return }
        location = newest
        statusText = String(format: "私密定位精度 ±%.0f 公尺", newest.horizontalAccuracy)
    }

    func locationManager(
        _ manager: CLLocationManager,
        didFailWithError error: Error
    ) {
        statusText = "尚未取得位置：\(error.localizedDescription)"
    }
}

struct QuickCommunityReportView: View {
    @StateObject private var locationProvider = QuickReportLocationProvider()
    @State private var category: CommunityReportCategory = .blockedSidewalk
    @State private var description = ""
    @State private var image: UIImage?
    @State private var regions: [RedactionRegion] = []
    @State private var selectedRegionID: UUID?
    @State private var isAddingRegion = false
    @State private var isShowingCamera = false
    @State private var isDetecting = false
    @State private var notice: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text("快速通報草稿")
                    .font(.largeTitle.bold())
                Text("這裡只建立尚未公開的本機草稿。原始照片不會進入上傳封包。")
                    .foregroundColor(.secondary)

                Picker("問題類別", selection: $category) {
                    ForEach(CommunityReportCategory.allCases) { item in
                        Text(item.title).tag(item)
                    }
                }
                .pickerStyle(.menu)

                TextEditor(text: $description)
                    .frame(minHeight: 92)
                    .padding(10)
                    .background(Color(.secondarySystemBackground))
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .overlay(alignment: .topLeading) {
                        if description.isEmpty {
                            Text("簡短描述實際行人遇到的問題")
                                .foregroundColor(.secondary)
                                .padding(16)
                                .allowsHitTesting(false)
                        }
                    }

                Label(locationProvider.statusText, systemImage: "location.fill")
                    .font(.footnote)
                    .foregroundColor(
                        locationProvider.location == nil ? .orange : .secondary
                    )

                if let image {
                    RedactionCanvas(
                        image: image,
                        regions: $regions,
                        selectedRegionID: $selectedRegionID,
                        isAddingRegion: $isAddingRegion
                    )
                    .frame(height: 390)
                    .clipShape(RoundedRectangle(cornerRadius: 16))

                    HStack {
                        Button(isAddingRegion ? "點照片加入遮蔽" : "新增人工遮蔽") {
                            isAddingRegion.toggle()
                        }
                        .buttonStyle(.borderedProminent)

                        Button("刪除所選遮蔽", role: .destructive) {
                            guard let selectedRegionID else { return }
                            regions.removeAll { $0.id == selectedRegionID }
                            self.selectedRegionID = nil
                        }
                        .buttonStyle(.bordered)
                        .disabled(selectedRegionID == nil)
                    }

                    Text(
                        "人臉 \(regions.filter { $0.kind == .face }.count)・"
                            + "車牌候選 \(regions.filter { $0.kind == .plateCandidate }.count)・"
                            + "人工 \(regions.filter { $0.kind == .manual }.count)"
                    )
                    .font(.footnote)
                    .foregroundColor(.secondary)
                }

                Button {
                    isShowingCamera = true
                } label: {
                    Label(
                        image == nil ? "拍攝問題照片" : "重新拍攝",
                        systemImage: "camera.fill"
                    )
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                }
                .buttonStyle(.bordered)

                Button(action: saveDraft) {
                    HStack {
                        if isDetecting {
                            ProgressView()
                        }
                        Text(isDetecting ? "正在辨識隱私區域…" : "確認遮蔽並儲存草稿")
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                }
                .buttonStyle(.borderedProminent)
                .tint(.green)
                .disabled(
                    image == nil
                        || locationProvider.location == nil
                        || description.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                        || isDetecting
                )

                if let notice {
                    Text(notice)
                        .font(.footnote)
                        .foregroundColor(notice.contains("完成") ? .green : .orange)
                }
            }
            .padding(20)
        }
        .navigationTitle("快速通報")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $isShowingCamera) {
            CommunityCameraPicker { captured in
                guard let captured else { return }
                image = captured.normalizedUp()
                regions = []
                selectedRegionID = nil
                isDetecting = true
                Task {
                    do {
                        let detected = try await OnDeviceRedaction.detectRegions(
                            in: captured.normalizedUp()
                        )
                        await MainActor.run {
                            regions = detected
                            isDetecting = false
                            notice = detected.isEmpty
                                ? "沒有自動找到人臉或車牌；仍請目視確認並可人工補遮。"
                                : "已標出候選區域，請逐一目視確認。"
                        }
                    } catch {
                        await MainActor.run {
                            isDetecting = false
                            notice = "自動辨識失敗，請使用人工遮蔽。"
                        }
                    }
                }
            }
        }
    }

    private func saveDraft() {
        guard let image,
              let location = locationProvider.location else {
            return
        }
        do {
            let redacted = OnDeviceRedaction.renderRedacted(
                image: image,
                regions: regions
            )
            _ = try CommunityDraftStore.save(
                original: image,
                redacted: redacted,
                category: category,
                description: description.trimmingCharacters(in: .whitespacesAndNewlines),
                location: location,
                regions: regions
            )
            notice = "草稿建立完成；目前仍未公開，也尚未送出。"
        } catch {
            notice = "草稿儲存失敗：\(error.localizedDescription)"
        }
    }
}

struct RedactionCanvas: View {
    let image: UIImage
    @Binding var regions: [RedactionRegion]
    @Binding var selectedRegionID: UUID?
    @Binding var isAddingRegion: Bool
    @State private var dragOrigins: [UUID: NormalizedRect] = [:]

    var body: some View {
        GeometryReader { geometry in
            let frame = aspectFitFrame(
                imageSize: image.size,
                containerSize: geometry.size
            )
            ZStack(alignment: .topLeading) {
                Color.black
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(width: frame.width, height: frame.height)
                    .position(x: frame.midX, y: frame.midY)

                ForEach($regions) { $region in
                    let rect = displayRect(region.rect, inside: frame)
                    RoundedRectangle(cornerRadius: 5)
                        .fill(Color.black.opacity(0.82))
                        .overlay(
                            RoundedRectangle(cornerRadius: 5)
                                .stroke(
                                    selectedRegionID == region.id
                                        ? Color.yellow
                                        : Color.white.opacity(0.8),
                                    lineWidth: selectedRegionID == region.id ? 3 : 1
                                )
                        )
                        .frame(width: rect.width, height: rect.height)
                        .position(x: rect.midX, y: rect.midY)
                        .onTapGesture {
                            selectedRegionID = region.id
                        }
                        .gesture(
                            DragGesture()
                                .onChanged { value in
                                    let origin = dragOrigins[region.id] ?? region.rect
                                    dragOrigins[region.id] = origin
                                    region.rect.x = clamp(
                                        origin.x + Double(value.translation.width / frame.width),
                                        0,
                                        1 - region.rect.width
                                    )
                                    region.rect.y = clamp(
                                        origin.y - Double(value.translation.height / frame.height),
                                        0,
                                        1 - region.rect.height
                                    )
                                }
                                .onEnded { _ in
                                    dragOrigins.removeValue(forKey: region.id)
                                }
                        )
                }
            }
            .contentShape(Rectangle())
            .simultaneousGesture(
                SpatialTapGesture().onEnded { value in
                    guard isAddingRegion, frame.contains(value.location) else { return }
                    let x = Double((value.location.x - frame.minX) / frame.width)
                    let yFromTop = Double((value.location.y - frame.minY) / frame.height)
                    let width = 0.20
                    let height = 0.10
                    let rect = CGRect(
                        x: clamp(x - width / 2, 0, 1 - width),
                        y: clamp((1 - yFromTop) - height / 2, 0, 1 - height),
                        width: width,
                        height: height
                    )
                    let newRegion = RedactionRegion(kind: .manual, rect: rect)
                    regions.append(newRegion)
                    selectedRegionID = newRegion.id
                    isAddingRegion = false
                }
            )
        }
    }

    private func aspectFitFrame(imageSize: CGSize, containerSize: CGSize) -> CGRect {
        guard imageSize.width > 0, imageSize.height > 0 else {
            return CGRect(origin: .zero, size: containerSize)
        }
        let scale = min(
            containerSize.width / imageSize.width,
            containerSize.height / imageSize.height
        )
        let size = CGSize(
            width: imageSize.width * scale,
            height: imageSize.height * scale
        )
        return CGRect(
            x: (containerSize.width - size.width) / 2,
            y: (containerSize.height - size.height) / 2,
            width: size.width,
            height: size.height
        )
    }

    private func displayRect(_ normalized: NormalizedRect, inside frame: CGRect) -> CGRect {
        CGRect(
            x: frame.minX + CGFloat(normalized.x) * frame.width,
            y: frame.minY + CGFloat(1 - normalized.y - normalized.height) * frame.height,
            width: CGFloat(normalized.width) * frame.width,
            height: CGFloat(normalized.height) * frame.height
        )
    }

    private func clamp<T: Comparable>(_ value: T, _ lower: T, _ upper: T) -> T {
        min(max(value, lower), upper)
    }
}

struct CommunityCameraPicker: UIViewControllerRepresentable {
    let completion: (UIImage?) -> Void
    @Environment(\.dismiss) private var dismiss

    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            picker.sourceType = .camera
            picker.cameraCaptureMode = .photo
        } else {
            picker.sourceType = .photoLibrary
        }
        return picker
    }

    func updateUIViewController(
        _ uiViewController: UIImagePickerController,
        context: Context
    ) {}

    final class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let parent: CommunityCameraPicker

        init(parent: CommunityCameraPicker) {
            self.parent = parent
        }

        func imagePickerController(
            _ picker: UIImagePickerController,
            didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]
        ) {
            parent.completion(info[.originalImage] as? UIImage)
            parent.dismiss()
        }

        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            parent.completion(nil)
            parent.dismiss()
        }
    }
}

private extension UIImage {
    func normalizedUp() -> UIImage {
        guard imageOrientation != .up else { return self }
        let format = UIGraphicsImageRendererFormat()
        format.scale = scale
        format.opaque = true
        return UIGraphicsImageRenderer(size: size, format: format).image { _ in
            draw(in: CGRect(origin: .zero, size: size))
        }
    }
}
