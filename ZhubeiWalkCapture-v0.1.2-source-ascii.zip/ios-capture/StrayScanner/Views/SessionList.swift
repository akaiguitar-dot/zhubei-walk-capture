//
//  SessionList.swift
//  Stray Scanner
//
//  Created by Kenneth Blomqvist on 11/15/20.
//  Copyright © 2020 Stray Robots. All rights reserved.
//

import SwiftUI
import CoreData

enum WalkCaptureMode: String, Codable, Equatable {
    case mappedSegment = "mapped_segment"
    case freeRoute = "free_route"
}

struct WalkMission: Codable, Equatable {
    let segmentID: String
    let targetLengthMeters: Double
    let requiresReturnTrip: Bool
    let captureMode: WalkCaptureMode

    init(
        segmentID: String,
        targetLengthMeters: Double,
        requiresReturnTrip: Bool,
        captureMode: WalkCaptureMode = .mappedSegment
    ) {
        self.segmentID = segmentID
        self.targetLengthMeters = targetLengthMeters
        self.requiresReturnTrip = requiresReturnTrip
        self.captureMode = captureMode
    }

    var expectedTravelMeters: Double {
        guard captureMode == .mappedSegment else { return 0 }
        targetLengthMeters * (requiresReturnTrip ? 2.0 : 1.0)
    }
}

class SessionListViewModel: ObservableObject {
    private var dataContext: NSManagedObjectContext?
    @Published var sessions: [Recording] = []

    init() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        dataContext = appDelegate.persistentContainer.viewContext
        self.sessions = []
        NotificationCenter.default.addObserver(self, selector: #selector(sessionsChanged), name: NSNotification.Name("sessionsChanged"), object: nil)
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
    }

    func fetchSessions() {
        let request = NSFetchRequest<NSManagedObject>(entityName: "Recording")
        request.sortDescriptors = [NSSortDescriptor(key: "createdAt", ascending: false)]
        do {
            let fetched: [NSManagedObject] = try dataContext?.fetch(request) ?? []
            sessions = fetched.map { session in
                return session as! Recording
            }

        } catch let error as NSError {
            print("Something went wrong. Error: \(error), \(error.userInfo)")
        }
    }

    @objc func sessionsChanged() {
        fetchSessions()
    }

}

struct SessionList: View {
    @ObservedObject var viewModel = SessionListViewModel()
    @State private var segmentID = "ZB-WALK-0001"
    @State private var lengthText = "20"
    @State private var requiresReturnTrip = true
    @State private var captureMode: WalkCaptureMode = .mappedSegment
    @State private var activeMission: WalkMission?
    @State private var showingRecorder = false
    @State private var validationMessage: String?

    private var mission: WalkMission? {
        let trimmedID = segmentID.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        guard !trimmedID.isEmpty else { return nil }
        if captureMode == .freeRoute {
            return WalkMission(
                segmentID: trimmedID,
                targetLengthMeters: 0,
                requiresReturnTrip: false,
                captureMode: .freeRoute
            )
        }
        let normalizedLength = lengthText.replacingOccurrences(of: "，", with: ".")
            .replacingOccurrences(of: ",", with: ".")
        guard let length = Double(normalizedLength),
              length > 0 else {
            return nil
        }
        return WalkMission(
            segmentID: trimmedID,
            targetLengthMeters: length,
            requiresReturnTrip: requiresReturnTrip,
            captureMode: .mappedSegment
        )
    }

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("竹北人行道採集")
                            .font(.largeTitle.bold())
                        Text("選定路段，沿指示走完去程與回程。LiDAR、影像與手機姿態會同步保存。")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }

                    VStack(alignment: .leading, spacing: 14) {
                        Text("這次要怎麼採集？")
                            .font(.headline)

                        Picker("採集方式", selection: $captureMode) {
                            Text("GIS 路段").tag(WalkCaptureMode.mappedSegment)
                            Text("自由動線").tag(WalkCaptureMode.freeRoute)
                        }
                        .pickerStyle(.segmented)

                        TextField("路段編號，例如 ZB-WALK-00428", text: $segmentID)
                            .textInputAutocapitalization(.characters)
                            .autocorrectionDisabled()
                            .padding(14)
                            .background(Color(.secondarySystemBackground))
                            .clipShape(RoundedRectangle(cornerRadius: 14))

                        if captureMode == .mappedSegment {
                            HStack {
                                TextField("路段長度", text: $lengthText)
                                    .keyboardType(.decimalPad)
                                Text("公尺")
                                    .foregroundColor(.secondary)
                            }
                            .padding(14)
                            .background(Color(.secondarySystemBackground))
                            .clipShape(RoundedRectangle(cornerRadius: 14))

                            Toggle("走到底後沿原路返回", isOn: $requiresReturnTrip)
                                .tint(.green)
                        } else {
                            Text("不用先填長度。App 會沿你實際走過的路，每 1 公尺建立一個空間節點。")
                                .font(.footnote)
                                .foregroundColor(.secondary)
                                .padding(14)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .background(Color(.secondarySystemBackground))
                                .clipShape(RoundedRectangle(cornerRadius: 14))
                        }

                        if let mission {
                            if mission.captureMode == .freeRoute {
                                Label("不限長度，結束時手動停止", systemImage: "point.topleft.down.to.point.bottomright.curvepath")
                                    .font(.footnote)
                                    .foregroundColor(.secondary)
                            } else {
                                HStack {
                                    Label(
                                        "預計採集 \(mission.expectedTravelMeters, specifier: "%.0f") 公尺",
                                        systemImage: "figure.walk"
                                    )
                                    Spacer()
                                    Text(requiresReturnTrip ? "往返" : "單程")
                                }
                                .font(.footnote)
                                .foregroundColor(.secondary)
                            }
                        }

                        Button(action: beginMission) {
                            Label("開始採集", systemImage: "viewfinder")
                                .font(.title3.bold())
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 16)
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(.green)
                        .clipShape(RoundedRectangle(cornerRadius: 16))

                        NavigationLink(
                            destination: Group {
                                if let activeMission {
                                    NewSessionView(mission: activeMission)
                                }
                            },
                            isActive: $showingRecorder
                        ) {
                            EmptyView()
                        }
                    }

                    if !viewModel.sessions.isEmpty {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("最近完成")
                                .font(.headline)

                            ForEach(viewModel.sessions, id: \.objectID) { recording in
                                NavigationLink(destination: SessionDetailView(recording: recording)) {
                                    HStack {
                                        Image(systemName: "checkmark.circle.fill")
                                            .foregroundColor(.green)
                                        VStack(alignment: .leading, spacing: 3) {
                                            Text(recording.name ?? "未命名路段")
                                                .font(.body.bold())
                                            Text(recording.createdAt ?? Date(), style: .date)
                                                .font(.caption)
                                                .foregroundColor(.secondary)
                                        }
                                        Spacer()
                                        Image(systemName: "chevron.right")
                                            .foregroundColor(.secondary)
                                    }
                                    .padding(14)
                                    .background(Color(.secondarySystemBackground))
                                    .clipShape(RoundedRectangle(cornerRadius: 14))
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                }
                .padding(20)
            }
            .background(Color(.systemBackground).ignoresSafeArea())
            .navigationBarHidden(true)
            .onAppear(perform: refreshSessions)
            .alert("還不能開始", isPresented: Binding(
                get: { validationMessage != nil },
                set: { if !$0 { validationMessage = nil } }
            )) {
                Button("知道了", role: .cancel) {}
            } message: {
                Text(validationMessage ?? "")
            }
        }
    }

    private func beginMission() {
        guard let mission else {
            validationMessage = captureMode == .freeRoute
                ? "請先輸入這次自由動線的名稱或編號。"
                : "請輸入路段編號與大於 0 的路段長度。"
            return
        }
        activeMission = mission
        showingRecorder = true
    }

    private func refreshSessions() {
        DispatchQueue.main.async {
            viewModel.fetchSessions()
        }
        let delegate = UIApplication.shared.delegate as? AppDelegate
        delegate?.appDaemon?.removeDeletedEntries()
    }
}

struct SessionList_Previews: PreviewProvider {
    static var previews: some View {
        SessionList()
    }
}
